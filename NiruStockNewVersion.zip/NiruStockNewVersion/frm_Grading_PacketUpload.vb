﻿Imports System.Data.SqlClient
Imports System.IO

Public Class frm_Grading_PacketUpload

    ' FORM LOAD
    Private Sub frm_Grading_PacketUpload_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
        Catch ex As Exception
            ErrorLog("frm_Grading_PacketUpload", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.ReadOnly = True
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("Tahoma", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim headers() As String = {"Parcel No", "Assortment", "Code", "Size Range", "Pcs", "Cts"}
        Dim names() As String = {"ParNo", "Assortment", "Code", "SizeRange", "Pcs", "Cts"}
        Dim widths() As Integer = {100, 110, 110, 110, 80, 90}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            If idx >= 4 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    ' PARCEL NO — ENTER KEY
    Private Sub txtParNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If ParcelFound(txtParNo.Text.Trim()) Then
                txtParNo.Text = txtParNo.Text.Trim().ToUpper()
                txtPktNo.Focus()
            Else
                MessageBox.Show("Invalid Parcel", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                ClearFields()
                txtParNo.Focus()
            End If
        End If
    End Sub

    ' PACKET NO — ENTER KEY
    Private Sub txtPktNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Try
                Using cmd As New SqlCommand(
                    "SELECT * FROM tblGrading_Packet WHERE ParNo=@par AND PktNo=@pkt",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        If dr.Read() Then
                            txtPktPcs.Text = dr("PktPcs").ToString()
                            txtPktCts.Text = Format(Convert.ToDouble(dr("PktCts")), "#0.000")
                        Else
                            MessageBox.Show("Invalid Parcel and Packet", Me.Text,
                                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                            txtPktNo.Text = ""
                        End If
                    End Using
                End Using
            Catch ex As Exception
                ErrorLog("frm_Grading_PacketUpload", "txtPktNo_KeyPress")
            End Try
        End If
    End Sub

    ' SELECT FILE
    Private Sub cmdSelect_Click(sender As Object, e As EventArgs) Handles cmdSelect.Click
        flxDetails.Rows.Clear()
        Using dlg As New OpenFileDialog()
            dlg.InitialDirectory = "C:\"
            dlg.Filter = "Excel Files (*.xls;*.xlsx)|*.xls;*.xlsx|All Files|*.*"
            If dlg.ShowDialog() = DialogResult.OK Then
                txtBackupLocation.Text = dlg.FileName
            End If
        End Using
    End Sub

    ' LOAD FILE
    Private Sub cmdLoad_Click(sender As Object, e As EventArgs) Handles cmdLoad.Click
        If txtBackupLocation.Text.Trim() = "" Then
            MessageBox.Show("Please select the Excel file", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If Not File.Exists(txtBackupLocation.Text.Trim()) Then
            MessageBox.Show("Invalid File Path", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        Upload_Excel()
    End Sub

    ' READ EXCEL AND POPULATE GRID
    Private Sub Upload_Excel()
        Cursor.Current = Cursors.WaitCursor
        Try
            flxDetails.Rows.Clear()
            txtPcs.Text = "0"
            txtCts.Text = "0"

            Dim xlApp As New Microsoft.Office.Interop.Excel.Application()
            xlApp.Visible = False
            Dim wb As Microsoft.Office.Interop.Excel.Workbook =
                xlApp.Workbooks.Open(txtBackupLocation.Text.Trim())
            Dim ws As Microsoft.Office.Interop.Excel.Worksheet =
                CType(wb.Worksheets(1), Microsoft.Office.Interop.Excel.Worksheet)

            Dim totPcs As Double = 0
            Dim totCts As Double = 0

            For intRow As Integer = 2 To 1000
                Dim cellVal As Object = ws.Cells(intRow, 1).Value
                If cellVal Is Nothing OrElse cellVal.ToString().Trim() = "" Then Exit For

                Dim assortNo As String = cellVal.ToString().Trim()

                ' Look up code from tblGrading_SizeListNew
                Dim mainAssort As String = ""
                Using cmd As New SqlCommand(
                    "SELECT MainAssort FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@a", assortNo)
                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing Then mainAssort = result.ToString().Trim()
                End Using

                If mainAssort = "" Then
                    Application.DoEvents()
                    Continue For
                End If

                Dim sizeRange As String = ws.Cells(intRow, 2).Value?.ToString().Trim()
                Dim pcs As Double = Convert.ToDouble(If(ws.Cells(intRow, 3).Value IsNot Nothing, ws.Cells(intRow, 3).Value, 0))
                Dim cts As Double = Convert.ToDouble(If(ws.Cells(intRow, 4).Value IsNot Nothing, ws.Cells(intRow, 4).Value, 0))

                flxDetails.Rows.Add(
                    txtParNo.Text.Trim(),
                    assortNo,
                    mainAssort,
                    sizeRange,
                    pcs.ToString(),
                    Format(cts, "#0.000")
                )

                totPcs += pcs
                totCts += cts

                Application.DoEvents()
            Next

            txtPcs.Text = totPcs.ToString()
            txtCts.Text = Format(Math.Round(totCts, 3), "#0.000")

            wb.Close(False)
            xlApp.Quit()
            System.Runtime.InteropServices.Marshal.ReleaseComObject(ws)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(wb)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    ' SAVE BUTTON
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Save()
    End Sub

    Private Sub Save()
        Try
            If flxDetails.Rows.Count = 0 Then Return

            If txtParNo.Text.Trim() = "" Then MessageBox.Show("Invalid Parcel No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtPktNo.Text.Trim() = "" Then MessageBox.Show("Invalid Packet No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtPktPcs.Text.Trim() = "" Then MessageBox.Show("Invalid Packet Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtPktCts.Text.Trim() = "" Then MessageBox.Show("Invalid Packet Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtPcs.Text.Trim() = "" Then MessageBox.Show("Invalid Total Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtCts.Text.Trim() = "" Then MessageBox.Show("Invalid Total Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return

            ' Verify pcs/cts match packet
            If Convert.ToDouble(txtPktPcs.Text) <> Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Invalid Pcs — does not match packet", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtPktCts.Text), 3) <> Math.Round(Convert.ToDouble(txtCts.Text), 3) Then
                MessageBox.Show("Invalid Cts — does not match packet", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            Dim confirm = MessageBox.Show("Are you sure?", Me.Text,
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.No Then Return

            Dim par As String = txtParNo.Text.Trim()
            Dim pkt As String = txtPktNo.Text.Trim()
            Dim pcs As Single = CSng(txtPcs.Text)
            Dim cts As Double = Convert.ToDouble(txtCts.Text)
            Dim today As String = Date.Now.ToString("MM/dd/yyyy")
            Dim now As String = DateTime.Now.ToString("HH:mm:ss")

            ' Insert checking issues/returns/types if not Size Only
            If Not chkSize.Checked Then
                For sec As Integer = 1 To 5
                    Using cmd As New SqlCommand(
                        "SELECT COUNT(*) FROM tblGrading_CheckingIssues " &
                        "WHERE Department='Colombo' AND ParNo=@par AND PktNo=@pkt AND Sec=@sec",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@par", par)
                        cmd.Parameters.AddWithValue("@pkt", pkt)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        If CInt(cmd.ExecuteScalar()) > 0 Then
                            MessageBox.Show("Already Entered", Me.Text,
                                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                            Return
                        End If
                    End Using

                    Using cmd As New SqlCommand(
                        "INSERT INTO tblGrading_CheckingIssues(Department,ParNo,PktNo,Sec,SecCount,EmpNo,IssPcs,IssCts,IssDate,IssTime) " &
                        "VALUES('Colombo',@par,@pkt,@sec,@sec,'D06975',@pcs,@cts,@date,@time)",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@par", par)
                        cmd.Parameters.AddWithValue("@pkt", pkt)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        cmd.Parameters.AddWithValue("@pcs", pcs)
                        cmd.Parameters.AddWithValue("@cts", cts)
                        cmd.Parameters.AddWithValue("@date", today)
                        cmd.Parameters.AddWithValue("@time", now)
                        cmd.ExecuteNonQuery()
                    End Using

                    Using cmd As New SqlCommand(
                        "INSERT INTO tblGrading_CheckingReturns(Department,ParNo,PktNo,Sec,SecCount,EmpNo,RetPcs,RetCts,LostPcs,LostCts,RepPcs,RepCts,RetDate,RetTime,RejPcs,RejCts) " &
                        "VALUES('Colombo',@par,@pkt,@sec,@sec,'D06975',@pcs,@cts,0,0,0,0,@date,@time,0,0)",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@par", par)
                        cmd.Parameters.AddWithValue("@pkt", pkt)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        cmd.Parameters.AddWithValue("@pcs", pcs)
                        cmd.Parameters.AddWithValue("@cts", cts)
                        cmd.Parameters.AddWithValue("@date", today)
                        cmd.Parameters.AddWithValue("@time", now)
                        cmd.ExecuteNonQuery()
                    End Using

                    ' Insert checking types with defaults per section
                    Dim rt1 As String = "DEF"
                    Dim rt2 As String = If(sec >= 2, "A MAKE", "")
                    Dim rt3 As String = If(sec >= 3, "N FLO", "")
                    Dim rt4 As String = If(sec >= 4, "VVS2", "")

                    Using cmd As New SqlCommand(
                        "INSERT INTO tblGrading_CheckingTypes(Department,ParNo,PktNo,Sec,ReturnType1,ReturnType2,ReturnType3,ReturnType4,Pcs,Cts) " &
                        "VALUES('Colombo',@par,@pkt,@sec,@rt1,@rt2,@rt3,@rt4,@pcs,@cts)",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@par", par)
                        cmd.Parameters.AddWithValue("@pkt", pkt)
                        cmd.Parameters.AddWithValue("@sec", sec)
                        cmd.Parameters.AddWithValue("@rt1", rt1)
                        cmd.Parameters.AddWithValue("@rt2", rt2)
                        cmd.Parameters.AddWithValue("@rt3", rt3)
                        cmd.Parameters.AddWithValue("@rt4", rt4)
                        cmd.Parameters.AddWithValue("@pcs", pcs)
                        cmd.Parameters.AddWithValue("@cts", cts)
                        cmd.ExecuteNonQuery()
                    End Using
                Next
            End If

            ' Sizing Packet
            Using cmd As New SqlCommand(
                "INSERT INTO tblGrading_SizingPacket(Department,ParNo,PktNo,SizeCode,PktPcs,PktCts,ReturnType1,ReturnType2,ReturnType3,ReturnType4,PktType) " &
                "VALUES('Colombo',@par,@pkt,'T02-0',@pcs,@cts,'','','','','N')", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", par)
                cmd.Parameters.AddWithValue("@pkt", pkt)
                cmd.Parameters.AddWithValue("@pcs", CDbl(pcs))
                cmd.Parameters.AddWithValue("@cts", cts)
                cmd.ExecuteNonQuery()
            End Using

            ' Sizing Issue
            Using cmd As New SqlCommand(
                "INSERT INTO tblGrading_SizingIssues(Department,ParNo,PktNo,Sec,EmpNo,IssPcs,IssCts,IssDate,IssTime) " &
                "VALUES('Colombo',@par,@pkt,1,'D06975',@pcs,@cts,@date,@time)", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", par)
                cmd.Parameters.AddWithValue("@pkt", pkt)
                cmd.Parameters.AddWithValue("@pcs", CDbl(pcs))
                cmd.Parameters.AddWithValue("@cts", cts)
                cmd.Parameters.AddWithValue("@date", today)
                cmd.Parameters.AddWithValue("@time", now)
                cmd.ExecuteNonQuery()
            End Using

            ' Sizing Return
            Using cmd As New SqlCommand(
                "INSERT INTO tblGrading_SizingReturns(Department,ParNo,PktNo,Sec,EmpNo,RetPcs,RetCts,LostPcs,LostCts,RepPcs,RepCts,RetDate,RetTime,RejPcs,RejCts) " &
                "VALUES('Colombo',@par,@pkt,1,'D06975',@pcs,@cts,0,0,0,0,@date,@time,0,0)", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", par)
                cmd.Parameters.AddWithValue("@pkt", pkt)
                cmd.Parameters.AddWithValue("@pcs", CDbl(pcs))
                cmd.Parameters.AddWithValue("@cts", cts)
                cmd.Parameters.AddWithValue("@date", today)
                cmd.Parameters.AddWithValue("@time", now)
                cmd.ExecuteNonQuery()
            End Using

            ' Sizing Types — one row per grid row
            For Each row As DataGridViewRow In flxDetails.Rows
                Using cmd As New SqlCommand(
                    "INSERT INTO tblGrading_SizingTypes(Department,ParNo,PktNo,Sec,ReturnType1,ReturnType2,ReturnType3,ReturnType4,ReturnType5,Pcs,Cts) " &
                    "VALUES('Colombo',@par,@pkt,1,@rt1,@rt2,@rt3,'','',@pcs,@cts)", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@par", par)
                    cmd.Parameters.AddWithValue("@pkt", pkt)
                    cmd.Parameters.AddWithValue("@rt1", row.Cells("Code").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@rt2", row.Cells("Assortment").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@rt3", row.Cells("SizeRange").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
                    cmd.ExecuteNonQuery()
                End Using
            Next

            MessageBox.Show("Parcel Saved", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()

        Catch ex As Exception
            MessageBox.Show("Error saving: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    ' PARCEL FOUND CHECK
    Private Function ParcelFound(parcelNo As String) As Boolean
        Try
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblInvoice WHERE ParcelNo=@par", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", parcelNo)
                Return CInt(cmd.ExecuteScalar()) > 0
            End Using
        Catch
            Return False
        End Try
    End Function

    ' CLEAR ALL FIELDS
    Private Sub ClearFields()
        txtParNo.Text = ""
        txtPktNo.Text = ""
        txtPktPcs.Text = ""
        txtPktCts.Text = ""
        txtPcs.Text = ""
        txtCts.Text = ""
        txtBackupLocation.Text = ""
        flxDetails.Rows.Clear()
        chkSize.Checked = False
    End Sub

    ' EXIT
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class