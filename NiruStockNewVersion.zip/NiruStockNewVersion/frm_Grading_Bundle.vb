﻿Imports System.Data.SqlClient

Public Class frm_Grading_Bundle

    ' FORM LOAD
    Private Sub frm_Grading_Bundle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            GetBundleNo()
        Catch ex As Exception
            ErrorLog("frm_Grading_Bundle", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID — single column: Packing List No
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.ReadOnly = True
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("MS Sans Serif", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim col As New DataGridViewTextBoxColumn()
        col.HeaderText = "Packing List No."
        col.Name = "PackNo"
        col.Width = 300
        flxDetails.Columns.Add(col)
    End Sub

    ' GET NEXT BUNDLE NUMBER
    Private Sub GetBundleNo()
        Try
            Using cmd As New SqlCommand(
                "SELECT MAX(BundleNo) AS MaxNo FROM tblGrading_Bundle", dbconn_Prod)
                Dim result = cmd.ExecuteScalar()
                txtBundleNo.Text = If(result Is DBNull.Value OrElse result Is Nothing,
                                      "1", (CInt(result) + 1).ToString())
            End Using
        Catch ex As Exception
            txtBundleNo.Text = "1"
        End Try
    End Sub

    ' PACKING LIST NO KEY PRESS
    Private Sub txtPackNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPackNo.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            cmdAdd.Focus()
        End If
    End Sub

    Private Sub txtBNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBNo.KeyPress
        IntegerOnly(e)
    End Sub

    ' ADD BUTTON
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Try
            If txtPackNo.Text.Trim() = "" Then Return

            ' Check if already bundled in DB
            Using cmd As New SqlCommand(
                "SELECT BundleNo FROM tblGrading_Bundle WHERE PackNo=@pn",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@pn", CDbl(txtPackNo.Text))
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing Then
                    MessageBox.Show("Already Bundled - " & result.ToString(), Me.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            End Using

            ' Check if already in current list
            For Each row As DataGridViewRow In flxDetails.Rows
                If row.Cells("PackNo").Value?.ToString() = txtPackNo.Text.Trim() Then
                    MessageBox.Show("Already Selected", Me.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            Next

            flxDetails.Rows.Add(txtPackNo.Text.Trim())
            txtPackNo.Text = ""
            txtPackNo.Focus()

        Catch ex As Exception
            ErrorLog("frm_Grading_Bundle", "cmdAdd_Click")
        End Try
    End Sub

    ' ROW CLICK — REMOVE ITEM
    Private Sub flxDetails_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellClick
        If e.RowIndex < 0 Then Return
        Try
            Dim confirm = MessageBox.Show("Are you sure to remove this entry?", Me.Text,
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.Yes Then
                flxDetails.Rows.RemoveAt(e.RowIndex)
            End If
        Catch ex As Exception
            ErrorLog("frm_Grading_Bundle", "flxDetails_CellClick")
        End Try
    End Sub

    ' SAVE BUTTON
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If flxDetails.Rows.Count = 0 Then
                MessageBox.Show("No packing list items added.", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim confirm = MessageBox.Show("Are you sure?", Me.Text,
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.No Then Return

            For Each row As DataGridViewRow In flxDetails.Rows
                Using cmd As New SqlCommand(
                    "INSERT INTO tblGrading_Bundle(BundleNo, PackNo) VALUES(@bno, @pno)",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                    cmd.Parameters.AddWithValue("@pno", CDbl(row.Cells("PackNo").Value?.ToString()))
                    cmd.ExecuteNonQuery()
                End Using
            Next

            MessageBox.Show("Bundle saved successfully.", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            ResetForm()

        Catch ex As Exception
            ErrorLog("frm_Grading_Bundle", "cmdSave_Click")
        End Try
    End Sub

    ' REFRESH BUTTON
    Private Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
        ResetForm()
    End Sub

    ' CLEAR BUTTON — DELETE BUNDLE FROM DB
    Private Sub cmdClear_Click(sender As Object, e As EventArgs) Handles cmdClear.Click
        Try
            Dim confirm = MessageBox.Show("Are you sure?", Me.Text,
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.Yes Then
                If txtBNo.Text.Trim() <> "" Then
                    Using cmd As New SqlCommand(
                        "DELETE FROM tblGrading_Bundle WHERE BundleNo=@bno", dbconn_Prod)
                        cmd.Parameters.AddWithValue("@bno", CDbl(txtBNo.Text))
                        cmd.ExecuteNonQuery()
                    End Using
                End If
                ResetForm()
            End If
        Catch ex As Exception
            ErrorLog("frm_Grading_Bundle", "cmdClear_Click")
        End Try
    End Sub


    ' EXIT
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    Private Sub ResetForm()
        GetBundleNo()
        txtPackNo.Text = ""
        txtBNo.Text = ""
        flxDetails.Rows.Clear()
    End Sub

End Class