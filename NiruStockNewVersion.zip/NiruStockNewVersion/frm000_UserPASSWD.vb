﻿Public Class frm000_UserPASSWD

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frm000_UserPASSWD_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MSG_Form_Code = "000"
        MSG_Form_Name = "System Log-in and Validate Password"
        MSG_Form_Execution_Level = "0"
        MSG_Form_Procedure = "Form Loading"

        Try
            ' Centre the form on screen
            Me.StartPosition = FormStartPosition.CenterScreen

            ' Set caption with date and time
            Me.Text = " * " & Date.Now.ToString("dd/MM/yyyy") & " * " & Date.Now.ToString("HH:mm:ss")

            ' Show company and location
            lblCompany.Text = Prod_GROUP_NAME.Trim()
            lblLocation.Text = Prod_NAME.Trim()

            ' Lock password until user is selected
            txtPassWord.ReadOnly = True

            ' Hide change password panel initially
            passfr.Visible = False

            ' Load users into dropdown
            Load_Users()

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD USERS INTO COMBO BOX
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Users()
        MSG_Form_Procedure = "Loading Users"
        Try
            cmbUsers.Items.Clear()

            Using cmd As New SqlCommand("SELECT User_ID, User_Name FROM PASSWD ORDER BY User_Name", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        ' Store User_ID as display, User_Name as tag via custom item
                        Dim item As New UserItem(dr("User_ID").ToString().Trim(),
                                                 dr("User_Name").ToString().Trim())
                        cmbUsers.Items.Add(item)
                    End While
                End Using
            End Using

            MSG_Form_Execution_Level = "99"

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' USER SELECTION FROM COMBO BOX
    '──────────────────────────────────────────────────────────────
    Private Sub cmbUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbUsers.SelectedIndexChanged
        MSG_Form_Procedure = "Select Users"
        Try
            If cmbUsers.SelectedItem Is Nothing Then Return

            Dim selected As UserItem = CType(cmbUsers.SelectedItem, UserItem)
            PBUser_ID = selected.UserID
            PBUser_Name = selected.UserName
            lblName.Text = selected.UserName

            txtPassWord.ReadOnly = True
            txtPassWord.Text = ""

            Verify_Password(PBUser_ID)

            If PBUser_Password_Step1_OK Then
                txtPassWord.ReadOnly = False
                txtPassWord.Focus()
            Else
                MessageBox.Show("Invalid User", "User Selection",
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' COMBO BOX GOT FOCUS — RESET PASSWORD FIELD
    '──────────────────────────────────────────────────────────────
    Private Sub cmbUsers_GotFocus(sender As Object, e As EventArgs) Handles cmbUsers.GotFocus
        txtPassWord.Text = ""
        txtPassWord.ReadOnly = True
        lblName.Text = ""
    End Sub

    '──────────────────────────────────────────────────────────────
    ' PASSWORD INPUT — PRESS ENTER TO LOGIN
    '──────────────────────────────────────────────────────────────
    Private Sub txtPassWord_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPassWord.KeyPress
        MSG_Form_Procedure = "Password Input"
        Try
            If e.KeyChar = ControlChars.Cr Then
                e.Handled = True

                If txtPassWord.Text.Trim() = "" Then Return

                If PBUser_TablePassword.Trim() = txtPassWord.Text.Trim() Then
                    PBUser_TablePassword = ""

                    If PBUser_PasswordChanged Then
                        ' Force password change
                        passfr.Visible = True
                        txtpw.Focus()
                    Else
                        ' Successful login
                        LoginSuccess()
                    End If
                Else
                    MessageBox.Show("Invalid Password.....", "Password Input",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtPassWord.Text = ""
                    txtPassWord.Focus()
                End If
            End If

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' NEW PASSWORD INPUT
    '──────────────────────────────────────────────────────────────
    Private Sub txtpw_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtpw.KeyPress
        MSG_Form_Procedure = "Change Password Input"
        Try
            If e.KeyChar = ControlChars.Cr Then
                e.Handled = True

                If txtpw.Text.Trim() = "" Then
                    MessageBox.Show("Please Enter Your New Password", "Changing Password",
                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return
                End If

                If txtPassWord.Text.Trim() = txtpw.Text.Trim() Then
                    txtpw.Text = ""
                    MessageBox.Show("Invalid Password - new password cannot be the same as old",
                                    "Changing Password", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return
                End If

                txtcpw.Focus()
            End If

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' CONFIRM NEW PASSWORD INPUT
    '──────────────────────────────────────────────────────────────
    Private Sub txtcpw_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcpw.KeyPress
        MSG_Form_Procedure = "Confirm Change Password Input"

        If txtpw.Text.Trim() = "" Then
            txtcpw.ReadOnly = True
            Return
        End If

        txtcpw.ReadOnly = False

        Try
            If e.KeyChar = ControlChars.Cr Then
                e.Handled = True

                If txtpw.Text.Trim() = txtcpw.Text.Trim() AndAlso
                   txtPassWord.Text.Trim() <> txtpw.Text.Trim() Then

                    ' Encrypt and save new password
                    MSG_Form_Execution_Level = "2"
                    ENCRIPT(txtcpw.Text)

                    Using trans As SqlTransaction = dbconn_Prod.BeginTransaction()
                        Try
                            Using cmd As New SqlCommand(
                                "UPDATE PASSWD SET PASS11=@p1, PASS22=@p2, PASS33=@p3, PASS44=@p4, " &
                                "PASS55=@p5, PASS66=@p6, PASS77=@p7, PASS88=@p8, CHANGE='0' " &
                                "WHERE User_ID=@uid", dbconn_Prod, trans)
                                cmd.Parameters.AddWithValue("@p1", mmInt_Pass1)
                                cmd.Parameters.AddWithValue("@p2", mmInt_Pass2)
                                cmd.Parameters.AddWithValue("@p3", mmInt_Pass3)
                                cmd.Parameters.AddWithValue("@p4", mmInt_Pass4)
                                cmd.Parameters.AddWithValue("@p5", mmInt_Pass5)
                                cmd.Parameters.AddWithValue("@p6", mmInt_Pass6)
                                cmd.Parameters.AddWithValue("@p7", mmInt_Pass7)
                                cmd.Parameters.AddWithValue("@p8", mmInt_Pass8)
                                cmd.Parameters.AddWithValue("@uid", PBUser_ID)
                                cmd.ExecuteNonQuery()
                            End Using
                            trans.Commit()
                        Catch
                            trans.Rollback()
                            Throw
                        End Try
                    End Using

                    passfr.Visible = False
                    LoginSuccess()

                ElseIf txtpw.Text.Trim() = txtPassWord.Text.Trim() Then
                    txtpw.Text = ""
                    txtcpw.Text = ""
                    txtpw.Focus()
                    MessageBox.Show("Invalid Password", "Changing Password",
                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    MessageBox.Show("Please Check The Password Again", "Changing Password",
                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If

        Catch ex As Exception
            Message_Window_Runtime(MSG_Form_Code, MSG_Form_Name, MSG_Form_Procedure,
                                   CInt(MSG_Form_Execution_Level), 0, ex.Message, 1)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOGIN SUCCESS — OPEN MAIN FORM
    '──────────────────────────────────────────────────────────────
    Private Sub LoginSuccess()
        Log_book("LOG-IN", "USER LOGGED-IN", "NONE",
                 "User - " & PBUser_ID.Trim() & " - " & lblName.Text.Trim())
        'Dim mainForm As New mdi_Hotel()
        'mainForm.Show()
        Me.Close()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' TIMER — SCROLL CAPTION TEXT
    '──────────────────────────────────────────────────────────────
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Text = scrolltext(Me.Text)
    End Sub

End Class

'──────────────────────────────────────────────────────────────────
' HELPER CLASS — ComboBox item holding UserID + UserName together
'──────────────────────────────────────────────────────────────────
Public Class UserItem
    Public Property UserID As String
    Public Property UserName As String

    Public Sub New(id As String, name As String)
        UserID = id
        UserName = name
    End Sub

    ' This controls what text is displayed in the ComboBox
    Public Overrides Function ToString() As String
        Return UserID & "  -  " & UserName
    End Function
End Class