﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.IO

Public Class frm_Grading_ExportSummary

    Private Sub frm_Grading_ExportSummary_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrids()
            GetPackNo()
            txtAddPcs.Text = "0"
            txtAddCts.Text = "0"
            txtPcs.Text = "0"
            txtCts.Text = "0"
            Load_ExportParcels()
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummary", "Form_Load")
        End Try
    End Sub

    Private Sub SetupGrids()
        ' Main details grid
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("MS Sans Serif", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim headers() As String = {
            "Assortment", "Par No", "Pcs", "Cts", "Act Pcs", "Act Cts",
            "Diff", "Price", "Value", "Dept", "ID", "Order No",
            "Pkt No", "Color", "Clarity", "Code", "Size Range"
        }
        Dim names() As String = {
            "Assortment", "ParNo", "Pcs", "Cts", "ActPcs", "ActCts",
            "Diff", "Price", "Value", "Dept", "ID", "OrderNo",
            "PktNo", "Color", "Clarity", "Code", "SizeRange"
        }
        Dim widths() As Integer = {
            110, 80, 60, 70, 60, 70,
            60, 65, 75, 80, 50, 90,
            65, 70, 70, 80, 90
        }
        Dim editable() As Boolean = {
            False, False, False, False, True, False,
            False, False, False, False, False, False,
            False, False, False, False, False
        }

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = Not editable(idx)
            If idx >= 2 AndAlso idx <= 8 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next

        ' Parcel combo grid
        cmbParcel.DropDownStyle = ComboBoxStyle.DropDownList
    End Sub

    Private Sub GetPackNo()
        Try
            Using cmd As New SqlCommand(
                "SELECT MAX(PackNo) AS MaxNo FROM tblGrading_PackingList", dbconn_Prod)
                Dim result = cmd.ExecuteScalar()
                txtPackNo.Text = If(result Is DBNull.Value OrElse result Is Nothing,
                                    "1", (CInt(result) + 1).ToString())
            End Using
        Catch ex As Exception
            txtPackNo.Text = "1"
        End Try
    End Sub


    Private Sub Load_ExportParcels()
        Try
            cmbParcel.Items.Clear()

            Dim sql As String
            If chkNew.Checked Then
                sql = "SELECT TOP (100) PERCENT Department, ParNo " &
                      "FROM tblGrading_SizingTypes WHERE OK=0 " &
                      "GROUP BY Department, ParNo ORDER BY ParNo"
            Else
                sql = "SELECT DISTINCT TOP (100) PERCENT Department, LEFT(ParNo,6) AS ParNo " &
                      "FROM tblGrading_SizingTypes WHERE OK=0 ORDER BY LEFT(ParNo,6)"
            End If

            Using cmd As New SqlCommand(sql, dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbParcel.Items.Add(New ParcelItem(
                            dr("ParNo").ToString().Trim(),
                            dr("Department").ToString().Trim()))
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummary", "Load_ExportParcels")
        End Try
    End Sub

    Private Sub cmbParcel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbParcel.SelectedIndexChanged
        If cmbParcel.SelectedItem Is Nothing Then Return
        Dim item As ParcelItem = CType(cmbParcel.SelectedItem, ParcelItem)
        Load_ExportDetails(item.ParNo, item.Department)
    End Sub


    Private Sub Load_ExportDetails(strParcel As String, strDept As String)
        Try
            ' Check if already loaded
            For Each row As DataGridViewRow In flxDetails.Rows
                If row.Cells("ParNo").Value?.ToString() = strParcel AndAlso
                   row.Cells("Dept").Value?.ToString() = strDept Then
                    MessageBox.Show("Already Entered", Me.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            Next

            Dim intIssPcs As Double = Convert.ToDouble(If(txtAddPcs.Text = "", "0", txtAddPcs.Text))
            Dim dblIssCts As Double = Convert.ToDouble(If(txtAddCts.Text = "", "0", txtAddCts.Text))
            Dim is2nd As Boolean = opt2.Checked
            Dim ctsRound As Integer = If(is2nd, 2, 3)
            Dim parFilter As String = If(chkNew.Checked, strParcel, strParcel)
            Dim parWhere As String = If(chkNew.Checked, "st.ParNo", "LEFT(st.ParNo,6)")

            ' Query sizing types
            Dim sql As String =
                $"SELECT TOP (100) PERCENT st.Department, {parWhere} AS ParNo, " &
                "st.ReturnType2, st.ReturnType3, SUM(st.Pcs) AS Pcs, " &
                $"ROUND(SUM(st.Cts),{ctsRound}) AS Cts, sln.Price, sln.MainAssort " &
                "FROM tblGrading_SizingTypes st " &
                "INNER JOIN tblGrading_SizeListNew sln ON st.ReturnType2 = sln.AssortNo " &
                "INNER JOIN tblGrading_SizingPacket sp ON st.Department=sp.Department AND st.ParNo=sp.ParNo AND st.PktNo=sp.PktNo " &
                $"WHERE ({parWhere} = @parno) AND st.OK=0 " &
                $"GROUP BY st.Department, st.ReturnType2, st.ReturnType3, sln.Price, {parWhere}, sln.MainAssort " &
                "ORDER BY st.ReturnType2"

            Using cmd As New SqlCommand(sql, dbconn_Prod)
                cmd.Parameters.AddWithValue("@parno", strParcel)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim assort As String = dr("ReturnType2").ToString().Trim()
                        Dim parNo As String = dr("ParNo").ToString().Trim()
                        Dim pcs As Double = Convert.ToDouble(dr("Pcs"))
                        Dim cts As Double = Math.Round(Convert.ToDouble(dr("Cts")), ctsRound)
                        Dim price As Double = If(IsDBNull(dr("Price")), 0, Convert.ToDouble(dr("Price")))
                        Dim mainAss As String = dr("MainAssort").ToString().Trim()

                        ' Subtract already packed pcs
                        Dim pkdPcs As Double = 0
                        Dim pkdCts As Double = 0
                        Using cmd2 As New SqlCommand(
                            "SELECT SUM(Pcs) AS P, ROUND(SUM(Cts),3) AS C FROM tblGrading_Box " &
                            "WHERE FM2=1 AND ParNo=@par AND Assortment=@a", dbconn_Prod)
                            cmd2.Parameters.AddWithValue("@par", strParcel)
                            cmd2.Parameters.AddWithValue("@a", assort)
                            Using dr2 As SqlDataReader = cmd2.ExecuteReader()
                                If dr2.Read() AndAlso dr2("P") IsNot DBNull.Value Then
                                    pkdPcs = Convert.ToDouble(dr2("P"))
                                    pkdCts = Convert.ToDouble(dr2("C"))
                                End If
                            End Using
                        End Using

                        Dim netPcs As Double = pcs - pkdPcs
                        Dim netCts As Double = cts - pkdCts

                        If netPcs > 0 Then
                            flxDetails.Rows.Add(
                                assort, parNo,
                                netPcs.ToString(), Format(netCts, If(is2nd, "#0.00", "#0.000")),
                                netPcs.ToString(), Format(netCts, If(is2nd, "#0.00", "#0.000")),
                                "0", Format(price, "#0.00"),
                                Format(price * netCts, "#0.00"),
                                dr("Department").ToString().Trim(), "",
                                "", "", "", "", mainAss, dr("ReturnType3").ToString().Trim()
                            )
                            intIssPcs += netPcs
                            dblIssCts += netCts
                        End If
                    End While
                End Using
            End Using

            ' Load box items (FM2=1)
            Using cmd As New SqlCommand(
                "SELECT b.Assortment, b.Pcs, b.Cts, b.ParNo, sln.Price, " &
                "sln.Color, sln.Clarity, b.PktNo, b.OrderNo " &
                "FROM tblGrading_Box b " &
                "INNER JOIN tblGrading_SizeListNew sln ON b.Assortment=sln.AssortNo " &
                "WHERE b.FM2=1 AND b.ParNo=@par ORDER BY b.Assortment", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", strParcel)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim pcs As Double = Convert.ToDouble(dr("Pcs"))
                        Dim cts As Double = Convert.ToDouble(dr("Cts"))
                        Dim price As Double = If(IsDBNull(dr("Price")), 0, Convert.ToDouble(dr("Price")))

                        flxDetails.Rows.Add(
                            dr("Assortment").ToString().Trim(),
                            dr("ParNo").ToString().Trim(),
                            pcs.ToString(), Format(cts, "#0.000"),
                            pcs.ToString(), Format(cts, "#0.000"),
                            "0", Format(price, "#0.00"),
                            Format(price * cts, "#0.00"),
                            strDept, "", dr("OrderNo").ToString().Trim(),
                            dr("PktNo").ToString().Trim(),
                            dr("Color").ToString().Trim(),
                            dr("Clarity").ToString().Trim(),
                            "ZFOREVERMARK", ""
                        )
                        intIssPcs += pcs
                        dblIssCts += cts
                    End While
                End Using
            End Using

            dblIssCts = Math.Round(dblIssCts, ctsRound)
            txtAddPcs.Text = intIssPcs.ToString()
            txtPcs.Text = intIssPcs.ToString()
            txtAddCts.Text = Format(dblIssCts, If(is2nd, "#0.00", "#0.000"))
            txtCts.Text = Format(dblIssCts, If(is2nd, "#0.00", "#0.000"))

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummary", "Load_ExportDetails")
        End Try
    End Sub


    Private Sub txtPackNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPackNo.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If txtPackNo.Text.Trim() <> "" Then Load_PackingList()
        End If
    End Sub

    Private Sub Load_PackingList()
        Try
            flxDetails.Rows.Clear()
            Dim intIssPcs As Double = 0
            Dim dblIssCts As Double = 0
            Dim intActPcs As Double = 0
            Dim dblActCts As Double = 0
            Dim is2nd As Boolean = opt2.Checked
            Dim ctsRound As Integer = If(is2nd, 2, 3)

            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_PackingList WHERE PackNo=@pn ORDER BY Code, Assortment",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@pn", CInt(txtPackNo.Text))
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    Dim first As Boolean = True
                    While dr.Read()
                        If first Then
                            chkComplete.Checked = (dr("OK").ToString() <> "0")
                            first = False
                        End If
                        Dim pcs As Double = Convert.ToDouble(dr("Pcs"))
                        Dim cts As Double = Convert.ToDouble(dr("Cts"))
                        Dim actPcs As Double = Convert.ToDouble(dr("ActPcs"))
                        Dim actCts As Double = Convert.ToDouble(dr("ActCts"))
                        Dim price As Double = If(IsDBNull(dr("Price")), 0, Convert.ToDouble(dr("Price")))

                        flxDetails.Rows.Add(
                            dr("Assortment").ToString().Trim(),
                            dr("ParNo").ToString().Trim(),
                            pcs.ToString(), Format(cts, If(is2nd, "#0.00", "#0.000")),
                            actPcs.ToString(), Format(actCts, If(is2nd, "#0.00", "#0.000")),
                            Format(Math.Round(cts - actCts, ctsRound), "#0.000"),
                            Format(price, "#0.00"),
                            Format(price * actCts, "#0.00"),
                            dr("Department").ToString().Trim(),
                            dr("ID").ToString().Trim(),
                            dr("OrderNo").ToString().Trim(),
                            dr("PktNo").ToString().Trim(),
                            dr("Color").ToString().Trim(),
                            dr("Clarity").ToString().Trim(),
                            dr("Code").ToString().Trim(),
                            dr("SizeRange").ToString().Trim()
                        )
                        intIssPcs += pcs : intActPcs += actPcs
                        dblIssCts += cts : dblActCts += actCts
                    End While
                End Using
            End Using

            txtAddPcs.Text = intIssPcs.ToString()
            txtPcs.Text = intActPcs.ToString()
            txtAddCts.Text = Format(Math.Round(dblIssCts, ctsRound), "#0.000")
            txtCts.Text = Format(Math.Round(dblActCts, ctsRound), "#0.000")

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummary", "Load_PackingList")
        End Try
    End Sub


    Private Function CalTotalPcs() As Double
        Dim total As Double = 0
        For Each row As DataGridViewRow In flxDetails.Rows
            total += Convert.ToDouble(If(row.Cells("ActPcs").Value?.ToString() = "", "0", row.Cells("ActPcs").Value?.ToString()))
        Next
        Return total
    End Function

    Private Function CalTotalCts() As Double
        Dim total As Double = 0
        Dim is2nd As Boolean = opt2.Checked
        For Each row As DataGridViewRow In flxDetails.Rows
            Dim actCts As Double = Convert.ToDouble(If(row.Cells("ActCts").Value?.ToString() = "", "0", row.Cells("ActCts").Value?.ToString()))
            Dim cts As Double = Convert.ToDouble(If(row.Cells("Cts").Value?.ToString() = "", "0", row.Cells("Cts").Value?.ToString()))
            Dim price As Double = Convert.ToDouble(If(row.Cells("Price").Value?.ToString() = "", "0", row.Cells("Price").Value?.ToString()))
            row.Cells("Diff").Value = Format(Math.Round(cts - actCts, If(is2nd, 2, 3)), "#0.000")
            row.Cells("Value").Value = Format(price * actCts, "#0.00")
            total += actCts
        Next
        Return Math.Round(total, If(is2nd, 2, 3))
    End Function


    Private Sub flxDetails_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellEndEdit
        If flxDetails.Columns(e.ColumnIndex).Name = "ActCts" Then
            txtPcs.Text = CalTotalPcs().ToString()
            txtCts.Text = Format(CalTotalCts(), "#0.000")
        End If
    End Sub
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If txtPackNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Package No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If flxDetails.Rows.Count < 1 Then
                MessageBox.Show("No Records", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Convert.ToDouble(txtAddPcs.Text) <> Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Pcs not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Check if exists
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_PackingList WHERE PackNo=@pn", dbconn_Prod)
                cmd.Parameters.AddWithValue("@pn", CInt(txtPackNo.Text))
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If exists Then
                If MessageBox.Show("Are you sure to update?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                For Each row As DataGridViewRow In flxDetails.Rows
                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_PackingList SET ActPcs=@pcs, ActCts=@cts WHERE ID=@id",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("ActPcs").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("ActCts").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@id", Convert.ToDouble(row.Cells("ID").Value?.ToString()))
                        cmd.ExecuteNonQuery()
                    End Using
                Next
                MessageBox.Show("Updated Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If MessageBox.Show("Are you sure to save?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                For Each row As DataGridViewRow In flxDetails.Rows
                    Using cmd As New SqlCommand(
                        "INSERT INTO tblGrading_PackingList(Department,PackNo,Assortment,ParNo,Pcs,Cts,ActPcs,ActCts,Price,OrderNo,PktNo,Color,Clarity,Code,SizeRange) " &
                        "VALUES(@dept,@pn,@assort,@parno,@pcs,@cts,@apcs,@acts,@price,@order,@pkt,@color,@clarity,@code,@size)",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@dept", row.Cells("Dept").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@pn", CInt(txtPackNo.Text))
                        cmd.Parameters.AddWithValue("@assort", row.Cells("Assortment").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@parno", row.Cells("ParNo").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@apcs", Convert.ToDouble(row.Cells("ActPcs").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@acts", Convert.ToDouble(row.Cells("ActCts").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@order", row.Cells("OrderNo").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@pkt", row.Cells("PktNo").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@color", row.Cells("Color").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@clarity", row.Cells("Clarity").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@code", row.Cells("Code").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@size", row.Cells("SizeRange").Value?.ToString().Trim())
                        cmd.ExecuteNonQuery()
                    End Using

                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_SizingTypes SET OK=1 " &
                        "WHERE Department=@dept AND LEFT(ParNo,6)=@parno AND OK=0",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@dept", row.Cells("Dept").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@parno", row.Cells("ParNo").Value?.ToString().Trim())
                        cmd.ExecuteNonQuery()
                    End Using
                Next
                MessageBox.Show("Saved Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            ' Reset
            flxDetails.Rows.Clear()
            txtAddPcs.Text = "0" : txtAddCts.Text = "0"
            txtPcs.Text = "0" : txtCts.Text = "0"
            GetPackNo()
            cmbParcel.SelectedIndex = -1
            Load_ExportParcels()

        Catch ex As Exception
            MessageBox.Show("Save error: " & ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub


    Private Sub cmdUpdate_Click(sender As Object, e As EventArgs) Handles cmdUpdate.Click
        Try
            If txtPackNo.Text.Trim() = "" Then Return
            Dim okVal As Integer = If(chkComplete.Checked, 1, 0)
            Using cmd As New SqlCommand(
                "UPDATE tblGrading_PackingList SET Ok=@ok WHERE PackNo=@pn", dbconn_Prod)
                cmd.Parameters.AddWithValue("@ok", okVal)
                cmd.Parameters.AddWithValue("@pn", CInt(txtPackNo.Text))
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Package Updated", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummary", "cmdUpdate_Click")
        End Try
    End Sub


    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        GetPackNo()
        txtAddPcs.Text = "0" : txtAddCts.Text = "0"
        txtPcs.Text = "0" : txtCts.Text = "0"
        flxDetails.Rows.Clear()
        chkComplete.Checked = False
    End Sub

    Private Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
        GetPackNo()
        Load_ExportParcels()
    End Sub

    Private Sub cmdExcel_Click(sender As Object, e As EventArgs) Handles cmdExcel.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "Excel Files (*.xls)|*.xls"
                dlg.FileName = "Package_" & txtPackNo.Text & ".xls"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportGridToFile(dlg.FileName, vbTab)
                    ShellEx(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub btnExportCSV_Click(sender As Object, e As EventArgs) Handles btnExportCSV.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "CSV Files (*.csv)|*.csv"
                dlg.FileName = "Package_" & txtPackNo.Text & ".csv"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportGridToFile(dlg.FileName, ",")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub ExportGridToFile(filePath As String, delimiter As String)
        Dim sb As New StringBuilder()
        Dim hdrs As New List(Of String)
        For Each col As DataGridViewColumn In flxDetails.Columns
            hdrs.Add(col.HeaderText)
        Next
        sb.AppendLine(String.Join(delimiter, hdrs))
        For Each row As DataGridViewRow In flxDetails.Rows
            Dim cols As New List(Of String)
            For Each cell As DataGridViewCell In row.Cells
                cols.Add(cell.Value?.ToString())
            Next
            sb.AppendLine(String.Join(delimiter, cols))
        Next
        File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class

'── Helper class for parcel combo ──────────────────────────────────
Public Class ParcelItem
    Public Property ParNo As String
    Public Property Department As String
    Public Sub New(parNo As String, dept As String)
        Me.ParNo = parNo
        Me.Department = dept
    End Sub
    Public Overrides Function ToString() As String
        Return ParNo & "  (" & Department & ")"
    End Function
End Class