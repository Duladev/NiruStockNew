﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Text

Public Class frm_Grading_Export

    ' FORM LOAD
    Private Sub frm_Grading_Export_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
        Catch ex As Exception
            ErrorLog("frm_Grading_Export", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.ReadOnly = True
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("Tahoma", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim headers() As String = {"Lot No", "Assortment", "Pcs", "Cts", "Price", "Value", "Pack No", "Size Range", "Country", "Make"}
        Dim names() As String = {"LotNo", "Assortment", "Pcs", "Cts", "Price", "Value", "PackNo", "SizeRange", "Country", "Make"}
        Dim widths() As Integer = {100, 120, 60, 75, 70, 80, 70, 100, 70, 80}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            If idx >= 2 AndAlso idx <= 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    ' PARCEL/LOT NO — ENTER KEY
    Private Sub txtParNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Get_PackingList()
        End If
    End Sub

    ' LOAD PACKING LIST DATA
    Private Sub Get_PackingList()
        Try
            flxDetails.Rows.Clear()
            txtPcs.Text = ""
            txtCts.Text = ""
            txtValue.Text = ""

            Dim dblPcs As Double = 0
            Dim dblCts As Double = 0
            Dim dblValue As Double = 0

            Dim sql As String

            If optParcel.Checked Then
                sql = "SELECT TOP (100) PERCENT vp.ParcelID AS LotNo, st.ReturnType2 AS Assortment, " &
                      "st.ReturnType3 AS SizeRange, SUM(st.Pcs) AS Pcs, ROUND(SUM(st.Cts),3) AS Cts, " &
                      "ISNULL(sln.Price, sl.Price) AS Price " &
                      "FROM tblGrading_SizingTypes st " &
                      "INNER JOIN VW_RealParcel vp ON st.ParNo = vp.ParcelNo " &
                      "LEFT JOIN tblGrading_SizeList sl ON st.ReturnType2 = sl.AssortNo " &
                      "LEFT JOIN tblGrading_SizeListNew sln ON st.ReturnType2 = sln.AssortNo " &
                      "WHERE vp.ParcelID = @parno " &
                      "GROUP BY vp.ParcelID, st.ReturnType2, st.ReturnType3, sln.Price, sl.Price " &
                      "ORDER BY vp.ParcelID, st.ReturnType2"
            Else
                sql = "SELECT TOP (100) PERCENT LotNo, PackNo, Assortment, SizeRange, " &
                      "SUM(Pcs) AS Pcs, ROUND(SUM(Cts),3) AS Cts, Price, ROUND(SUM(Price*Cts),2) AS Value " &
                      "FROM tblGrading_PackingListM " &
                      "WHERE LotNo = @parno " &
                      "GROUP BY LotNo, PackNo, Assortment, Price, SizeRange " &
                      "ORDER BY Assortment"
            End If

            Using cmd As New SqlCommand(sql, dbconn_Prod)
                cmd.Parameters.AddWithValue("@parno", txtParNo.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim assortment As String = dr("Assortment").ToString().Trim()
                        Dim sizeRange As String = dr("SizeRange").ToString().Trim()
                        Dim pcs As Double = Convert.ToDouble(dr("Pcs"))
                        Dim cts As Double = Math.Round(Convert.ToDouble(dr("Cts")), 3)
                        Dim price As Double = If(IsDBNull(dr("Price")), 0, Convert.ToDouble(dr("Price")))
                        Dim value As Double = Math.Round(cts * price, 2)
                        Dim packNo As String = If(dr.GetOrdinal("PackNo") >= 0 AndAlso Not IsDBNull(dr("PackNo")), dr("PackNo").ToString().Trim(), "")
                        Dim lotNo As String = dr("LotNo").ToString().Trim()

                        ' Look up country
                        Dim country As String = "SL"
                        Dim make As String = ""

                        Using cmd2 As New SqlCommand(
                            "SELECT Country FROM VW_DCLPermanentsT WHERE ItemName=@a AND SizeRange=@s",
                            dbconn_Prod)
                            cmd2.Parameters.AddWithValue("@a", assortment)
                            cmd2.Parameters.AddWithValue("@s", sizeRange)
                            Dim res = cmd2.ExecuteScalar()
                            If res IsNot Nothing Then country = res.ToString().Trim()
                        End Using

                        Using cmd3 As New SqlCommand(
                            "SELECT Make FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                            dbconn_Prod)
                            cmd3.Parameters.AddWithValue("@a", assortment)
                            Dim res = cmd3.ExecuteScalar()
                            If res IsNot Nothing Then make = res.ToString().Trim()
                        End Using

                        flxDetails.Rows.Add(
                            lotNo, assortment,
                            pcs.ToString(),
                            Format(cts, "#0.000"),
                            Format(price, "#0.00"),
                            Format(value, "#0.00"),
                            packNo, sizeRange, country, make
                        )

                        dblPcs += pcs
                        dblCts += cts
                        dblValue += value
                    End While
                End Using
            End Using

            txtPcs.Text = dblPcs.ToString()
            txtCts.Text = Format(Math.Round(dblCts, 3), "#0.000")
            txtValue.Text = Format(Math.Round(dblValue, 2), "#0.00")

        Catch ex As Exception
            ErrorLog("frm_Grading_Export", "Get_PackingList")
        End Try
    End Sub

    ' EXPORT TO EXCEL
    Private Sub cmdExport_Click(sender As Object, e As EventArgs) Handles cmdExport.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "Excel Files (*.xls)|*.xls"
                dlg.FileName = "PackingList_" & txtParNo.Text.Trim() & ".xls"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportToExcel(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    Private Sub ExportToExcel(filePath As String)
        Dim sb As New StringBuilder()

        ' Headers
        For Each col As DataGridViewColumn In flxDetails.Columns
            sb.Append(col.HeaderText & vbTab)
        Next
        sb.AppendLine()

        ' Data
        For Each row As DataGridViewRow In flxDetails.Rows
            For Each cell As DataGridViewCell In row.Cells
                sb.Append(cell.Value?.ToString() & vbTab)
            Next
            sb.AppendLine()
        Next

        File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8)
        ShellEx(filePath)
        MessageBox.Show("Exported successfully to:" & vbCrLf & filePath, Me.Text,
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    ' EXPORT TO CSV
    Private Sub btnExportCSV_Click(sender As Object, e As EventArgs) Handles btnExportCSV.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "CSV Files (*.csv)|*.csv"
                dlg.FileName = "PackingList_" & txtParNo.Text.Trim() & ".csv"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportToCSV(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    Private Sub ExportToCSV(filePath As String)
        Dim sb As New StringBuilder()

        ' Headers
        Dim headerCols As New List(Of String)
        For Each col As DataGridViewColumn In flxDetails.Columns
            headerCols.Add("""" & col.HeaderText & """")
        Next
        sb.AppendLine(String.Join(",", headerCols))

        ' Data
        For Each row As DataGridViewRow In flxDetails.Rows
            Dim rowCols As New List(Of String)
            For Each cell As DataGridViewCell In row.Cells
                rowCols.Add("""" & cell.Value?.ToString().Replace("""", """""") & """")
            Next
            sb.AppendLine(String.Join(",", rowCols))
        Next

        File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8)
        MessageBox.Show("CSV exported successfully to:" & vbCrLf & filePath, Me.Text,
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    ' EXIT
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class