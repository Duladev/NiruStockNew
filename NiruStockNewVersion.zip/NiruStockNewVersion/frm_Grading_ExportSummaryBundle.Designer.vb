﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_ExportSummaryBundle
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)
        Dim fntBold As New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlRow1 = New System.Windows.Forms.Panel()
        Me.lblBundleNo = New System.Windows.Forms.Label()
        Me.txtBundleNo = New System.Windows.Forms.TextBox()
        Me.lblTotPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.cmdExcel = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pnlRow2 = New System.Windows.Forms.Panel()
        Me.lblAssort = New System.Windows.Forms.Label()
        Me.cmbAssort = New System.Windows.Forms.ComboBox()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.lblNewPcs = New System.Windows.Forms.Label()
        Me.txtNewPcs = New System.Windows.Forms.TextBox()
        Me.lblNewCts = New System.Windows.Forms.Label()
        Me.txtNewCts = New System.Windows.Forms.TextBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.lblTotPcsB = New System.Windows.Forms.Label()
        Me.txtTotPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCtsB = New System.Windows.Forms.Label()
        Me.txtTotCts = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "BUNDLE PACKAGES"
        Me.Size = New System.Drawing.Size(920, 680)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "BUNDLE PACKAGES"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Row 1 ──────────────────────────────────────────────
        Me.pnlRow1.Location = New System.Drawing.Point(0, 35)
        Me.pnlRow1.Size = New System.Drawing.Size(914, 40)
        Me.pnlRow1.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.lblBundleNo.Text = "Bundle No." : Me.lblBundleNo.Font = fntBold : Me.lblBundleNo.Location = New System.Drawing.Point(5, 5) : Me.lblBundleNo.Size = New System.Drawing.Size(80, 18) : Me.lblBundleNo.BackColor = System.Drawing.Color.Transparent
        Me.txtBundleNo.Location = New System.Drawing.Point(5, 22) : Me.txtBundleNo.Size = New System.Drawing.Size(80, 22) : Me.txtBundleNo.Font = fnt

        Me.lblTotPcs.Text = "Total Pcs" : Me.lblTotPcs.Font = fntBold : Me.lblTotPcs.Location = New System.Drawing.Point(95, 5) : Me.lblTotPcs.Size = New System.Drawing.Size(65, 18) : Me.lblTotPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPcs.Location = New System.Drawing.Point(95, 22) : Me.txtPcs.Size = New System.Drawing.Size(70, 22) : Me.txtPcs.Font = fnt : Me.txtPcs.ReadOnly = True : Me.txtPcs.TextAlign = HorizontalAlignment.Right : Me.txtPcs.Text = "0"

        Me.lblTotCts.Text = "Total Cts" : Me.lblTotCts.Font = fntBold : Me.lblTotCts.Location = New System.Drawing.Point(175, 5) : Me.lblTotCts.Size = New System.Drawing.Size(65, 18) : Me.lblTotCts.BackColor = System.Drawing.Color.Transparent
        Me.txtCts.Location = New System.Drawing.Point(175, 22) : Me.txtCts.Size = New System.Drawing.Size(80, 22) : Me.txtCts.Font = fnt : Me.txtCts.ReadOnly = True : Me.txtCts.TextAlign = HorizontalAlignment.Right : Me.txtCts.Text = "0"

        Dim btns() As System.Windows.Forms.Button = {Me.cmdRefresh, Me.cmdExcel, Me.cmdNew, Me.cmdSave, Me.btnExit}
        Dim btnTxt() As String = {"Refresh", "Excel", "New", "Save", "Exit"}
        Dim btnClr() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxt(idx)
            btns(idx).Location = New System.Drawing.Point(470 + idx * 88, 12)
            btns(idx).Size = New System.Drawing.Size(80, 22)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnClr(idx)
            Me.pnlRow1.Controls.Add(btns(idx))
        Next
        Me.pnlRow1.Controls.AddRange({Me.lblBundleNo, Me.txtBundleNo, Me.lblTotPcs, Me.txtPcs, Me.lblTotCts, Me.txtCts})

        '── Row 2 ──────────────────────────────────────────────
        Me.pnlRow2.Location = New System.Drawing.Point(0, 75)
        Me.pnlRow2.Size = New System.Drawing.Size(914, 38)
        Me.pnlRow2.BackColor = System.Drawing.Color.FromArgb(245, 245, 245)

        Me.lblAssort.Text = "Assortment" : Me.lblAssort.Font = fntBold : Me.lblAssort.Location = New System.Drawing.Point(5, 3) : Me.lblAssort.Size = New System.Drawing.Size(85, 18) : Me.lblAssort.BackColor = System.Drawing.Color.Transparent
        Me.cmbAssort.Location = New System.Drawing.Point(5, 18) : Me.cmbAssort.Size = New System.Drawing.Size(150, 22) : Me.cmbAssort.Font = fnt : Me.cmbAssort.DropDownStyle = ComboBoxStyle.DropDown

        Me.lblSize.Text = "Size Range" : Me.lblSize.Font = fntBold : Me.lblSize.Location = New System.Drawing.Point(165, 3) : Me.lblSize.Size = New System.Drawing.Size(80, 18) : Me.lblSize.BackColor = System.Drawing.Color.Transparent
        Me.cmbSize.Location = New System.Drawing.Point(165, 18) : Me.cmbSize.Size = New System.Drawing.Size(100, 22) : Me.cmbSize.Font = fnt : Me.cmbSize.DropDownStyle = ComboBoxStyle.DropDown

        Me.lblNewPcs.Text = "Pcs" : Me.lblNewPcs.Font = fntBold : Me.lblNewPcs.Location = New System.Drawing.Point(275, 3) : Me.lblNewPcs.Size = New System.Drawing.Size(40, 18) : Me.lblNewPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtNewPcs.Location = New System.Drawing.Point(275, 18) : Me.txtNewPcs.Size = New System.Drawing.Size(60, 22) : Me.txtNewPcs.Font = fnt

        Me.lblNewCts.Text = "Cts" : Me.lblNewCts.Font = fntBold : Me.lblNewCts.Location = New System.Drawing.Point(345, 3) : Me.lblNewCts.Size = New System.Drawing.Size(40, 18) : Me.lblNewCts.BackColor = System.Drawing.Color.Transparent
        Me.txtNewCts.Location = New System.Drawing.Point(345, 18) : Me.txtNewCts.Size = New System.Drawing.Size(75, 22) : Me.txtNewCts.Font = fnt

        Me.cmdAdd.Text = "Add" : Me.cmdAdd.Location = New System.Drawing.Point(430, 15) : Me.cmdAdd.Size = New System.Drawing.Size(60, 24) : Me.cmdAdd.Font = fnt : Me.cmdAdd.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.pnlRow2.Controls.AddRange({Me.lblAssort, Me.cmbAssort, Me.lblSize, Me.cmbSize, Me.lblNewPcs, Me.txtNewPcs, Me.lblNewCts, Me.txtNewCts, Me.cmdAdd})

        '── Grid ───────────────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 118)
        Me.flxDetails.Size = New System.Drawing.Size(904, 510)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        '── Totals ─────────────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 633)
        Me.pnlTotals.Size = New System.Drawing.Size(914, 30)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.lblTotPcsB.Text = "Act Pcs:" : Me.lblTotPcsB.Font = fntBold : Me.lblTotPcsB.Location = New System.Drawing.Point(220, 6) : Me.lblTotPcsB.Size = New System.Drawing.Size(60, 18) : Me.lblTotPcsB.BackColor = System.Drawing.Color.Transparent
        Me.txtTotPcs.Location = New System.Drawing.Point(285, 4) : Me.txtTotPcs.Size = New System.Drawing.Size(70, 22) : Me.txtTotPcs.Font = fntBold : Me.txtTotPcs.ReadOnly = True : Me.txtTotPcs.TextAlign = HorizontalAlignment.Right : Me.txtTotPcs.Text = "0"

        Me.lblTotCtsB.Text = "Act Cts:" : Me.lblTotCtsB.Font = fntBold : Me.lblTotCtsB.Location = New System.Drawing.Point(365, 6) : Me.lblTotCtsB.Size = New System.Drawing.Size(60, 18) : Me.lblTotCtsB.BackColor = System.Drawing.Color.Transparent
        Me.txtTotCts.Location = New System.Drawing.Point(430, 4) : Me.txtTotCts.Size = New System.Drawing.Size(80, 22) : Me.txtTotCts.Font = fntBold : Me.txtTotCts.ReadOnly = True : Me.txtTotCts.TextAlign = HorizontalAlignment.Right : Me.txtTotCts.Text = "0"

        Me.pnlTotals.Controls.AddRange({Me.lblTotPcsB, Me.txtTotPcs, Me.lblTotCtsB, Me.txtTotCts})

        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlRow1)
        Me.Controls.Add(Me.pnlRow2)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlRow1 As System.Windows.Forms.Panel
    Friend WithEvents lblBundleNo As System.Windows.Forms.Label
    Friend WithEvents txtBundleNo As System.Windows.Forms.TextBox
    Friend WithEvents lblTotPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents cmdExcel As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents pnlRow2 As System.Windows.Forms.Panel
    Friend WithEvents lblAssort As System.Windows.Forms.Label
    Friend WithEvents cmbAssort As System.Windows.Forms.ComboBox
    Friend WithEvents lblSize As System.Windows.Forms.Label
    Friend WithEvents cmbSize As System.Windows.Forms.ComboBox
    Friend WithEvents lblNewPcs As System.Windows.Forms.Label
    Friend WithEvents txtNewPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblNewCts As System.Windows.Forms.Label
    Friend WithEvents txtNewCts As System.Windows.Forms.TextBox
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents lblTotPcsB As System.Windows.Forms.Label
    Friend WithEvents txtTotPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCtsB As System.Windows.Forms.Label
    Friend WithEvents txtTotCts As System.Windows.Forms.TextBox

End Class