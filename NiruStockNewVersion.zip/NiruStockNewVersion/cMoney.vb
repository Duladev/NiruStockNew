﻿''' <summary>
''' Converts a numeric monetary value into its word representation.
''' Example: 1525.50 → "One Thousand Five Hundred Twenty-Five and Fifty Cents"
''' </summary>
Public Class cMoney

    Private m_19AndUnder() As String
    Private m_Tens() As String
    Private m_Hundred As String
    Private m_Groups() As String
    Private m_Dollar As String
    Private m_Dollars As String
    Private m_Cent As String
    Private m_Cents As String
    Private m_Hyphen As String
    Private m_And As String
    Private m_InvalidAmount As String

    Public Sub New()
        ' ── Number words ───────────────────────────────────────
        m_19AndUnder = New String() {
            "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven",
            "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen",
            "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
        }

        m_Tens = New String() {
            "", "", "Twenty", "Thirty", "Forty", "Fifty",
            "Sixty", "Seventy", "Eighty", "Ninety"
        }

        m_Hundred = "Hundred"

        m_Groups = New String() {
            "", "", "Thousand", "Million", "Billion", "Trillion",
            "Quadrillion", "Quintillion", "Sextillion", "Septillion", "Octillion"
        }

        ' ── Currency labels ────────────────────────────────────
        m_Dollar = " Rupee"
        m_Dollars = " Rupees"
        m_Cent = " Cent"
        m_Cents = " Cents"
        m_Hyphen = "-"
        m_And = " and "
        m_InvalidAmount = "Invalid Amount."
    End Sub

    ''' <summary>
    ''' Main entry point. Pass a numeric value, get back words.
    ''' </summary>
    Public Function MonetaryToWords(ByVal value As Object) As String
        Try
            Dim decValue As Decimal = Convert.ToDecimal(value)
            If decValue < 0 Then Return m_InvalidAmount

            Dim sValue As String = decValue.ToString("0.##")
            Dim dotPos As Integer = sValue.IndexOf("."c)

            Dim sDollars As String
            Dim sCents As String

            If dotPos < 0 Then
                sDollars = sValue
                sCents = "00"
            Else
                sDollars = sValue.Substring(0, dotPos)
                sCents = sValue.Substring(dotPos + 1)
                If sCents.Length > 2 Then Return m_InvalidAmount
                sCents = (sCents & "00").Substring(0, 2)
            End If

            Select Case sCents
                Case "00"
                    Return DollarsToWords(sDollars)
                Case "01"
                    Return DollarsToWords(sDollars) & m_And & sCents & m_Cent
                Case Else
                    Return DollarsToWords(sDollars) & m_And & DollarsToWords(sCents) & m_Cents
            End Select

        Catch
            Return m_InvalidAmount
        End Try
    End Function

    ' ── Internal: convert whole number string to words ─────────
    Private Function DollarsToWords(sDollars As String) As String
        If Not IsNumeric(sDollars) Then Return m_InvalidAmount

        Dim decValue As Decimal = Convert.ToDecimal(sDollars)

        Select Case decValue
            Case 0 : Return m_19AndUnder(0)
            Case 1 : Return m_19AndUnder(1)
        End Select

        Dim sWords As String = ""
        Dim sRemaining As String = sDollars.TrimStart("0"c)
        If sRemaining = "" Then sRemaining = "0"

        Dim iGroup As Integer = 0

        Do While sRemaining.Length > 0
            iGroup += 1

            Dim s3 As String
            If sRemaining.Length > 3 Then
                s3 = sRemaining.Substring(sRemaining.Length - 3)
                sRemaining = sRemaining.Substring(0, sRemaining.Length - 3)
            Else
                s3 = sRemaining.PadLeft(3, "0"c)
                sRemaining = ""
            End If

            If s3 <> "000" Then
                Dim i100 As Integer = CInt(s3.Substring(0, 1))
                Dim i10 As Integer = CInt(s3.Substring(1, 1))
                Dim i1 As Integer = CInt(s3.Substring(2, 1))
                Dim i99 As Integer = (i10 * 10) + i1

                Dim sWork As String = ""
                If iGroup > 1 AndAlso iGroup <= m_Groups.Length - 1 Then
                    sWork = " " & m_Groups(iGroup)
                End If

                If i10 > 1 Then
                    sWork = If(i1 > 0,
                               m_Tens(i10) & m_Hyphen & m_19AndUnder(i1),
                               m_Tens(i10)) & sWork
                ElseIf i99 > 0 Then
                    sWork = m_19AndUnder(i99) & sWork
                End If

                If i100 > 0 Then
                    sWork = m_19AndUnder(i100) & " " & m_Hundred & " " & sWork
                End If

                sWords = sWork.Trim() & " " & sWords
            End If
        Loop

        Return sWords.Trim()
    End Function

End Class