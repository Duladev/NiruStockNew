﻿Public Class frm_Grading_Parcels

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frm_Grading_Parcels_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_Parcels()
        Catch ex As Exception
            ErrorLog("frm_Grading_Parcels", "Form_Load")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SETUP GRID
    '──────────────────────────────────────────────────────────────
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("Tahoma", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)
        flxDetails.RowTemplate.Height = 22

        ' Checkbox column for "Complete"
        Dim chkCol As New DataGridViewCheckBoxColumn()
        chkCol.HeaderText = "Complete"
        chkCol.Name = "Complete"
        chkCol.Width = 70
        flxDetails.Columns.Add(chkCol)

        ' Text columns
        Dim headers() As String = {"Parcel No", "Date", "Ret Pcs", "Ret Cts"}
        Dim names() As String = {"ParNo", "ParDate", "RetPcs", "RetCts"}
        Dim widths() As Integer = {120, 100, 80, 80}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = True
            If idx >= 2 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD PARCELS
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Parcels()
        Try
            flxDetails.Rows.Clear()

            Dim sql As String =
                "SELECT TOP (100) PERCENT p.ParNo, p.SystemDateTime, " &
                "SUM(st.Pcs) AS Pcs, ROUND(SUM(st.Cts), 3) AS Cts " &
                "FROM tblGrading_Parcel p " &
                "INNER JOIN tblGrading_SizingTypes st ON p.ParNo = st.ParNo " &
                "WHERE p.Complete = 0 " &
                "GROUP BY p.ParNo, p.SystemDateTime " &
                "ORDER BY p.ParNo"

            Using cmd As New SqlCommand(sql, dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim rowIdx As Integer = flxDetails.Rows.Add()
                        Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                        row.Cells("Complete").Value = False
                        row.Cells("ParNo").Value = dr("ParNo").ToString().Trim()
                        row.Cells("ParDate").Value = Convert.ToDateTime(dr("SystemDateTime")).ToString("dd/MM/yyyy")
                        row.Cells("RetPcs").Value = dr("Pcs").ToString()
                        row.Cells("RetCts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                    End While
                End Using
            End Using

            txtRecordCount.Text = "Records : " & flxDetails.Rows.Count

        Catch ex As Exception
            ErrorLog("frm_Grading_Parcels", "Load_Parcels")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SAVE — MARK CHECKED ROWS AS COMPLETE
    '──────────────────────────────────────────────────────────────
    Private Sub Save()
        Try
            Dim blnSave As Boolean = False

            For Each row As DataGridViewRow In flxDetails.Rows
                Dim isChecked As Boolean = Convert.ToBoolean(row.Cells("Complete").Value)
                If isChecked Then
                    Dim parNo As String = row.Cells("ParNo").Value?.ToString().Trim()

                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_Parcel SET Complete=1, ExportDate=@date WHERE ParNo=@par",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@date", Date.Now.ToString("MM/dd/yyyy"))
                        cmd.Parameters.AddWithValue("@par", parNo)
                        cmd.ExecuteNonQuery()
                    End Using

                    Using cmd As New SqlCommand(
                        "UPDATE tblInvoice SET Export=1 WHERE ParcelNo=@par",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@par", parNo)
                        cmd.ExecuteNonQuery()
                    End Using

                    blnSave = True
                End If
            Next

            If blnSave Then
                MessageBox.Show("Parcels marked as complete successfully.", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Load_Parcels()
            Else
                MessageBox.Show("No parcels selected. Please check the Complete checkbox for parcels to save.",
                                Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            ErrorLog("frm_Grading_Parcels", "Save")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' TOOLBAR BUTTONS
    '──────────────────────────────────────────────────────────────
    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Load_Parcels()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Save()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SELECT ALL / DESELECT ALL
    '──────────────────────────────────────────────────────────────
    Private Sub btnSelectAll_Click(sender As Object, e As EventArgs) Handles btnSelectAll.Click
        For Each row As DataGridViewRow In flxDetails.Rows
            row.Cells("Complete").Value = True
        Next
    End Sub

    Private Sub btnDeselectAll_Click(sender As Object, e As EventArgs) Handles btnDeselectAll.Click
        For Each row As DataGridViewRow In flxDetails.Rows
            row.Cells("Complete").Value = False
        Next
    End Sub

End Class