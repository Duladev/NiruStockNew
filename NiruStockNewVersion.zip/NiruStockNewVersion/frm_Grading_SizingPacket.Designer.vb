﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_SizingPacket
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        '── Controls ───────────────────────────────────────────
        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlToolbar = New System.Windows.Forms.Panel()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExcel = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtRecordCount = New System.Windows.Forms.TextBox()

        Me.pnlEntry = New System.Windows.Forms.Panel()

        ' Row 1 — Parcel No, Pkt No, Size Code, Color, Make
        Me.lblParNo = New System.Windows.Forms.Label()
        Me.txtParNo = New System.Windows.Forms.TextBox()
        Me.lblPktNo = New System.Windows.Forms.Label()
        Me.txtPktNo = New System.Windows.Forms.TextBox()
        Me.lblSizeCode = New System.Windows.Forms.Label()
        Me.cmbSizeType = New System.Windows.Forms.ComboBox()
        Me.lblColor = New System.Windows.Forms.Label()
        Me.cmbType1 = New System.Windows.Forms.ComboBox()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.cmbType2 = New System.Windows.Forms.ComboBox()
        Me.lblFluor = New System.Windows.Forms.Label()
        Me.cmbType3 = New System.Windows.Forms.ComboBox()
        Me.lblClarity = New System.Windows.Forms.Label()
        Me.cmbType4 = New System.Windows.Forms.ComboBox()
        Me.lblPcs = New System.Windows.Forms.Label()
        Me.txtPktPcs = New System.Windows.Forms.TextBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtPktCts = New System.Windows.Forms.TextBox()

        ' Row 2 — Balance, Actuals, Packet Type, Add button
        Me.lblBalPcs = New System.Windows.Forms.Label()
        Me.txtBalPcs = New System.Windows.Forms.TextBox()
        Me.lblBalCts = New System.Windows.Forms.Label()
        Me.txtBalCts = New System.Windows.Forms.TextBox()
        Me.lblActPcs = New System.Windows.Forms.Label()
        Me.txtActPcs = New System.Windows.Forms.TextBox()
        Me.lblActCts = New System.Windows.Forms.Label()
        Me.txtActCts = New System.Windows.Forms.TextBox()
        Me.lblPktType = New System.Windows.Forms.Label()
        Me.cmbPktType = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.lblFinPcs = New System.Windows.Forms.Label()

        ' Totals row
        Me.lblTotPcs = New System.Windows.Forms.Label()
        Me.txtTotPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCts = New System.Windows.Forms.Label()
        Me.txtTotCts = New System.Windows.Forms.TextBox()
        Me.lblTPktPcs = New System.Windows.Forms.Label()
        Me.txtTPktPcs = New System.Windows.Forms.TextBox()
        Me.lblTPktCts = New System.Windows.Forms.Label()
        Me.txtTPktCts = New System.Windows.Forms.TextBox()

        ' Grids
        Me.flxType = New System.Windows.Forms.DataGridView()
        Me.flxSelect = New System.Windows.Forms.DataGridView()
        Me.flxDetails = New System.Windows.Forms.DataGridView()

        ' Grid labels
        Me.lblGridType = New System.Windows.Forms.Label()
        Me.lblGridSelect = New System.Windows.Forms.Label()
        Me.lblGridDetails = New System.Windows.Forms.Label()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "Sizing Packet Entry"
        Me.Size = New System.Drawing.Size(1100, 780)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.White

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "Sizing Packet Entry"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Toolbar ────────────────────────────────────────────
        Me.pnlToolbar.Location = New System.Drawing.Point(0, 35)
        Me.pnlToolbar.Size = New System.Drawing.Size(1090, 38)
        Me.pnlToolbar.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Dim btns() As System.Windows.Forms.Button = {Me.btnNew, Me.btnSave, Me.btnExcel, Me.btnExit}
        Dim btnTxts() As String = {"New", "Save", "Excel", "Exit"}
        Dim btnColors() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(235, 183, 157),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxts(idx)
            btns(idx).Location = New System.Drawing.Point(5 + idx * 80, 5)
            btns(idx).Size = New System.Drawing.Size(72, 26)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnColors(idx)
            Me.pnlToolbar.Controls.Add(btns(idx))
        Next

        Me.txtRecordCount.Location = New System.Drawing.Point(700, 7)
        Me.txtRecordCount.Size = New System.Drawing.Size(150, 22)
        Me.txtRecordCount.Font = fnt
        Me.txtRecordCount.ReadOnly = True
        Me.txtRecordCount.TextAlign = HorizontalAlignment.Center
        Me.txtRecordCount.Text = "Record Count"
        Me.pnlToolbar.Controls.Add(Me.txtRecordCount)

        '── Entry Panel ────────────────────────────────────────
        Me.pnlEntry.Location = New System.Drawing.Point(0, 73)
        Me.pnlEntry.Size = New System.Drawing.Size(1090, 120)
        Me.pnlEntry.BackColor = System.Drawing.Color.White

        ' Row 1 labels and controls
        Dim row1Labels() As System.Windows.Forms.Label = {Me.lblParNo, Me.lblPktNo, Me.lblSizeCode, Me.lblColor, Me.lblMake, Me.lblFluor, Me.lblClarity, Me.lblPcs, Me.lblCts}
        Dim row1Texts() As String = {"Parcel No", "Pkt No", "Size Code", "Color", "Make", "Fluorescent", "Clarity", "PCs", "Cts"}
        Dim row1X() As Integer = {5, 135, 200, 320, 440, 560, 700, 835, 925}

        For idx As Integer = 0 To row1Labels.Length - 1
            row1Labels(idx).Text = row1Texts(idx)
            row1Labels(idx).Font = fntBold
            row1Labels(idx).ForeColor = System.Drawing.Color.DarkRed
            row1Labels(idx).Location = New System.Drawing.Point(row1X(idx), 5)
            row1Labels(idx).Size = New System.Drawing.Size(110, 18)
            row1Labels(idx).BackColor = System.Drawing.Color.Transparent
            Me.pnlEntry.Controls.Add(row1Labels(idx))
        Next

        Me.txtParNo.Location = New System.Drawing.Point(5, 24) : Me.txtParNo.Size = New System.Drawing.Size(120, 22) : Me.txtParNo.Font = fnt
        Me.txtPktNo.Location = New System.Drawing.Point(135, 24) : Me.txtPktNo.Size = New System.Drawing.Size(55, 22) : Me.txtPktNo.Font = fnt : Me.txtPktNo.ReadOnly = True
        Me.cmbSizeType.Location = New System.Drawing.Point(200, 24) : Me.cmbSizeType.Size = New System.Drawing.Size(110, 22) : Me.cmbSizeType.Font = fnt : Me.cmbSizeType.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbType1.Location = New System.Drawing.Point(320, 24) : Me.cmbType1.Size = New System.Drawing.Size(110, 22) : Me.cmbType1.Font = fnt : Me.cmbType1.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbType2.Location = New System.Drawing.Point(440, 24) : Me.cmbType2.Size = New System.Drawing.Size(110, 22) : Me.cmbType2.Font = fnt : Me.cmbType2.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbType3.Location = New System.Drawing.Point(560, 24) : Me.cmbType3.Size = New System.Drawing.Size(130, 22) : Me.cmbType3.Font = fnt : Me.cmbType3.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbType4.Location = New System.Drawing.Point(700, 24) : Me.cmbType4.Size = New System.Drawing.Size(125, 22) : Me.cmbType4.Font = fnt : Me.cmbType4.DropDownStyle = ComboBoxStyle.DropDownList
        Me.txtPktPcs.Location = New System.Drawing.Point(835, 24) : Me.txtPktPcs.Size = New System.Drawing.Size(75, 22) : Me.txtPktPcs.Font = fnt
        Me.txtPktCts.Location = New System.Drawing.Point(925, 24) : Me.txtPktCts.Size = New System.Drawing.Size(80, 22) : Me.txtPktCts.Font = fnt

        ' Row 2 — Balance/Actual/Type/Add
        Me.lblBalPcs.Text = "Bal. PCs" : Me.lblBalPcs.Font = fntBold : Me.lblBalPcs.ForeColor = System.Drawing.Color.DarkRed : Me.lblBalPcs.Location = New System.Drawing.Point(5, 55) : Me.lblBalPcs.Size = New System.Drawing.Size(70, 18) : Me.lblBalPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtBalPcs.Location = New System.Drawing.Point(80, 53) : Me.txtBalPcs.Size = New System.Drawing.Size(60, 22) : Me.txtBalPcs.Font = fnt : Me.txtBalPcs.ReadOnly = True

        Me.lblBalCts.Text = "Bal. Cts" : Me.lblBalCts.Font = fntBold : Me.lblBalCts.ForeColor = System.Drawing.Color.DarkRed : Me.lblBalCts.Location = New System.Drawing.Point(150, 55) : Me.lblBalCts.Size = New System.Drawing.Size(70, 18) : Me.lblBalCts.BackColor = System.Drawing.Color.Transparent
        Me.txtBalCts.Location = New System.Drawing.Point(225, 53) : Me.txtBalCts.Size = New System.Drawing.Size(70, 22) : Me.txtBalCts.Font = fnt : Me.txtBalCts.ReadOnly = True

        Me.lblActPcs.Text = "Act. PCs" : Me.lblActPcs.Font = fntBold : Me.lblActPcs.ForeColor = System.Drawing.Color.DarkGreen : Me.lblActPcs.Location = New System.Drawing.Point(310, 55) : Me.lblActPcs.Size = New System.Drawing.Size(70, 18) : Me.lblActPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtActPcs.Location = New System.Drawing.Point(385, 53) : Me.txtActPcs.Size = New System.Drawing.Size(60, 22) : Me.txtActPcs.Font = fnt : Me.txtActPcs.ReadOnly = True : Me.txtActPcs.Text = "0"

        Me.lblActCts.Text = "Act. Cts" : Me.lblActCts.Font = fntBold : Me.lblActCts.ForeColor = System.Drawing.Color.DarkGreen : Me.lblActCts.Location = New System.Drawing.Point(455, 55) : Me.lblActCts.Size = New System.Drawing.Size(70, 18) : Me.lblActCts.BackColor = System.Drawing.Color.Transparent
        Me.txtActCts.Location = New System.Drawing.Point(530, 53) : Me.txtActCts.Size = New System.Drawing.Size(70, 22) : Me.txtActCts.Font = fnt : Me.txtActCts.ReadOnly = True : Me.txtActCts.Text = "0"

        Me.lblPktType.Text = "Pkt Type" : Me.lblPktType.Font = fntBold : Me.lblPktType.ForeColor = System.Drawing.Color.DarkRed : Me.lblPktType.Location = New System.Drawing.Point(615, 55) : Me.lblPktType.Size = New System.Drawing.Size(70, 18) : Me.lblPktType.BackColor = System.Drawing.Color.Transparent
        Me.cmbPktType.Location = New System.Drawing.Point(690, 53) : Me.cmbPktType.Size = New System.Drawing.Size(60, 22) : Me.cmbPktType.Font = fnt : Me.cmbPktType.DropDownStyle = ComboBoxStyle.DropDownList

        Me.cmdAdd.Text = "<< Add >>"
        Me.cmdAdd.Location = New System.Drawing.Point(770, 50)
        Me.cmdAdd.Size = New System.Drawing.Size(100, 28)
        Me.cmdAdd.Font = fnt
        Me.cmdAdd.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        ' Add all to entry panel
        Me.pnlEntry.Controls.AddRange({
            Me.txtParNo, Me.txtPktNo, Me.cmbSizeType,
            Me.cmbType1, Me.cmbType2, Me.cmbType3, Me.cmbType4,
            Me.txtPktPcs, Me.txtPktCts,
            Me.lblBalPcs, Me.txtBalPcs, Me.lblBalCts, Me.txtBalCts,
            Me.lblActPcs, Me.txtActPcs, Me.lblActCts, Me.txtActCts,
            Me.lblPktType, Me.cmbPktType, Me.cmdAdd
        })

        '── Grid Labels ────────────────────────────────────────
        Me.lblGridType.Text = "Finished Pcs"
        Me.lblGridType.Font = fntBold
        Me.lblGridType.ForeColor = System.Drawing.Color.DarkRed
        Me.lblGridType.Location = New System.Drawing.Point(5, 196)
        Me.lblGridType.Size = New System.Drawing.Size(120, 18)
        Me.lblGridType.BackColor = System.Drawing.Color.Transparent

        Me.lblGridSelect.Text = "Selected Pcs"
        Me.lblGridSelect.Font = fntBold
        Me.lblGridSelect.ForeColor = System.Drawing.Color.DarkRed
        Me.lblGridSelect.Location = New System.Drawing.Point(580, 196)
        Me.lblGridSelect.Size = New System.Drawing.Size(120, 18)
        Me.lblGridSelect.BackColor = System.Drawing.Color.Transparent

        Me.lblGridDetails.Text = "Packeted Pcs"
        Me.lblGridDetails.Font = fntBold
        Me.lblGridDetails.ForeColor = System.Drawing.Color.DarkRed
        Me.lblGridDetails.Location = New System.Drawing.Point(580, 410)
        Me.lblGridDetails.Size = New System.Drawing.Size(120, 18)
        Me.lblGridDetails.BackColor = System.Drawing.Color.Transparent

        '── Grids ──────────────────────────────────────────────
        Me.flxType.Location = New System.Drawing.Point(5, 214)
        Me.flxType.Size = New System.Drawing.Size(560, 520)
        Me.flxType.Font = fnt

        Me.flxSelect.Location = New System.Drawing.Point(575, 214)
        Me.flxSelect.Size = New System.Drawing.Size(510, 185)
        Me.flxSelect.Font = fnt

        Me.flxDetails.Location = New System.Drawing.Point(575, 428)
        Me.flxDetails.Size = New System.Drawing.Size(510, 310)
        Me.flxDetails.Font = fnt

        '── Totals ─────────────────────────────────────────────
        Me.lblTotPcs.Text = "Tot Pcs" : Me.lblTotPcs.Font = fntBold : Me.lblTotPcs.Location = New System.Drawing.Point(5, 742) : Me.lblTotPcs.Size = New System.Drawing.Size(65, 18) : Me.lblTotPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtTotPcs.Location = New System.Drawing.Point(75, 740) : Me.txtTotPcs.Size = New System.Drawing.Size(60, 22) : Me.txtTotPcs.Font = fnt : Me.txtTotPcs.ReadOnly = True : Me.txtTotPcs.Text = "0"

        Me.lblTotCts.Text = "Tot Cts" : Me.lblTotCts.Font = fntBold : Me.lblTotCts.Location = New System.Drawing.Point(145, 742) : Me.lblTotCts.Size = New System.Drawing.Size(65, 18) : Me.lblTotCts.BackColor = System.Drawing.Color.Transparent
        Me.txtTotCts.Location = New System.Drawing.Point(215, 740) : Me.txtTotCts.Size = New System.Drawing.Size(70, 22) : Me.txtTotCts.Font = fnt : Me.txtTotCts.ReadOnly = True : Me.txtTotCts.Text = "0"

        Me.lblTPktPcs.Text = "Pkt Pcs" : Me.lblTPktPcs.Font = fntBold : Me.lblTPktPcs.Location = New System.Drawing.Point(575, 742) : Me.lblTPktPcs.Size = New System.Drawing.Size(65, 18) : Me.lblTPktPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtTPktPcs.Location = New System.Drawing.Point(645, 740) : Me.txtTPktPcs.Size = New System.Drawing.Size(60, 22) : Me.txtTPktPcs.Font = fnt : Me.txtTPktPcs.ReadOnly = True : Me.txtTPktPcs.Text = "0"

        Me.lblTPktCts.Text = "Pkt Cts" : Me.lblTPktCts.Font = fntBold : Me.lblTPktCts.Location = New System.Drawing.Point(715, 742) : Me.lblTPktCts.Size = New System.Drawing.Size(65, 18) : Me.lblTPktCts.BackColor = System.Drawing.Color.Transparent
        Me.txtTPktCts.Location = New System.Drawing.Point(785, 740) : Me.txtTPktCts.Size = New System.Drawing.Size(70, 22) : Me.txtTPktCts.Font = fnt : Me.txtTPktCts.ReadOnly = True : Me.txtTPktCts.Text = "0"

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlToolbar)
        Me.Controls.Add(Me.pnlEntry)
        Me.Controls.Add(Me.lblGridType)
        Me.Controls.Add(Me.lblGridSelect)
        Me.Controls.Add(Me.lblGridDetails)
        Me.Controls.Add(Me.flxType)
        Me.Controls.Add(Me.flxSelect)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.lblTotPcs) : Me.Controls.Add(Me.txtTotPcs)
        Me.Controls.Add(Me.lblTotCts) : Me.Controls.Add(Me.txtTotCts)
        Me.Controls.Add(Me.lblTPktPcs) : Me.Controls.Add(Me.txtTPktPcs)
        Me.Controls.Add(Me.lblTPktCts) : Me.Controls.Add(Me.txtTPktCts)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlToolbar As System.Windows.Forms.Panel
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExcel As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtRecordCount As System.Windows.Forms.TextBox
    Friend WithEvents pnlEntry As System.Windows.Forms.Panel

    Friend WithEvents lblParNo As System.Windows.Forms.Label
    Friend WithEvents txtParNo As System.Windows.Forms.TextBox
    Friend WithEvents lblPktNo As System.Windows.Forms.Label
    Friend WithEvents txtPktNo As System.Windows.Forms.TextBox
    Friend WithEvents lblSizeCode As System.Windows.Forms.Label
    Friend WithEvents cmbSizeType As System.Windows.Forms.ComboBox
    Friend WithEvents lblColor As System.Windows.Forms.Label
    Friend WithEvents cmbType1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblMake As System.Windows.Forms.Label
    Friend WithEvents cmbType2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblFluor As System.Windows.Forms.Label
    Friend WithEvents cmbType3 As System.Windows.Forms.ComboBox
    Friend WithEvents lblClarity As System.Windows.Forms.Label
    Friend WithEvents cmbType4 As System.Windows.Forms.ComboBox
    Friend WithEvents lblPcs As System.Windows.Forms.Label
    Friend WithEvents txtPktPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtPktCts As System.Windows.Forms.TextBox

    Friend WithEvents lblBalPcs As System.Windows.Forms.Label
    Friend WithEvents txtBalPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblBalCts As System.Windows.Forms.Label
    Friend WithEvents txtBalCts As System.Windows.Forms.TextBox
    Friend WithEvents lblActPcs As System.Windows.Forms.Label
    Friend WithEvents txtActPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblActCts As System.Windows.Forms.Label
    Friend WithEvents txtActCts As System.Windows.Forms.TextBox
    Friend WithEvents lblPktType As System.Windows.Forms.Label
    Friend WithEvents cmbPktType As System.Windows.Forms.ComboBox
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents lblFinPcs As System.Windows.Forms.Label

    Friend WithEvents lblTotPcs As System.Windows.Forms.Label
    Friend WithEvents txtTotPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCts As System.Windows.Forms.Label
    Friend WithEvents txtTotCts As System.Windows.Forms.TextBox
    Friend WithEvents lblTPktPcs As System.Windows.Forms.Label
    Friend WithEvents txtTPktPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTPktCts As System.Windows.Forms.Label
    Friend WithEvents txtTPktCts As System.Windows.Forms.TextBox

    Friend WithEvents lblGridType As System.Windows.Forms.Label
    Friend WithEvents lblGridSelect As System.Windows.Forms.Label
    Friend WithEvents lblGridDetails As System.Windows.Forms.Label

    Friend WithEvents flxType As System.Windows.Forms.DataGridView
    Friend WithEvents flxSelect As System.Windows.Forms.DataGridView
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView

End Class