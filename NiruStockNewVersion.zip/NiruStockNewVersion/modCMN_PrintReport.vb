﻿Imports System.Collections.Specialized.BitVector32

' ── Crystal Reports for VB.NET ─────────────────────────────────
' IMPORTANT: Add NuGet package "CrystalDecisions.CrystalReports.Engine"
' In Visual Studio: Tools → NuGet Package Manager → Search "CrystalReports"
' Install: SAP Crystal Reports runtime engine for .NET Framework
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared ''

Module modCMN_PrintReport

    ' ── Print or Preview a Crystal Report ──────────────────────
    '
    ' Parameters:
    '   strReportName     - filename of the .rpt file (e.g. "rptSales.rpt")
    '   blnPreview        - True = show preview window, False = print directly
    '   blnPromptUser     - True = show printer dialog before printing
    '   intNumberOfCopies - how many copies to print
    '   strSelectionFormula - Crystal record selection formula (can be "")
    '   strReportTitle    - title shown in preview window
    '   Params            - ParamArray of values to pass to report parameters
    '
    Public Sub PrintReport(ByVal strReportName As String,
                           ByVal blnPreview As Boolean,
                           ByVal blnPromptUser As Boolean,
                           ByVal intNumberOfCopies As Integer,
                           ByVal strSelectionFormula As String,
                           ByVal strReportTitle As String,
                           ByVal ParamArray Params() As Object)
        Try
            Cursor.Current = Cursors.WaitCursor

            ' ── Build full report path ──────────────────────────
            Dim reportPath As String = IO.Path.Combine(PBReportPath.Trim(), strReportName)

            If Not IO.File.Exists(reportPath) Then
                MessageBox.Show($"Report file not found:{vbCrLf}{reportPath}", "Report Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' ── Load the report ────────────────────────────────
            Dim report As New ReportDocument()
            report.Load(reportPath)

            ' ── Set database login for all tables ──────────────
            Dim connInfo As New ConnectionInfo()
            connInfo.ServerName = Prod_DBSOURCE
            connInfo.DatabaseName = Prod_DBNAME
            connInfo.UserID = Prod_DBUSER
            connInfo.Password = Prod_DBPW

            SetDBLogonForReport(connInfo, report)

            ' ── Set record selection formula ───────────────────
            If strSelectionFormula <> "" Then
                report.RecordSelectionFormula = strSelectionFormula
            End If

            ' ── Set parameter values ───────────────────────────
            If Params IsNot Nothing AndAlso Params.Length > 0 Then
                Dim paramFields As ParameterFields = report.ParameterFields
                For idx As Integer = 0 To Math.Min(Params.Length, paramFields.Count) - 1
                    Dim pf As ParameterField = paramFields(idx)
                    Dim pv As New ParameterDiscreteValue()
                    pv.Value = Params(idx)
                    pf.CurrentValues.Clear()
                    pf.CurrentValues.Add(pv)
                Next
            End If

            ' ── Preview or Print ───────────────────────────────
            If blnPreview Then
                ' Show in a Crystal Reports viewer form
                Dim viewerForm As New Form()
                viewerForm.Text = strReportTitle
                viewerForm.WindowState = FormWindowState.Maximized

                Dim viewer As New CrystalDecisions.Windows.Forms.CrystalReportViewer()
                viewer.Dock = DockStyle.Fill
                viewer.ReportSource = report
                viewer.ShowPrintButton = True
                viewer.ShowExportButton = True
                viewer.ShowCloseButton = True

                viewerForm.Controls.Add(viewer)
                viewerForm.ShowDialog()
            Else
                ' Print directly
                report.PrintOptions.PrinterName = ""  ' uses default printer
                report.PrintToPrinter(intNumberOfCopies, False, 0, 0)
            End If

            report.Close()
            report.Dispose()

        Catch ex As Exception
            MessageBox.Show("Report Error: " & ex.Message, "Print Report",
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    ' ── Apply DB login to all tables including subreports ──────
    Private Sub SetDBLogonForReport(connInfo As ConnectionInfo, report As ReportDocument)
        ' Main report tables
        For Each tbl As Table In report.Database.Tables
            Dim tli As TableLogOnInfo = tbl.LogOnInfo
            tli.ConnectionInfo = connInfo
            tbl.ApplyLogOnInfo(tli)
        Next

        ' Subreport tables
        For Each section As Section In report.ReportDefinition.Sections
            For Each obj As ReportObject In section.ReportObjects
                If obj.Kind = ReportObjectKind.SubreportObject Then
                    Dim subRpt As SubreportObject = CType(obj, SubreportObject)
                    Dim subDoc As ReportDocument = report.OpenSubreport(subRpt.SubreportName)
                    For Each tbl As Table In subDoc.Database.Tables
                        Dim tli As TableLogOnInfo = tbl.LogOnInfo
                        tli.ConnectionInfo = connInfo
                        tbl.ApplyLogOnInfo(tli)
                    Next
                End If
            Next
        Next
    End Sub

End Module