﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_AssortComp
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)
        Dim fntBold As New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.grpMain = New System.Windows.Forms.GroupBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()
        Me.lblAssort1 = New System.Windows.Forms.Label()
        Me.cmbAssort1 = New System.Windows.Forms.ComboBox()
        Me.lblAssort2 = New System.Windows.Forms.Label()
        Me.cmbAssort2 = New System.Windows.Forms.ComboBox()
        Me.lblValue1 = New System.Windows.Forms.Label()
        Me.txtValue1 = New System.Windows.Forms.TextBox()
        Me.lblValue2 = New System.Windows.Forms.Label()
        Me.txtValue2 = New System.Windows.Forms.TextBox()
        Me.cmdCalc = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "ASSORTMENT CALCULATOR"
        Me.Size = New System.Drawing.Size(480, 290)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "ASSORTMENT CALCULATOR"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── GroupBox ───────────────────────────────────────────
        Me.grpMain.Location = New System.Drawing.Point(5, 40)
        Me.grpMain.Size = New System.Drawing.Size(465, 235)
        Me.grpMain.BackColor = System.Drawing.Color.Transparent
        Me.grpMain.Text = ""

        ' Row 1 — Cts | Assortment 1 | Assortment 2
        Me.lblCts.Text = "Cts" : Me.lblCts.Font = fntBold
        Me.lblCts.Location = New System.Drawing.Point(10, 18) : Me.lblCts.Size = New System.Drawing.Size(40, 18) : Me.lblCts.BackColor = System.Drawing.Color.Transparent

        Me.txtCts.Location = New System.Drawing.Point(10, 36) : Me.txtCts.Size = New System.Drawing.Size(80, 22)
        Me.txtCts.Font = fnt : Me.txtCts.TextAlign = HorizontalAlignment.Right

        Me.lblAssort1.Text = "Assortment 1" : Me.lblAssort1.Font = fntBold
        Me.lblAssort1.Location = New System.Drawing.Point(105, 18) : Me.lblAssort1.Size = New System.Drawing.Size(100, 18) : Me.lblAssort1.BackColor = System.Drawing.Color.Transparent

        Me.cmbAssort1.Location = New System.Drawing.Point(105, 36) : Me.cmbAssort1.Size = New System.Drawing.Size(160, 22)
        Me.cmbAssort1.Font = fnt : Me.cmbAssort1.DropDownStyle = ComboBoxStyle.DropDown

        Me.lblAssort2.Text = "Assortment 2" : Me.lblAssort2.Font = fntBold
        Me.lblAssort2.Location = New System.Drawing.Point(280, 18) : Me.lblAssort2.Size = New System.Drawing.Size(100, 18) : Me.lblAssort2.BackColor = System.Drawing.Color.Transparent

        Me.cmbAssort2.Location = New System.Drawing.Point(280, 36) : Me.cmbAssort2.Size = New System.Drawing.Size(160, 22)
        Me.cmbAssort2.Font = fnt : Me.cmbAssort2.DropDownStyle = ComboBoxStyle.DropDown

        ' Row 2 — Value 1 | Value 2
        Me.lblValue1.Text = "Value 1" : Me.lblValue1.Font = fntBold
        Me.lblValue1.Location = New System.Drawing.Point(105, 75) : Me.lblValue1.Size = New System.Drawing.Size(70, 18) : Me.lblValue1.BackColor = System.Drawing.Color.Transparent

        Me.txtValue1.Location = New System.Drawing.Point(105, 93) : Me.txtValue1.Size = New System.Drawing.Size(160, 22)
        Me.txtValue1.Font = fnt : Me.txtValue1.ReadOnly = True : Me.txtValue1.TextAlign = HorizontalAlignment.Right
        Me.txtValue1.BackColor = System.Drawing.Color.LightYellow

        Me.lblValue2.Text = "Value 2" : Me.lblValue2.Font = fntBold
        Me.lblValue2.Location = New System.Drawing.Point(280, 75) : Me.lblValue2.Size = New System.Drawing.Size(70, 18) : Me.lblValue2.BackColor = System.Drawing.Color.Transparent

        Me.txtValue2.Location = New System.Drawing.Point(280, 93) : Me.txtValue2.Size = New System.Drawing.Size(160, 22)
        Me.txtValue2.Font = fnt : Me.txtValue2.ReadOnly = True : Me.txtValue2.TextAlign = HorizontalAlignment.Right
        Me.txtValue2.BackColor = System.Drawing.Color.LightYellow

        ' Row 3 — Buttons
        Me.cmdCalc.Text = "Calculate"
        Me.cmdCalc.Location = New System.Drawing.Point(105, 140)
        Me.cmdCalc.Size = New System.Drawing.Size(160, 30)
        Me.cmdCalc.Font = fnt
        Me.cmdCalc.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.cmdExit.Text = "Exit"
        Me.cmdExit.Location = New System.Drawing.Point(280, 140)
        Me.cmdExit.Size = New System.Drawing.Size(160, 30)
        Me.cmdExit.Font = fnt
        Me.cmdExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.grpMain.Controls.AddRange({
            Me.lblCts, Me.txtCts,
            Me.lblAssort1, Me.cmbAssort1,
            Me.lblAssort2, Me.cmbAssort2,
            Me.lblValue1, Me.txtValue1,
            Me.lblValue2, Me.txtValue2,
            Me.cmdCalc, Me.cmdExit
        })

        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.grpMain)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents grpMain As System.Windows.Forms.GroupBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox
    Friend WithEvents lblAssort1 As System.Windows.Forms.Label
    Friend WithEvents cmbAssort1 As System.Windows.Forms.ComboBox
    Friend WithEvents lblAssort2 As System.Windows.Forms.Label
    Friend WithEvents cmbAssort2 As System.Windows.Forms.ComboBox
    Friend WithEvents lblValue1 As System.Windows.Forms.Label
    Friend WithEvents txtValue1 As System.Windows.Forms.TextBox
    Friend WithEvents lblValue2 As System.Windows.Forms.Label
    Friend WithEvents txtValue2 As System.Windows.Forms.TextBox
    Friend WithEvents cmdCalc As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button

End Class