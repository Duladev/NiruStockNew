﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPAY_Excel_Upload
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        '── Controls ───────────────────────────────────────────
        Me.grpMain = New System.Windows.Forms.GroupBox()
        Me.lblCompany = New System.Windows.Forms.Label()
        Me.cmbHotel = New System.Windows.Forms.ComboBox()
        Me.lblSourceLoc = New System.Windows.Forms.Label()
        Me.txtBackupLocation = New System.Windows.Forms.TextBox()
        Me.cmdSelect = New System.Windows.Forms.Button()
        Me.lblSupplier = New System.Windows.Forms.Label()
        Me.cmbSupplier = New System.Windows.Forms.ComboBox()
        Me.lblInvDate = New System.Windows.Forms.Label()
        Me.dtpInvDate = New System.Windows.Forms.DateTimePicker()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.txtCount = New System.Windows.Forms.TextBox()
        Me.lblInvoice = New System.Windows.Forms.Label()
        Me.txtInvoice = New System.Windows.Forms.TextBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.flxOT = New System.Windows.Forms.DataGridView()
        Me.txtError = New System.Windows.Forms.TextBox()

        ' Toolbar buttons
        Me.cmdLoad = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.pnlButtons = New System.Windows.Forms.Panel()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "I M P O R T   U P L O A D"
        Me.Size = New System.Drawing.Size(820, 680)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Font = fnt

        '── Button Panel ───────────────────────────────────────
        Me.pnlButtons.Location = New System.Drawing.Point(0, 0)
        Me.pnlButtons.Size = New System.Drawing.Size(814, 40)
        Me.pnlButtons.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Dim btns() As System.Windows.Forms.Button = {Me.cmdLoad, Me.cmdNew, Me.cmdSave, Me.cmdClose}
        Dim btnTxts() As String = {"Load File", "New", "Upload", "Exit"}
        Dim btnColors() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxts(idx)
            btns(idx).Location = New System.Drawing.Point(5 + idx * 100, 5)
            btns(idx).Size = New System.Drawing.Size(90, 28)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnColors(idx)
            Me.pnlButtons.Controls.Add(btns(idx))
        Next

        '── Main GroupBox ──────────────────────────────────────
        Me.grpMain.Text = ""
        Me.grpMain.Location = New System.Drawing.Point(5, 45)
        Me.grpMain.Size = New System.Drawing.Size(800, 590)

        '── Row 1: Company ─────────────────────────────────────
        Me.lblCompany.Text = "Company"
        Me.lblCompany.Font = fntBold
        Me.lblCompany.Location = New System.Drawing.Point(10, 18)
        Me.lblCompany.Size = New System.Drawing.Size(80, 18)
        Me.lblCompany.BackColor = System.Drawing.Color.Transparent

        Me.cmbHotel.Location = New System.Drawing.Point(10, 36)
        Me.cmbHotel.Size = New System.Drawing.Size(330, 24)
        Me.cmbHotel.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbHotel.Font = fnt

        '── Row 1 right: Supplier ──────────────────────────────
        Me.lblSupplier.Text = "Supplier"
        Me.lblSupplier.Font = fntBold
        Me.lblSupplier.Location = New System.Drawing.Point(400, 18)
        Me.lblSupplier.Size = New System.Drawing.Size(80, 18)
        Me.lblSupplier.BackColor = System.Drawing.Color.Transparent

        Me.cmbSupplier.Location = New System.Drawing.Point(400, 36)
        Me.cmbSupplier.Size = New System.Drawing.Size(380, 24)
        Me.cmbSupplier.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbSupplier.Font = fnt

        '── Row 2: Source Location ─────────────────────────────
        Me.lblSourceLoc.Text = "Source Location"
        Me.lblSourceLoc.Font = fntBold
        Me.lblSourceLoc.Location = New System.Drawing.Point(10, 70)
        Me.lblSourceLoc.Size = New System.Drawing.Size(120, 18)
        Me.lblSourceLoc.BackColor = System.Drawing.Color.Transparent

        Me.txtBackupLocation.Location = New System.Drawing.Point(10, 88)
        Me.txtBackupLocation.Size = New System.Drawing.Size(320, 22)
        Me.txtBackupLocation.Font = fnt
        Me.txtBackupLocation.ReadOnly = True
        Me.txtBackupLocation.Multiline = True
        Me.txtBackupLocation.Height = 45

        Me.cmdSelect.Text = "..."
        Me.cmdSelect.Location = New System.Drawing.Point(335, 88)
        Me.cmdSelect.Size = New System.Drawing.Size(30, 24)
        Me.cmdSelect.Font = fnt
        Me.cmdSelect.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        '── Row 2 right: Invoice Date ──────────────────────────
        Me.lblInvDate.Text = "Invoice Date"
        Me.lblInvDate.Font = fntBold
        Me.lblInvDate.Location = New System.Drawing.Point(400, 70)
        Me.lblInvDate.Size = New System.Drawing.Size(100, 18)
        Me.lblInvDate.BackColor = System.Drawing.Color.Transparent

        Me.dtpInvDate.Location = New System.Drawing.Point(400, 88)
        Me.dtpInvDate.Size = New System.Drawing.Size(140, 24)
        Me.dtpInvDate.Font = fnt
        Me.dtpInvDate.Format = DateTimePickerFormat.Short

        '── Row 3: Count + Invoice ─────────────────────────────
        Me.lblCount.Text = "Count"
        Me.lblCount.Font = fntBold
        Me.lblCount.Location = New System.Drawing.Point(10, 145)
        Me.lblCount.Size = New System.Drawing.Size(50, 18)
        Me.lblCount.BackColor = System.Drawing.Color.Transparent

        Me.txtCount.Location = New System.Drawing.Point(10, 163)
        Me.txtCount.Size = New System.Drawing.Size(80, 22)
        Me.txtCount.Font = fntBold
        Me.txtCount.ReadOnly = True
        Me.txtCount.TextAlign = HorizontalAlignment.Right

        Me.lblInvoice.Text = "Invoice No."
        Me.lblInvoice.Font = fntBold
        Me.lblInvoice.Location = New System.Drawing.Point(100, 145)
        Me.lblInvoice.Size = New System.Drawing.Size(80, 18)
        Me.lblInvoice.BackColor = System.Drawing.Color.Transparent

        Me.txtInvoice.Location = New System.Drawing.Point(100, 163)
        Me.txtInvoice.Size = New System.Drawing.Size(150, 22)
        Me.txtInvoice.Font = fntBold
        Me.txtInvoice.ReadOnly = True

        '── ProgressBar ────────────────────────────────────────
        Me.ProgressBar1.Location = New System.Drawing.Point(10, 192)
        Me.ProgressBar1.Size = New System.Drawing.Size(775, 18)

        '── DataGridView ───────────────────────────────────────
        Me.flxOT.Location = New System.Drawing.Point(10, 215)
        Me.flxOT.Size = New System.Drawing.Size(775, 305)
        Me.flxOT.Font = fnt

        '── Error TextBox ──────────────────────────────────────
        Me.txtError.Location = New System.Drawing.Point(10, 525)
        Me.txtError.Size = New System.Drawing.Size(480, 50)
        Me.txtError.Font = fnt
        Me.txtError.Multiline = True
        Me.txtError.ReadOnly = True
        Me.txtError.BackColor = System.Drawing.Color.LightYellow
        Me.txtError.ForeColor = System.Drawing.Color.Red

        '── Add controls to GroupBox ───────────────────────────
        Me.grpMain.Controls.AddRange({
            Me.lblCompany, Me.cmbHotel,
            Me.lblSupplier, Me.cmbSupplier,
            Me.lblSourceLoc, Me.txtBackupLocation, Me.cmdSelect,
            Me.lblInvDate, Me.dtpInvDate,
            Me.lblCount, Me.txtCount,
            Me.lblInvoice, Me.txtInvoice,
            Me.ProgressBar1, Me.flxOT, Me.txtError
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlButtons)
        Me.Controls.Add(Me.grpMain)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents grpMain As System.Windows.Forms.GroupBox
    Friend WithEvents pnlButtons As System.Windows.Forms.Panel
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents lblCompany As System.Windows.Forms.Label
    Friend WithEvents cmbHotel As System.Windows.Forms.ComboBox
    Friend WithEvents lblSupplier As System.Windows.Forms.Label
    Friend WithEvents cmbSupplier As System.Windows.Forms.ComboBox
    Friend WithEvents lblSourceLoc As System.Windows.Forms.Label
    Friend WithEvents txtBackupLocation As System.Windows.Forms.TextBox
    Friend WithEvents cmdSelect As System.Windows.Forms.Button
    Friend WithEvents lblInvDate As System.Windows.Forms.Label
    Friend WithEvents dtpInvDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents txtCount As System.Windows.Forms.TextBox
    Friend WithEvents lblInvoice As System.Windows.Forms.Label
    Friend WithEvents txtInvoice As System.Windows.Forms.TextBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents flxOT As System.Windows.Forms.DataGridView
    Friend WithEvents txtError As System.Windows.Forms.TextBox

End Class