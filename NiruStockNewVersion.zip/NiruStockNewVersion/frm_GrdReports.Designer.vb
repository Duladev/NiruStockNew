﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_GrdReports
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.scroll = New System.Windows.Forms.Panel()
        Me.btnExit = New System.Windows.Forms.Button()

        '── Button declarations ────────────────────────────────
        Me.btnStockInfo = New System.Windows.Forms.Button()
        Me.btnSizingStockInfo = New System.Windows.Forms.Button()
        Me.btnStockSummary = New System.Windows.Forms.Button()
        Me.btnPacketInfo = New System.Windows.Forms.Button()
        Me.btnSizingPacketInfo = New System.Windows.Forms.Button()
        Me.btnPackingList = New System.Windows.Forms.Button()
        Me.btnSizingDetails = New System.Windows.Forms.Button()
        Me.btnColorSummaryNew = New System.Windows.Forms.Button()
        Me.btnMakeSummaryNew = New System.Windows.Forms.Button()
        Me.btnClaritySummaryNew = New System.Windows.Forms.Button()
        Me.btnParcelBeforeFloNew = New System.Windows.Forms.Button()
        Me.btnParcelDetailsNew = New System.Windows.Forms.Button()
        Me.btnParcelDetailsSummary = New System.Windows.Forms.Button()
        Me.btnSizingSummaryNew = New System.Windows.Forms.Button()
        Me.btnCheckingSummary = New System.Windows.Forms.Button()
        Me.btnPacketDetails = New System.Windows.Forms.Button()
        Me.btnParcelValue = New System.Windows.Forms.Button()
        Me.btnSizingSummaryNewBtn = New System.Windows.Forms.Button()
        Me.btnEmpProduction = New System.Windows.Forms.Button()
        Me.btnEmpProdEmpWise = New System.Windows.Forms.Button()
        Me.btnEmpProdSummary = New System.Windows.Forms.Button()
        Me.btnForevermarkList = New System.Windows.Forms.Button()
        Me.btnFMSticker = New System.Windows.Forms.Button()
        Me.btnFMStickerNew = New System.Windows.Forms.Button()
        Me.btnPacketPrintNew = New System.Windows.Forms.Button()
        Me.btnAssortingPNL = New System.Windows.Forms.Button()
        Me.btnAssortingPNLSummary = New System.Windows.Forms.Button()
        Me.btnPackingListNiru = New System.Windows.Forms.Button()
        Me.btnBoxLabelsNew = New System.Windows.Forms.Button()
        Me.btnBoxLabelsNiru = New System.Windows.Forms.Button()
        Me.btnMainStickerNiru = New System.Windows.Forms.Button()
        Me.btnSubLabelsNiru = New System.Windows.Forms.Button()
        Me.btnSubMainStickerNiru = New System.Windows.Forms.Button()
        Me.btnPackingListBundle = New System.Windows.Forms.Button()
        Me.btnBoxLabelsBundle = New System.Windows.Forms.Button()
        Me.btnSubLabelsBundle = New System.Windows.Forms.Button()
        Me.btnPackingListHK = New System.Windows.Forms.Button()
        Me.btnPackingListHKMix = New System.Windows.Forms.Button()
        Me.btnPackingListFM = New System.Windows.Forms.Button()
        Me.btnPackingListFMID = New System.Windows.Forms.Button()
        Me.btnBoxLabelsID = New System.Windows.Forms.Button()
        Me.btnBoxLabelsIDClient = New System.Windows.Forms.Button()
        Me.btnPackingListClient = New System.Windows.Forms.Button()
        Me.btnSubLabelsClient = New System.Windows.Forms.Button()
        Me.btnPackingListClientNY = New System.Windows.Forms.Button()
        Me.btnBoxLabelsClientNY = New System.Windows.Forms.Button()
        Me.btnSubLabelsClientNY = New System.Windows.Forms.Button()
        Me.btnPackingListNY = New System.Windows.Forms.Button()
        Me.btnBoxLabelsNY = New System.Windows.Forms.Button()
        Me.btnAssortingPNLRep = New System.Windows.Forms.Button()
        Me.btnAssortingPNLRA = New System.Windows.Forms.Button()
        Me.btnPackingListRA = New System.Windows.Forms.Button()
        Me.btnBoxLabelsIDRA = New System.Windows.Forms.Button()
        Me.btnSubLabelsRA = New System.Windows.Forms.Button()
        Me.btnPackingListCountry = New System.Windows.Forms.Button()
        Me.btnMainStickerCountry = New System.Windows.Forms.Button()
        Me.btnSubLabelsCountry = New System.Windows.Forms.Button()
        Me.btnBoxLabelsCountry = New System.Windows.Forms.Button()
        Me.btnStockInSection = New System.Windows.Forms.Button()
        Me.btnPacketSticker = New System.Windows.Forms.Button()
        Me.btnMainStickerClient = New System.Windows.Forms.Button()
        Me.btnSizingProdEmpWise = New System.Windows.Forms.Button()
        Me.btnMainStickerFM = New System.Windows.Forms.Button()
        Me.btnPackingListClient2 = New System.Windows.Forms.Button()
        Me.btnParcelAnalysis = New System.Windows.Forms.Button()
        Me.btnLotSummary = New System.Windows.Forms.Button()
        Me.btnPackingListClientHK = New System.Windows.Forms.Button()
        Me.btnFMStickerID = New System.Windows.Forms.Button()
        Me.btnSizingDetailsSum = New System.Windows.Forms.Button()
        Me.btnPackingListPkt = New System.Windows.Forms.Button()
        Me.btnBoxLabelsPkt = New System.Windows.Forms.Button()
        Me.btnAssortingPNLParcel = New System.Windows.Forms.Button()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "GRADING INFO"
        Me.Size = New System.Drawing.Size(1020, 660)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "GRADING REPORTS"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Exit button ────────────────────────────────────────
        Me.btnExit.Text = "Exit"
        Me.btnExit.Location = New System.Drawing.Point(920, 40)
        Me.btnExit.Size = New System.Drawing.Size(80, 26)
        Me.btnExit.Font = fnt
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)
        Me.btnExit.Anchor = AnchorStyles.Top Or AnchorStyles.Right

        '── Scrollable panel ───────────────────────────────────
        Me.scroll.Location = New System.Drawing.Point(0, 35)
        Me.scroll.Size = New System.Drawing.Size(1014, 615)
        Me.scroll.AutoScroll = True
        Me.scroll.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or
                                AnchorStyles.Left Or AnchorStyles.Right
        Me.scroll.BackColor = System.Drawing.Color.FromArgb(240, 245, 248)

        '── Build buttons in 5-column grid ─────────────────────
        Dim btnW As Integer = 185
        Dim btnH As Integer = 28
        Dim padX As Integer = 8
        Dim padY As Integer = 8
        Dim cols As Integer = 5

        Dim allBtns() As System.Windows.Forms.Button = {
            Me.btnStockInfo, Me.btnSizingStockInfo, Me.btnStockSummary,
            Me.btnPacketInfo, Me.btnSizingPacketInfo,
            Me.btnPackingList, Me.btnSizingDetails,
            Me.btnColorSummaryNew, Me.btnMakeSummaryNew, Me.btnClaritySummaryNew,
            Me.btnParcelBeforeFloNew, Me.btnParcelDetailsNew, Me.btnParcelDetailsSummary,
            Me.btnSizingSummaryNew, Me.btnCheckingSummary,
            Me.btnPacketDetails, Me.btnParcelValue, Me.btnSizingSummaryNewBtn,
            Me.btnEmpProduction, Me.btnEmpProdEmpWise,
            Me.btnEmpProdSummary, Me.btnForevermarkList,
            Me.btnFMSticker, Me.btnFMStickerNew, Me.btnPacketPrintNew,
            Me.btnAssortingPNL, Me.btnAssortingPNLSummary,
            Me.btnPackingListNiru, Me.btnBoxLabelsNew, Me.btnBoxLabelsNiru,
            Me.btnMainStickerNiru, Me.btnSubLabelsNiru, Me.btnSubMainStickerNiru,
            Me.btnPackingListBundle, Me.btnBoxLabelsBundle, Me.btnSubLabelsBundle,
            Me.btnPackingListHK, Me.btnPackingListHKMix,
            Me.btnPackingListFM, Me.btnPackingListFMID,
            Me.btnBoxLabelsID, Me.btnBoxLabelsIDClient,
            Me.btnPackingListClient, Me.btnSubLabelsClient,
            Me.btnPackingListClientNY, Me.btnBoxLabelsClientNY, Me.btnSubLabelsClientNY,
            Me.btnPackingListNY, Me.btnBoxLabelsNY,
            Me.btnAssortingPNLRep, Me.btnAssortingPNLRA,
            Me.btnPackingListRA, Me.btnBoxLabelsIDRA, Me.btnSubLabelsRA,
            Me.btnPackingListCountry, Me.btnMainStickerCountry,
            Me.btnSubLabelsCountry, Me.btnBoxLabelsCountry,
            Me.btnStockInSection, Me.btnPacketSticker,
            Me.btnMainStickerClient, Me.btnSizingProdEmpWise, Me.btnMainStickerFM,
            Me.btnPackingListClient2, Me.btnParcelAnalysis,
            Me.btnLotSummary, Me.btnPackingListClientHK, Me.btnFMStickerID,
            Me.btnSizingDetailsSum, Me.btnPackingListPkt,
            Me.btnBoxLabelsPkt, Me.btnAssortingPNLParcel
        }

        Dim btnTexts() As String = {
            "Stock Info", "Sizing Stock Info", "Stock Summary",
            "Packet Information", "Sizing Packet Info",
            "Packing List", "Sizing Details",
            "Color Summary New", "Make Summary New", "Clarity Summary New",
            "Parcel Before Flo New", "Parcel Details New", "Parcel Details Summary",
            "Sizing Summary New", "Checking Summary",
            "Packet Details", "Parcel Value", "Sizing Summary New 2",
            "Employee Production", "Emp Prod Emp Wise",
            "Emp Prod Summary", "Forevermark List",
            "FM Sticker", "FM Sticker New", "Packet Print New",
            "Assorting PNL", "Assorting PNL Summary",
            "Packing List NIRU", "Box Labels New", "Box Labels NIRU",
            "Main Sticker NIRU", "Sub Labels NIRU", "Sub Main Sticker NIRU",
            "Packing List Bundle", "Box Labels Bundle", "Sub Labels Bundle",
            "Packing List HK", "Packing List HK Mix",
            "Packing List FM", "Packing List FM ID",
            "Box Labels ID", "Box Labels ID Client",
            "Packing List Client", "Sub Labels Client",
            "Packing List Client NY", "Box Labels Client NY", "Sub Labels Client NY",
            "Packing List NY", "Box Labels NY",
            "Assorting PNL Rep", "Assorting PNL RA",
            "Packing List RA", "Box Labels ID RA", "Sub Labels RA",
            "Packing List Country", "Main Sticker Country",
            "Sub Labels Country", "Box Labels Country",
            "Stock In Section", "Packet Sticker",
            "Main Sticker Client", "Sizing Prod Emp Wise", "Main Sticker FM",
            "Packing List Client 2", "Parcel Analysis",
            "Lot Summary", "Packing List Client HK", "FM Sticker ID",
            "Sizing Details Sum", "Packing List Pkt",
            "Box Labels Pkt", "Assorting PNL Parcel"
        }

        For idx As Integer = 0 To allBtns.Length - 1
            Dim col As Integer = idx Mod cols
            Dim row As Integer = idx \ cols
            allBtns(idx).Text = btnTexts(idx)
            allBtns(idx).Location = New System.Drawing.Point(
                padX + col * (btnW + padX),
                padY + row * (btnH + padY))
            allBtns(idx).Size = New System.Drawing.Size(btnW, btnH)
            allBtns(idx).Font = fnt
            allBtns(idx).BackColor = System.Drawing.Color.FromArgb(220, 235, 245)
            allBtns(idx).FlatStyle = FlatStyle.Standard
            Me.scroll.Controls.Add(allBtns(idx))
        Next

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.scroll)

        Me.ResumeLayout(False)
    End Sub

    '── Declarations ───────────────────────────────────────────
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents scroll As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnStockInfo As System.Windows.Forms.Button
    Friend WithEvents btnSizingStockInfo As System.Windows.Forms.Button
    Friend WithEvents btnStockSummary As System.Windows.Forms.Button
    Friend WithEvents btnPacketInfo As System.Windows.Forms.Button
    Friend WithEvents btnSizingPacketInfo As System.Windows.Forms.Button
    Friend WithEvents btnPackingList As System.Windows.Forms.Button
    Friend WithEvents btnSizingDetails As System.Windows.Forms.Button
    Friend WithEvents btnColorSummaryNew As System.Windows.Forms.Button
    Friend WithEvents btnMakeSummaryNew As System.Windows.Forms.Button
    Friend WithEvents btnClaritySummaryNew As System.Windows.Forms.Button
    Friend WithEvents btnParcelBeforeFloNew As System.Windows.Forms.Button
    Friend WithEvents btnParcelDetailsNew As System.Windows.Forms.Button
    Friend WithEvents btnParcelDetailsSummary As System.Windows.Forms.Button
    Friend WithEvents btnSizingSummaryNew As System.Windows.Forms.Button
    Friend WithEvents btnCheckingSummary As System.Windows.Forms.Button
    Friend WithEvents btnPacketDetails As System.Windows.Forms.Button
    Friend WithEvents btnParcelValue As System.Windows.Forms.Button
    Friend WithEvents btnSizingSummaryNewBtn As System.Windows.Forms.Button
    Friend WithEvents btnEmpProduction As System.Windows.Forms.Button
    Friend WithEvents btnEmpProdEmpWise As System.Windows.Forms.Button
    Friend WithEvents btnEmpProdSummary As System.Windows.Forms.Button
    Friend WithEvents btnForevermarkList As System.Windows.Forms.Button
    Friend WithEvents btnFMSticker As System.Windows.Forms.Button
    Friend WithEvents btnFMStickerNew As System.Windows.Forms.Button
    Friend WithEvents btnPacketPrintNew As System.Windows.Forms.Button
    Friend WithEvents btnAssortingPNL As System.Windows.Forms.Button
    Friend WithEvents btnAssortingPNLSummary As System.Windows.Forms.Button
    Friend WithEvents btnPackingListNiru As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsNew As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsNiru As System.Windows.Forms.Button
    Friend WithEvents btnMainStickerNiru As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsNiru As System.Windows.Forms.Button
    Friend WithEvents btnSubMainStickerNiru As System.Windows.Forms.Button
    Friend WithEvents btnPackingListBundle As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsBundle As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsBundle As System.Windows.Forms.Button
    Friend WithEvents btnPackingListHK As System.Windows.Forms.Button
    Friend WithEvents btnPackingListHKMix As System.Windows.Forms.Button
    Friend WithEvents btnPackingListFM As System.Windows.Forms.Button
    Friend WithEvents btnPackingListFMID As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsID As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsIDClient As System.Windows.Forms.Button
    Friend WithEvents btnPackingListClient As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsClient As System.Windows.Forms.Button
    Friend WithEvents btnPackingListClientNY As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsClientNY As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsClientNY As System.Windows.Forms.Button
    Friend WithEvents btnPackingListNY As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsNY As System.Windows.Forms.Button
    Friend WithEvents btnAssortingPNLRep As System.Windows.Forms.Button
    Friend WithEvents btnAssortingPNLRA As System.Windows.Forms.Button
    Friend WithEvents btnPackingListRA As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsIDRA As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsRA As System.Windows.Forms.Button
    Friend WithEvents btnPackingListCountry As System.Windows.Forms.Button
    Friend WithEvents btnMainStickerCountry As System.Windows.Forms.Button
    Friend WithEvents btnSubLabelsCountry As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsCountry As System.Windows.Forms.Button
    Friend WithEvents btnStockInSection As System.Windows.Forms.Button
    Friend WithEvents btnPacketSticker As System.Windows.Forms.Button
    Friend WithEvents btnMainStickerClient As System.Windows.Forms.Button
    Friend WithEvents btnSizingProdEmpWise As System.Windows.Forms.Button
    Friend WithEvents btnMainStickerFM As System.Windows.Forms.Button
    Friend WithEvents btnPackingListClient2 As System.Windows.Forms.Button
    Friend WithEvents btnParcelAnalysis As System.Windows.Forms.Button
    Friend WithEvents btnLotSummary As System.Windows.Forms.Button
    Friend WithEvents btnPackingListClientHK As System.Windows.Forms.Button
    Friend WithEvents btnFMStickerID As System.Windows.Forms.Button
    Friend WithEvents btnSizingDetailsSum As System.Windows.Forms.Button
    Friend WithEvents btnPackingListPkt As System.Windows.Forms.Button
    Friend WithEvents btnBoxLabelsPkt As System.Windows.Forms.Button
    Friend WithEvents btnAssortingPNLParcel As System.Windows.Forms.Button

End Class