﻿Module mdlToolBarColor

    ' ── In VB.NET / WinForms, toolbar background color is set  ─
    ' ── directly through the ToolStrip control properties.     ─
    ' ── The VB6 Windows API approach is no longer needed.      ─

    ' ── Set ToolStrip background color ────────────────────────
    '
    ' Usage example in a form:
    '   mdlToolBarColor.SetToolStripColor(ToolStrip1, Color.SteelBlue)
    '
    Public Sub SetToolStripColor(ts As System.Windows.Forms.ToolStrip, newColor As Color)
        ts.BackColor = newColor
        ts.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        ts.Invalidate()
    End Sub

    ' ── Set ToolStrip background from a hex color string ───────
    '
    ' Usage example:
    '   mdlToolBarColor.SetToolStripColorHex(ToolStrip1, "#4A90D9")
    '
    Public Sub SetToolStripColorHex(ts As System.Windows.Forms.ToolStrip, hexColor As String)
        Try
            Dim c As Color = ColorTranslator.FromHtml(hexColor)
            SetToolStripColor(ts, c)
        Catch ex As Exception
            ' Invalid color string — ignore silently
        End Try
    End Sub

    ' ── Reset ToolStrip to default system color ─────────────── 
    Public Sub ResetToolStripColor(ts As System.Windows.Forms.ToolStrip)
        ts.BackColor = SystemColors.Control
        ts.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode
        ts.Invalidate()
    End Sub

End Module