﻿Imports System.IO
Imports System.Runtime.InteropServices

Module mdlCMN_Procedures

    ' ── Windows API ────────────────────────────────────────────
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Public Function FindWindow(lpClassName As String, lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function IsWindow(hWnd As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function PostMessage(hWnd As IntPtr, msg As Integer, wParam As IntPtr, lParam As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function GetWindowLong(hWnd As IntPtr, nIndex As Integer) As Integer
    End Function

    Private Const GWL_STYLE As Integer = -16
    Private Const WS_DISABLED As Integer = &H8000000
    Private Const WM_CLOSE As Integer = &H10

    ' ── App Startup ────────────────────────────────────────────
    Public Sub StartupApp()
        Try
            Startup()
            frm000_UserPASSWD.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Startup Error", MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    ' ── Read Config File (sysniru.txt) ─────────────────────────
    Public Sub Startup()
        Dim configFile As String = "sysniru.txt"
        Dim configPath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), configFile)

        If Not File.Exists(configPath) Then
            MessageBox.Show("Invalid Registration", "Vital Information Missing!", MessageBoxButtons.OK, MessageBoxIcon.Critical)
            Application.Exit()
            Return
        End If

        Dim content As String = File.ReadAllText(configPath)
        Dim parts() As String = content.Split("|"c)

        If parts.Length >= 13 Then
            Prod_GROUP_NAME = parts(0).Trim()
            Prod_CODE = parts(1).Trim()
            Prod_NAME = parts(2).Trim()
            Prod_SERIAL_NO = parts(3).Trim()
            Prod_REG_TO = parts(4).Trim()
            Prod_RECORD_ORIENTATION = parts(5).Trim()
            Prod_DBSOURCE = parts(6).Trim()
            Prod_DBNAME = parts(7).Trim()
            Prod_DBUSER = parts(8).Trim()
            Prod_DBPW = parts(9).Trim()
            Prod_SystemCaption = parts(10).Trim()
            Prod_WK_ID = parts(11).Trim()
            Prod_PRINTER_CODE = parts(12).Trim()
        End If

        Open_File()
    End Sub

    ' ── Open DB Connection & Load System Parameters ──────────
    Public Sub Open_File()
        Try
            PBGridColor_Blue = "#F8E9DE"
            PBGridColor_Green = "#E3EFEC"
            PBGridColor_Purple = "#F5F0F0"

            Prod_SystemConnection = $"Data Source={Prod_DBSOURCE};Initial Catalog={Prod_DBNAME};Integrated Security=True;Connect Timeout=60;"
            gStrConnectionString = Prod_SystemConnection

            dbconn_Prod = New SqlConnection(Prod_SystemConnection)
            dbconn_Prod.Open()

            strCompName = Environment.MachineName

            ' ── Load site info ─────────────────────────────────
            Using cmd As New SqlCommand("SELECT * FROM wan_loca WHERE WAN_CODE=@code", dbconn_Prod)
                cmd.Parameters.AddWithValue("@code", Prod_CODE)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        Prod_SITE_CODE = dr("WAN_CODE").ToString().Trim()
                        Prod_SITE_NAME = dr("WAN_NAME").ToString().Trim()
                        Prod_RESERV_CODE = dr("RESERV_CODE").ToString().Trim()
                        Prod_STREET = dr("STREET").ToString().Trim()
                        Prod_CITY = dr("City").ToString().Trim()
                        Prod_STATE = dr("State").ToString().Trim()
                        Prod_COUNTRY = dr("Country").ToString().Trim()
                        Prod_TELEPHONE = dr("Telephone").ToString().Trim()
                        Prod_FAX = dr("Fax").ToString().Trim()
                        Prod_EMAIL = dr("Email").ToString().Trim()
                    End If
                End Using
            End Using

            ' ── Load system parameters ─────────────────────────
            Using cmd As New SqlCommand("SELECT * FROM SYS_PAR", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        PBReportPath = dr("REPORT_PATH").ToString().Trim()
                        PBStockPath = dr("REPORT_PATH_STOCK").ToString().Trim()
                        PBSERVICE_RATE = Convert.ToDouble(If(IsDBNull(dr("SERVICE_RATE")), 0, dr("SERVICE_RATE")))
                        PBVAT = Convert.ToDouble(If(IsDBNull(dr("VAT_RATE")), 0, dr("VAT_RATE")))
                        pbFilePath = dr("FILE_PATH").ToString().Trim()
                        pbFilePathCus = dr("FILE_PATH_CUS").ToString().Trim()
                        pbFilePathPro = dr("FILE_PATH_PRO").ToString().Trim()
                        pbFilePathTra = dr("FILE_PATH_TRA").ToString().Trim()
                        PBSystem_Interface = dr("HOTEL_INTERFACE").ToString().Trim()
                        PBSystem_Interface_Path = dr("HOTEL_INTERFACE_PATH").ToString().Trim()
                        pbFilePathDir = dr("FILE_PATH_DIR").ToString().Trim()
                        pbImagePath = dr("IMAGE_PATH").ToString().Trim()
                        pbTempPath = dr("TEMP_PATH").ToString().Trim()
                        dblEPF = Convert.ToDouble(If(IsDBNull(dr("EPF")), 0, dr("EPF")))
                        dblEPF_EMP = Convert.ToDouble(If(IsDBNull(dr("EPF_EMP")), 0, dr("EPF_EMP")))
                        dblETF = Convert.ToDouble(If(IsDBNull(dr("ETF")), 0, dr("ETF")))
                        pbBackupPath = dr("BACKUP_PATH").ToString().Trim()
                    End If
                End Using
            End Using

            GetDivideRate()

        Catch ex As Exception
            MessageBox.Show("Connection Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Critical)
            Application.Exit()
        End Try
    End Sub

    ' ── Verify User Password ───────────────────────────────────
    Public Sub Verify_Password(strUserID As String)
        PBUser_TablePassword = ""
        PBUser_Password_Step1_OK = False
        Try
            Using cmd As New SqlCommand("SELECT * FROM dbo.PASSWD WHERE User_ID=@uid", dbconn_Prod)
                cmd.Parameters.AddWithValue("@uid", strUserID.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        PBUser_Password_Step1_OK = True
                        dblPBUser_ID = Convert.ToDouble(dr("ID"))
                        PBUser_Rights = dr("User_Rights").ToString()
                        PBUser_Name = dr("User_Name").ToString()
                        PBUser_PasswordChanged = Convert.ToBoolean(dr("Change"))
                        PBUser_FullName = dr("User_FullName").ToString()
                        PBUser_Designation = dr("Designation").ToString()
                        PBUser_Telephone = dr("Telephone").ToString()
                        PBUser_Email = dr("Email").ToString()
                        PBUser_SiteCode = dr("WanCode").ToString()
                        DECRIPT(dr("pass11"), dr("pass22"), dr("pass33"), dr("pass44"),
                                dr("pass55"), dr("pass66"), dr("pass77"), dr("pass88"))
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error verifying user: " & ex.Message)
        End Try
    End Sub

    Public Sub Verify_Password_Approval(strUserID As String)
        PBUser_TablePassword = ""
        PBUser_Password_Step1_OK = False
        Try
            Using cmd As New SqlCommand("SELECT * FROM dbo.PASSWD WHERE User_ID=@uid", dbconn_Prod)
                cmd.Parameters.AddWithValue("@uid", strUserID.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        PBUser_Password_Step1_OK = True
                        dblPBUser_ID_APRV = Convert.ToDouble(dr("ID"))
                        PBUser_ID_APRV = dr("User_ID").ToString().Trim()
                        PBUser_Rights_APRV = dr("User_Rights").ToString()
                        PBUser_Name_APRV = dr("User_Name").ToString()
                        PBUser_PasswordChanged = Convert.ToBoolean(dr("Change"))
                        DECRIPT(dr("pass11"), dr("pass22"), dr("pass33"), dr("pass44"),
                                dr("pass55"), dr("pass66"), dr("pass77"), dr("pass88"))
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error verifying approver: " & ex.Message)
        End Try
    End Sub

    ' ── Password Encrypt ───────────────────────────────────────
    Public Sub ENCRIPT(strCPW As String)
        mmInt_Pass1 = 24 : mmInt_Pass2 = 25 : mmInt_Pass3 = 26 : mmInt_Pass4 = 27
        mmInt_Pass5 = 28 : mmInt_Pass6 = 29 : mmInt_Pass7 = 30 : mmInt_Pass8 = 31
        For i As Integer = 1 To Math.Min(strCPW.Length, 8)
            Dim c As Integer = Asc(Mid(strCPW, i, 1))
            If c = 32 Then Exit For
            Select Case i
                Case 1 : mmInt_Pass1 = c - 8
                Case 2 : mmInt_Pass2 = c - 7
                Case 3 : mmInt_Pass3 = c - 6
                Case 4 : mmInt_Pass4 = c - 5
                Case 5 : mmInt_Pass5 = c - 4
                Case 6 : mmInt_Pass6 = c - 3
                Case 7 : mmInt_Pass7 = c - 2
                Case 8 : mmInt_Pass8 = c - 1
            End Select
        Next
    End Sub

    ' ── Password Decrypt ───────────────────────────────────────
    Public Sub DECRIPT(p1 As Object, p2 As Object, p3 As Object, p4 As Object,
                       p5 As Object, p6 As Object, p7 As Object, p8 As Object)
        PBUser_TablePassword = ""
        Dim vals() As Integer = {
            CInt(p1) + 8, CInt(p2) + 7, CInt(p3) + 6, CInt(p4) + 5,
            CInt(p5) + 4, CInt(p6) + 3, CInt(p7) + 2, CInt(p8) + 1
        }
        For Each v As Integer In vals
            If v <> 32 Then PBUser_TablePassword &= Chr(v)
        Next
    End Sub

    ' ── Activity Log ───────────────────────────────────────────
    Public Sub Log_book(screenName As String, activity As String, resNo As String, record As String)
        Try
            Using cmd As New SqlCommand("spCMN_InsertUserActivityLog", dbconn_Prod)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@LogDate", Format(Now, "MM/dd/yyyy HH:mm:ss"))
                cmd.Parameters.AddWithValue("@UserName", PBUser_Name)
                cmd.Parameters.AddWithValue("@UserID", PBUser_ID)
                cmd.Parameters.AddWithValue("@ScreenName", screenName)
                cmd.Parameters.AddWithValue("@Activity", activity)
                cmd.Parameters.AddWithValue("@ResNo", resNo)
                cmd.Parameters.AddWithValue("@Record", record)
                cmd.Parameters.AddWithValue("@SiteCode", Prod_SITE_CODE)
                cmd.Parameters.AddWithValue("@Orientation", Prod_RECORD_ORIENTATION)
                cmd.ExecuteNonQuery()
            End Using
        Catch
            ' Log silently
        End Try
    End Sub

    ' ── Write PABX Buffer ──────────────────────────────────────
    Public Sub Write_PABX_Buffer(strBuffer As String, strSiteCode As String)
        Try
            Using cmd As New SqlCommand("spHLO_InsertSendBuffer", dbconn_Prod)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Buffer", strBuffer)
                cmd.Parameters.AddWithValue("@SiteCode", strSiteCode)
                cmd.ExecuteNonQuery()
            End Using
        Catch ex As Exception
            MessageBox.Show("PABX Buffer Error: " & ex.Message)
        End Try
    End Sub

    ' ── Load Color Scheme ──────────────────────────────────────
    Public Sub Get_Color_Scheme(formName As String)
        Try
            Dim colorScheme As String = ""
            Using cmd As New SqlCommand("SELECT ColorScheeme FROM HOT_SystemScreen WHERE FormName=@name", dbconn_Prod)
                cmd.Parameters.AddWithValue("@name", formName)
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing Then colorScheme = result.ToString()
            End Using
            If colorScheme = "" Then Return

            Using cmd As New SqlCommand("SELECT * FROM CMN_ColorScheemFlex WHERE CLR_Scheem=@s", dbconn_Prod)
                cmd.Parameters.AddWithValue("@s", colorScheme)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        Color_Flex_Appearance = dr("clr_Appearance").ToString()
                        Color_Flex_BackColor = dr("clr_BackColor").ToString()
                        Color_Flex_BackColorBkg = dr("clr_BackColorBkg").ToString()
                        Color_Flex_BackColorFixed = dr("clr_BackColorFixed").ToString()
                        Color_Flex_BackColorSel = dr("clr_BackColorSel").ToString()
                        Color_Flex_BorderStyle = dr("clr_BorderStyle").ToString()
                        Color_Flex_FixedCol = dr("clr_FixedCol").ToString()
                        Color_Flex_ForecolorFixed = dr("clr_ForeColorFixed").ToString()
                        Color_Flex_ForeColorSel = dr("clr_ForeColorSel").ToString()
                        Color_Flex_GridColor = dr("clr_GridColor").ToString()
                        Color_Flex_GridColorFixed = dr("clr_GridColorFixed").ToString()
                    End If
                End Using
            End Using

            Using cmd As New SqlCommand("SELECT * FROM CMN_ColorScheemFrame WHERE CLR_Scheem=@s", dbconn_Prod)
                cmd.Parameters.AddWithValue("@s", colorScheme)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        Color_Fram_BackColor = dr("clr_BackColor").ToString()
                        Color_Fram_BorderColor = dr("clr_BorderColor").ToString()
                        Color_Fram_ButtonColor = dr("clr_ButtonColor").ToString()
                        Color_Fram_ButtonHighLightColor = dr("clr_ButtonHighLightColor").ToString()
                        Color_Fram_ForeColor = dr("clr_ForeColor").ToString()
                        Color_Fram_GradientBottom = dr("clr_GradientBottom").ToString()
                        Color_Fram_GradientTop = dr("clr_GradientTop").ToString()
                        Color_Fram_HeaderGradientBottom = dr("clr_HeaderGradientBottom").ToString()
                        Color_Fram_HeaderGradientTop = dr("CLR_HeaderGradientTop").ToString()
                    End If
                End Using
            End Using

            Using cmd As New SqlCommand("SELECT * FROM CMN_ColorScheemButton WHERE CLR_Scheem=@s", dbconn_Prod)
                cmd.Parameters.AddWithValue("@s", colorScheme)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        Color_Butn_BackColor = dr("clr_BackColor").ToString()
                        Color_Butn_BorderColor = dr("clr_BorderColor").ToString()
                        Color_Butn_HoverColor = dr("clr_HoverColor").ToString()
                        Color_Butn_FontColor = dr("clr_FontColor").ToString()
                    End If
                End Using
            End Using

        Catch ex As Exception
            ' Color scheme load failed silently
        End Try
    End Sub

    ' ── Find Folio ─────────────────────────────────────────────
    Public Sub Find_Folio(strFolio As String)
        blnFolioCreated = True
        Try
            Using cmd As New SqlCommand("SELECT COUNT(*) FROM TFC_ACCOUNT WHERE AccountFolio=@f", dbconn_Prod)
                cmd.Parameters.AddWithValue("@f", strFolio.Trim())
                Dim count As Integer = CInt(cmd.ExecuteScalar())
                If count = 0 Then
                    MessageBox.Show("Folio Not Created.", "Create Folio in Accounts", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    blnFolioCreated = False
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Find Folio Error: " & ex.Message)
        End Try
    End Sub

    ' ── Utility: Form Centre ───────────────────────────────────
    Public Sub FormCentre(frm As Form)
        frm.StartPosition = FormStartPosition.CenterScreen
    End Sub

    ' ── Utility: Keyboard Filters ──────────────────────────────
    Public Sub IntegerOnly(ByRef e As KeyPressEventArgs)
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Public Sub NumericOnly(ByRef e As KeyPressEventArgs, currentText As String)
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back _
            AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> ControlChars.Cr Then
            e.Handled = True : Return
        End If
        If e.KeyChar = "."c AndAlso currentText.Contains(".") Then e.Handled = True
    End Sub

    Public Sub NumericOnlyWithMinus(ByRef e As KeyPressEventArgs, currentText As String)
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back _
            AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> "-"c Then
            e.Handled = True : Return
        End If
        If e.KeyChar = "."c AndAlso currentText.Contains(".") Then e.Handled = True
    End Sub

    ' ── Utility: Calculations ──────────────────────────────────
    Public Sub GetDivideRate()
        Dim temp As Double = 100 + 100 * PBSERVICE_RATE / 100
        dblDivideRate = temp + temp * PBVAT / 100
    End Sub

    Public Function GetWeekDayNameShort(dt As Date) As String
        Return dt.ToString("ddd")
    End Function

    ' ── Utility: Error Display ─────────────────────────────────
    Public Sub Message_Window_Runtime(formCode As String, formName As String,
                                      procedure As String, level As Integer,
                                      errNo As Double, errDesc As String, btnType As Integer)
        MessageBox.Show(
            $"Form Code      : {formCode}{vbCrLf}{vbCrLf}" &
            $"Form Name      : {formName}{vbCrLf}{vbCrLf}" &
            $"Procedure      : {procedure}{vbCrLf}{vbCrLf}" &
            $"Execution Level: {level}{vbCrLf}{vbCrLf}" &
            $"Fault Code     : {errNo}{vbCrLf}{vbCrLf}" &
            $"Description    : {errDesc}",
            "SYSTEM MESSAGE (RUNTIME)", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    End Sub

    Public Sub ErrorLog(formName As String, eventName As String)
        MessageBox.Show($"Error in {eventName} - {formName}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Critical)
    End Sub

    Public Sub ErrorMsg(errNo As String, errDesc As String)
        If errNo <> "35600" Then
            MessageBox.Show($"{errNo},  {errDesc}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    ' ── Task Management ────────────────────────────────────────
    Public Function IsTaskRunning(windowName As String) As Boolean
        Dim hWnd As IntPtr = FindWindow(Nothing, windowName)
        Return hWnd <> IntPtr.Zero
    End Function

    Public Function EndTask(windowName As String) As Boolean
        Dim hWnd As IntPtr = FindWindow(Nothing, windowName)
        If hWnd = IntPtr.Zero Then Return False
        If Not IsWindow(hWnd) Then Return False
        If (GetWindowLong(hWnd, GWL_STYLE) And WS_DISABLED) = 0 Then
            PostMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero)
        End If
        Return True
    End Function

    ' ── Focus Color Helpers ────────────────────────────────────
    Public Sub GotFClr(objText As Control)
        objText.ForeColor = Color.FromArgb(strForeColor)
    End Sub

    Public Sub LostFClr(objText As Control)
        objText.ForeColor = SystemColors.MenuText
    End Sub

    Public Sub GotBClr(objText As Control)
        objText.BackColor = Color.FromArgb(strBackColor)
    End Sub

    Public Sub LostBClr(objText As Control)
        objText.BackColor = SystemColors.Window
    End Sub

End Module