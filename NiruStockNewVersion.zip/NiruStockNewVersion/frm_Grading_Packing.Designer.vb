﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_Packing
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        '── Controls ───────────────────────────────────────────
        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblParNo = New System.Windows.Forms.Label()
        Me.txtParNo = New System.Windows.Forms.TextBox()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblOrderNo = New System.Windows.Forms.Label()
        Me.cmbOrder = New System.Windows.Forms.ComboBox()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.lblPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "PACKING LIST"
        Me.Size = New System.Drawing.Size(1100, 660)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "PACKING LIST"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Top Panel ──────────────────────────────────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 35)
        Me.pnlTop.Size = New System.Drawing.Size(1090, 48)
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.lblParNo.Text = "Parcel No"
        Me.lblParNo.Font = fntBold
        Me.lblParNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblParNo.Location = New System.Drawing.Point(8, 5)
        Me.lblParNo.Size = New System.Drawing.Size(70, 18)
        Me.lblParNo.BackColor = System.Drawing.Color.Transparent

        Me.txtParNo.Location = New System.Drawing.Point(8, 23)
        Me.txtParNo.Size = New System.Drawing.Size(120, 22)
        Me.txtParNo.Font = fnt

        Me.lblOrderNo.Text = "Order No"
        Me.lblOrderNo.Font = fntBold
        Me.lblOrderNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblOrderNo.Location = New System.Drawing.Point(140, 5)
        Me.lblOrderNo.Size = New System.Drawing.Size(70, 18)
        Me.lblOrderNo.BackColor = System.Drawing.Color.Transparent

        Me.cmbOrder.Location = New System.Drawing.Point(140, 23)
        Me.cmbOrder.Size = New System.Drawing.Size(150, 22)
        Me.cmbOrder.DropDownStyle = ComboBoxStyle.DropDownList
        Me.cmbOrder.Font = fnt

        Me.cmdSave.Text = "&Save"
        Me.cmdSave.Location = New System.Drawing.Point(320, 20)
        Me.cmdSave.Size = New System.Drawing.Size(80, 26)
        Me.cmdSave.Font = fnt
        Me.cmdSave.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.btnExit.Text = "&Exit"
        Me.btnExit.Location = New System.Drawing.Point(405, 20)
        Me.btnExit.Size = New System.Drawing.Size(80, 26)
        Me.btnExit.Font = fnt
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.pnlTop.Controls.AddRange({
            Me.lblParNo, Me.txtParNo,
            Me.lblOrderNo, Me.cmbOrder,
            Me.cmdSave, Me.btnExit
        })

        '── DataGridView ───────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 88)
        Me.flxDetails.Size = New System.Drawing.Size(1080, 510)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or
                                  AnchorStyles.Left Or AnchorStyles.Right

        '── Totals Panel ───────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 600)
        Me.pnlTotals.Size = New System.Drawing.Size(1090, 35)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.lblPcs.Text = "Total Pcs:"
        Me.lblPcs.Font = fntBold
        Me.lblPcs.Location = New System.Drawing.Point(600, 8)
        Me.lblPcs.Size = New System.Drawing.Size(70, 18)
        Me.lblPcs.BackColor = System.Drawing.Color.Transparent

        Me.txtPcs.Location = New System.Drawing.Point(675, 6)
        Me.txtPcs.Size = New System.Drawing.Size(80, 22)
        Me.txtPcs.Font = fntBold
        Me.txtPcs.ReadOnly = True
        Me.txtPcs.TextAlign = HorizontalAlignment.Right

        Me.lblCts.Text = "Total Cts:"
        Me.lblCts.Font = fntBold
        Me.lblCts.Location = New System.Drawing.Point(770, 8)
        Me.lblCts.Size = New System.Drawing.Size(70, 18)
        Me.lblCts.BackColor = System.Drawing.Color.Transparent

        Me.txtCts.Location = New System.Drawing.Point(845, 6)
        Me.txtCts.Size = New System.Drawing.Size(90, 22)
        Me.txtCts.Font = fntBold
        Me.txtCts.ReadOnly = True
        Me.txtCts.TextAlign = HorizontalAlignment.Right

        Me.pnlTotals.Controls.AddRange({
            Me.lblPcs, Me.txtPcs, Me.lblCts, Me.txtCts
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblParNo As System.Windows.Forms.Label
    Friend WithEvents txtParNo As System.Windows.Forms.TextBox
    Friend WithEvents lblOrderNo As System.Windows.Forms.Label
    Friend WithEvents cmbOrder As System.Windows.Forms.ComboBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents lblPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox

End Class