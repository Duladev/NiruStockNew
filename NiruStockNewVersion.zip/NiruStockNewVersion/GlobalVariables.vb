﻿Module GlobalVariables

    ' ── Company / Site Info ────────────────────────────────────
    Public Prod_GROUP_NAME As String = ""
    Public Prod_CODE As String = ""
    Public Prod_NAME As String = ""
    Public Prod_SERIAL_NO As String = ""
    Public Prod_REG_TO As String = ""
    Public Prod_RECORD_ORIENTATION As String = ""
    Public Prod_DBSOURCE As String = ""
    Public Prod_DBNAME As String = ""
    Public Prod_DBUSER As String = ""
    Public Prod_DBPW As String = ""
    Public Prod_SystemDate As Date
    Public Prod_SystemTime As Date
    Public Prod_SystemCaption As String = ""
    Public Prod_SystemConnection As String = ""
    Public Prod_WK_ID As String = ""
    Public Prod_PRINTER_CODE As String = ""
    Public Prod_SITE_CODE As String = ""
    Public Prod_SITE_NAME As String = ""
    Public Prod_RESERV_CODE As String = ""
    Public Prod_STREET As String = ""
    Public Prod_CITY As String = ""
    Public Prod_STATE As String = ""
    Public Prod_COUNTRY As String = ""
    Public Prod_TELEPHONE As String = ""
    Public Prod_FAX As String = ""
    Public Prod_EMAIL As String = ""
    Public Prod_LOCAL_CURRENCY As String = ""
    Public Prod_AccountingPeriod As Long = 0
    Public Prod_WORKSTATIONS As Integer = 0
    Public Prod_COMPUTERNAME As String = ""

    ' ── Database ───────────────────────────────────────────────
    Public dbconn_Prod As New System.Data.SqlClient.SqlConnection
    Public dbconn_ProdTemp As System.Data.SqlClient.SqlConnection
    Public sqlstr As String = ""
    Public gStrConnectionString As String = ""

    ' ── User Info ──────────────────────────────────────────────
    Public PBUser_ID As String = ""
    Public PBUser_Name As String = ""
    Public PBUser_FullName As String = ""
    Public PBUser_Rights As String = ""
    Public PBUser_Level As String = ""
    Public PBUser_Designation As String = ""
    Public PBUser_Telephone As String = ""
    Public PBUser_Email As String = ""
    Public PBUser_SiteCode As String = ""
    Public PBUser_TablePassword As String = ""
    Public PBUser_Password_Step1_OK As Boolean = False
    Public PBUser_Password_Step2_OK As Boolean = False
    Public PBUser_PasswordChanged As Boolean = False
    Public dblPBUser_ID As Double = 0

    ' ── Approval User ──────────────────────────────────────────
    Public PBUser_ID_APRV As String = ""
    Public PBUser_Rights_APRV As String = ""
    Public PBUser_Level_APRV As String = ""
    Public PBUser_Name_APRV As String = ""
    Public dblPBUser_ID_APRV As Double = 0

    ' ── Encrypt Fields ─────────────────────────────────────────
    Public mmInt_Pass1 As Integer = 24
    Public mmInt_Pass2 As Integer = 25
    Public mmInt_Pass3 As Integer = 26
    Public mmInt_Pass4 As Integer = 27
    Public mmInt_Pass5 As Integer = 28
    Public mmInt_Pass6 As Integer = 29
    Public mmInt_Pass7 As Integer = 30
    Public mmInt_Pass8 As Integer = 31

    ' ── System Parameters ──────────────────────────────────────
    Public PBReportPath As String = ""
    Public PBStockPath As String = ""
    Public PBSERVICE_RATE As Double = 0
    Public PBVAT As Double = 0
    Public PBGST As Double = 0
    Public PBBTT As Double = 0
    Public PBNSL As Double = 0
    Public pbFilePath As String = ""
    Public pbFilePathCus As String = ""
    Public pbFilePathPro As String = ""
    Public pbFilePathTra As String = ""
    Public pbFilePathDir As String = ""
    Public pbImagePath As String = ""
    Public pbTempPath As String = ""
    Public pbBackupPath As String = ""
    Public PBSystem_Interface As String = ""
    Public PBSystem_Interface_Path As String = ""
    Public strRPTPath As String = ""
    Public dblEPF As Double = 0
    Public dblEPF_EMP As Double = 0
    Public dblETF As Double = 0
    Public dblDivideRate As Double = 0

    ' ── Grid Colors ────────────────────────────────────────────
    Public PBGridColor_Blue As String = ""
    Public PBGridColor_Green As String = ""
    Public PBGridColor_Purple As String = ""

    ' ── Color Scheme - Grid ────────────────────────────────────
    Public Color_Flex_Appearance As String = ""
    Public Color_Flex_BackColor As String = ""
    Public Color_Flex_BackColorBkg As String = ""
    Public Color_Flex_BackColorFixed As String = ""
    Public Color_Flex_BackColorSel As String = ""
    Public Color_Flex_BorderStyle As String = ""
    Public Color_Flex_FixedCol As String = ""
    Public Color_Flex_ForecolorFixed As String = ""
    Public Color_Flex_ForeColorSel As String = ""
    Public Color_Flex_GridColor As String = ""
    Public Color_Flex_GridColorFixed As String = ""

    ' ── Color Scheme - Frame ───────────────────────────────────
    Public Color_Fram_BackColor As String = ""
    Public Color_Fram_BorderColor As String = ""
    Public Color_Fram_ButtonColor As String = ""
    Public Color_Fram_ButtonHighLightColor As String = ""
    Public Color_Fram_ForeColor As String = ""
    Public Color_Fram_GradientBottom As String = ""
    Public Color_Fram_GradientTop As String = ""
    Public Color_Fram_HeaderGradientBottom As String = ""
    Public Color_Fram_HeaderGradientTop As String = ""

    ' ── Color Scheme - Button ──────────────────────────────────
    Public Color_Butn_BackColor As String = ""
    Public Color_Butn_BorderColor As String = ""
    Public Color_Butn_HoverColor As String = ""
    Public Color_Butn_FontColor As String = ""

    ' ── Misc / UI State ────────────────────────────────────────
    Public strCompName As String = ""
    Public strIPAddress As String = ""
    Public PBTotalEmployees As Double = 10000
    Public blnFolioCreated As Boolean = False
    Public PBResponse As String = ""
    Public PBPath As String = ""
    Public PB_EmpNo As String = ""
    Public CalCulateBaseUnitQty As Double = 0
    Public strOverBookStatus As String = ""
    Public PBIdentify_Form_Loading As Boolean = False
    Public strFind_UserID As String = ""
    Public strCriteriaCode As String = ""
    Public strNewAccountCode As String = ""
    Public strNewAccountFolio As String = ""
    Public mmint_Start As Integer = 0
    Public mmInt_Length As Integer = 0

    ' ── Order / Transaction State ──────────────────────────────
    Public MyAdvance As Object
    Public MYINVType As Object
    Public MyAmt As Object
    Public MyCusCode As Object
    Public MYCALL As Object
    Public MyDay As Object
    Public FP As Boolean = False
    Public MYOrdItem As Object
    Public MYOrdNumber As Object
    Public PbORDER_NO As Object
    Public Status As Object
    Public PBCRN As Object
    Public PBORINV As Object
    Public MyCrnAmt As Object
    Public MyCRNNo As Object
    Public MYCrnDesc As Object
    Public MyCrnExpDate As Object
    Public MyRcpCus As Object
    Public NewCRNNo As Object
    Public MyGVNo As Object
    Public MyGVAmt As Object
    Public MyGVExpDate As Object
    Public MyGVDesc As Object
    Public NewGVNo As Object
    Public dDate As Date
    Public strDate As String = ""

    ' ── Refresh Flags ──────────────────────────────────────────
    Public blnRefresAfterSharing As Boolean = False
    Public blnRefreshAfterBillSettle As Boolean = False
    Public blnRefreshAllocation As Boolean = False
    Public blnRefreshReservation As Boolean = False
    Public blnRefreshGP As Boolean = False
    Public blnRefreshComments As Boolean = False
    Public blnRefreshRateCode As Boolean = False
    Public blnRefreshDiscount As Boolean = False
    Public blnRefreshTA As Boolean = False
    Public blnRefreshTO As Boolean = False
    Public blnRefreshComp As Boolean = False

    ' ── Edit Mode Enum ─────────────────────────────────────────
    Public Enum EditMode
        emInitial = 0
        emAddNew = 1
        emEdit = 2
        emListView = 3
        emRecordView = 4
    End Enum

    ' ── Message Variables ──────────────────────────────────────
    Public MSG_Form_Code As String = ""
    Public MSG_Form_Name As String = ""
    Public MSG_Form_Procedure As String = ""
    Public MSG_Form_Execution_Level As String = ""
    Public MSG_Form_Error_No As Double = 0
    Public MSG_Form_Error_Description As String = ""

    ' ── Log Variables ──────────────────────────────────────────
    Public PBLog_ScreenName As String = ""
    Public PBLog_Activity As String = ""
    Public PBLog_ResNo As String = ""
    Public PBLog_Record As String = ""

    ' ── Focus Color (used in GotFClr / LostFClr) ───────────────
    Public strForeColor As Integer = 0
    Public strBackColor As Integer = 0

    ' ── Date Range Filters ─────────────────────────────────────
    Public PBDate_From As Date
    Public PBDate_To As Date

    ' ── Loop Counters (shared) ─────────────────────────────────
    Public i As Integer = 0
    Public j As Integer = 0

    ' ── Validation ─────────────────────────────────────────────
    Public Parcel As Boolean = False
    Public Datavalid As Boolean = False

End Module


