﻿Module modEncrypt

    ' ── String Encryption ──────────────────────────────────────
    ' Each character is encoded as a 4-digit numeric string.
    Public Function Encryption(ByVal strText As String) As String
        Dim cons As Integer = 2895
        Dim result As String = ""
        For t As Integer = 1 To strText.Length
            Dim x As String = Mid(strText, t, 1)
            Dim charValue As Integer = (Asc(x) + cons) + Asc(x) + t
            result &= charValue.ToString()
        Next
        Return result
    End Function

    ' ── String Decryption ──────────────────────────────────────
    Public Function Decryption(ByVal strText As String) As String
        Dim cons As Integer = 2895
        Dim result As String = ""
        Dim length As Integer = strText.Length \ 4
        For t As Integer = 0 To length - 1
            Dim x As Integer = CInt(Mid(strText, (t * 4) + 1, 4))
            Dim y As Integer = x - (t + 1)
            Dim yy As Integer = y - cons
            Dim z As Integer = yy \ 2
            result &= Chr(z)
        Next
        Return result
    End Function

End Module