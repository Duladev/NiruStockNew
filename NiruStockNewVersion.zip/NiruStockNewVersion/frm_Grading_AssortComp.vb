﻿Imports System.Data.SqlClient

Public Class frm_Grading_AssortComp

    ' FORM LOAD
    Private Sub frm_Grading_AssortComp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            Load_Assortments()
        Catch ex As Exception
            ErrorLog("frm_Grading_AssortComp", "Form_Load")
        End Try
    End Sub

    ' LOAD ASSORTMENTS INTO BOTH COMBOS
    Private Sub Load_Assortments()
        Try
            cmbAssort1.Items.Clear()
            cmbAssort2.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT AssortNo FROM tblGrading_SizeListNew ORDER BY AssortNo",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim assort As String = dr("AssortNo").ToString().Trim()
                        cmbAssort1.Items.Add(assort)
                        cmbAssort2.Items.Add(assort)
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_AssortComp", "Load_Assortments")
        End Try
    End Sub

    ' CTS — NUMERIC ONLY
    Private Sub txtCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCts.KeyPress
        NumericOnly(e, txtCts.Text)
    End Sub

    ' CALCULATE BUTTON
    Private Sub cmdCalc_Click(sender As Object, e As EventArgs) Handles cmdCalc.Click
        Try
            txtValue1.Text = "0.00"
            txtValue2.Text = "0.00"

            If txtCts.Text.Trim() = "" OrElse
               cmbAssort1.Text.Trim() = "" OrElse
               cmbAssort2.Text.Trim() = "" Then
                MessageBox.Show("Invalid Cts or Assortment", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim cts As Double = Convert.ToDouble(txtCts.Text.Trim())

            ' Value 1
            Using cmd As New SqlCommand(
                "SELECT Price FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort1.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing AndAlso result IsNot DBNull.Value Then
                    txtValue1.Text = Format(cts * Convert.ToDouble(result), "#0.00")
                End If
            End Using

            ' Value 2
            Using cmd As New SqlCommand(
                "SELECT Price FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort2.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing AndAlso result IsNot DBNull.Value Then
                    txtValue2.Text = Format(cts * Convert.ToDouble(result), "#0.00")
                End If
            End Using

        Catch ex As Exception
            ErrorLog("frm_Grading_AssortComp", "cmdCalc_Click")
        End Try
    End Sub

    ' EXIT
    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

End Class