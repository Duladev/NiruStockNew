﻿Public Class frm_Grading_SizingPacket

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frm_Grading_SizingPacket_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrids()
            ClearFields()
            Load_Size_Types()
            Load_Pkt_Types()
            Load_GradingTypes(1)
            Load_GradingTypes(2)
            Load_GradingTypes(3)
            Load_GradingTypes(4)
        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "Form_Load")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SETUP GRIDS
    '──────────────────────────────────────────────────────────────
    Private Sub SetupGrids()
        ' flxType grid — sizing codes with pcs/cts/balance
        SetupGrid(flxType, {"Code", "Color", "Make", "Fluorescent", "Clarity", "Pcs", "Cts", "Bal Pcs", "Bal Cts"},
                           {"Code", "Color", "Make", "Fluor", "Clarity", "Pcs", "Cts", "BalPcs", "BalCts"},
                           {100, 70, 70, 90, 80, 70, 80, 80, 80})

        ' flxSelect grid — items added to current packet
        SetupGrid(flxSelect, {"Pkt No", "Code", "Color", "Make", "Clarity", "Flo", "Pkt Pcs", "Pkt Cts", "Type"},
                             {"PktNo", "Code", "Color", "Make", "Clarity", "Flo", "PktPcs", "PktCts", "Type"},
                             {60, 80, 60, 60, 70, 50, 70, 75, 50})

        ' flxDetails grid — all saved packets for this parcel
        SetupGrid(flxDetails, {"Pkt No", "Code", "Color", "Make", "Clarity", "Flo", "Pkt Pcs", "Pkt Cts", "Type"},
                              {"PktNo", "Code", "Color", "Make", "Clarity", "Flo", "PktPcs", "PktCts", "Type"},
                              {60, 80, 60, 60, 70, 50, 70, 75, 50})
    End Sub

    Private Sub SetupGrid(grid As DataGridView, headers() As String, names() As String, widths() As Integer)
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False
        grid.AllowUserToAddRows = False
        grid.AllowUserToDeleteRows = False
        grid.ReadOnly = True
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        grid.BackgroundColor = System.Drawing.Color.White
        grid.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            If idx >= 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            grid.Columns.Add(col)
        Next
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD DROPDOWNS
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Size_Types()
        Try
            cmbSizeType.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT Code FROM tblGrading_SizingCodes GROUP BY Code ORDER BY Code",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSizeType.Items.Add(dr("Code").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "Load_Size_Types")
        End Try
    End Sub

    Private Sub Load_Pkt_Types()
        cmbPktType.Items.Clear()
        cmbPktType.Items.AddRange({"N", "B", "C", "M"})
    End Sub

    Private Sub Load_GradingTypes(intSec As Integer)
        Try
            Dim cbo As ComboBox = Nothing
            Select Case intSec
                Case 1 : cbo = cmbType1
                Case 2 : cbo = cmbType2
                Case 3 : cbo = cmbType3
                Case 4 : cbo = cmbType4
            End Select
            If cbo Is Nothing Then Return

            cbo.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT Type FROM tblGrading_Types WHERE Sec=@sec ORDER BY Type",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@sec", intSec)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cbo.Items.Add(dr("Type").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "Load_GradingTypes")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' PARCEL NO — ENTER KEY
    '──────────────────────────────────────────────────────────────
    Private Sub txtParNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If ParcelFound(txtParNo.Text.Trim()) Then
                txtParNo.Text = txtParNo.Text.Trim().ToUpper()
                GetNewPacket()
            Else
                MessageBox.Show("Invalid Parcel", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                ClearFields()
                txtParNo.Focus()
            End If
        End If
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SIZE CODE SELECTED — AUTO FILL COLOR/MAKE/CLARITY
    '──────────────────────────────────────────────────────────────
    Private Sub cmbSizeType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSizeType.SelectedIndexChanged
        If cmbSizeType.Text.Trim() = "" Then Return
        Try
            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_SizingCodes WHERE Code=@code", dbconn_Prod)
                cmd.Parameters.AddWithValue("@code", cmbSizeType.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        cmbType1.Text = dr("Color").ToString().Trim()
                        cmbType2.Text = dr("Make").ToString().Trim()
                        cmbType4.Text = dr("Clarity").ToString().Trim()
                    End If
                End Using
            End Using
            txtPktPcs.Focus()
        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "cmbSizeType_SelectedIndexChanged")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' PCS / CTS KEY PRESS
    '──────────────────────────────────────────────────────────────
    Private Sub txtPktPcs_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktPcs.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            txtPktCts.Focus()
        End If
    End Sub

    Private Sub txtPktCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktCts.KeyPress
        NumericOnly(e, txtPktCts.Text)
    End Sub

    '──────────────────────────────────────────────────────────────
    ' flxType ROW CLICK — FILL ENTRY FIELDS
    '──────────────────────────────────────────────────────────────
    Private Sub flxType_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles flxType.CellClick
        If e.RowIndex < 0 Then Return
        Try
            Dim row As DataGridViewRow = flxType.Rows(e.RowIndex)
            cmbSizeType.Text = row.Cells("Code").Value?.ToString()
            cmbType1.Text = row.Cells("Color").Value?.ToString()
            cmbType2.Text = row.Cells("Make").Value?.ToString()
            cmbType3.Text = row.Cells("Fluor").Value?.ToString()
            cmbType4.Text = row.Cells("Clarity").Value?.ToString()
            txtBalPcs.Text = row.Cells("BalPcs").Value?.ToString()
            txtBalCts.Text = row.Cells("BalCts").Value?.ToString()
            txtPktPcs.Text = row.Cells("BalPcs").Value?.ToString()
            txtPktCts.Text = row.Cells("BalCts").Value?.ToString()
        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "flxType_CellClick")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' flxSelect DOUBLE CLICK — DELETE ROW
    '──────────────────────────────────────────────────────────────
    Private Sub flxSelect_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles flxSelect.CellDoubleClick
        If e.RowIndex < 0 Then Return
        If flxSelect.Rows.Count = 0 Then Return

        Dim confirm = MessageBox.Show("Are you sure you want to delete?", Me.Text,
                                      MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If confirm = DialogResult.Yes Then
            Dim row As DataGridViewRow = flxSelect.Rows(e.RowIndex)
            Dim pcs As Double = Convert.ToDouble(If(row.Cells("PktPcs").Value?.ToString() = "", "0", row.Cells("PktPcs").Value?.ToString()))
            Dim cts As Double = Convert.ToDouble(If(row.Cells("PktCts").Value?.ToString() = "", "0", row.Cells("PktCts").Value?.ToString()))

            txtActPcs.Text = Format(Convert.ToDouble(txtActPcs.Text) - pcs, "#0")
            txtActCts.Text = Format(Convert.ToDouble(txtActCts.Text) - cts, "#0.000")
            txtBalPcs.Text = Format(Convert.ToDouble(txtBalPcs.Text) + pcs, "#0")
            txtBalCts.Text = Format(Convert.ToDouble(txtBalCts.Text) + cts, "#0.000")

            flxSelect.Rows.RemoveAt(e.RowIndex)
        End If
    End Sub

    '──────────────────────────────────────────────────────────────
    ' ADD BUTTON — ADD ROW TO flxSelect
    '──────────────────────────────────────────────────────────────
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        If Not ValidateEntry() Then Return

        Dim pcs As Double = Convert.ToDouble(txtPktPcs.Text)
        Dim cts As Double = Convert.ToDouble(txtPktCts.Text)

        flxSelect.Rows.Add(
            txtPktNo.Text,
            cmbSizeType.Text,
            cmbType1.Text,
            cmbType2.Text,
            cmbType4.Text,
            cmbType3.Text,
            pcs.ToString(),
            Format(cts, "#0.000"),
            cmbPktType.Text
        )

        txtActPcs.Text = Format(Convert.ToDouble(txtActPcs.Text) + pcs, "#0")
        txtActCts.Text = Format(Convert.ToDouble(txtActCts.Text) + cts, "#0.000")
        txtBalPcs.Text = Format(Convert.ToDouble(txtBalPcs.Text) - pcs, "#0")
        txtBalCts.Text = Format(Convert.ToDouble(txtBalCts.Text) - cts, "#0.000")

        txtPktPcs.Text = ""
        txtPktCts.Text = ""
    End Sub

    '──────────────────────────────────────────────────────────────
    ' VALIDATE ENTRY
    '──────────────────────────────────────────────────────────────
    Private Function ValidateEntry() As Boolean
        If txtParNo.Text.Trim() = "" Then
            MessageBox.Show("Invalid Parcel No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If txtPktNo.Text.Trim() = "" Then
            MessageBox.Show("Invalid Packet No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If cmbSizeType.Text.Trim() = "" Then
            MessageBox.Show("Invalid Code", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If cmbPktType.Text.Trim() = "" Then
            MessageBox.Show("Invalid Packet Type", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If txtPktPcs.Text.Trim() = "" OrElse Convert.ToDouble(txtPktPcs.Text) <= 0 Then
            MessageBox.Show("Invalid Packet Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If txtPktCts.Text.Trim() = "" OrElse Convert.ToDouble(txtPktCts.Text) <= 0 Then
            MessageBox.Show("Invalid Packet Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If Convert.ToDouble(txtPktPcs.Text) > Convert.ToDouble(txtBalPcs.Text) Then
            MessageBox.Show("Invalid Packet Pcs — exceeds balance", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        If Convert.ToDouble(txtPktCts.Text) > Convert.ToDouble(txtBalCts.Text) Then
            MessageBox.Show("Invalid Packet Cts — exceeds balance", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False
        End If
        Return True
    End Function

    '──────────────────────────────────────────────────────────────
    ' TOOLBAR BUTTONS
    '──────────────────────────────────────────────────────────────
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        ClearFields()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Save()
    End Sub

    Private Sub btnExcel_Click(sender As Object, e As EventArgs) Handles btnExcel.Click
        ExportGridToExcel(flxType)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SAVE
    '──────────────────────────────────────────────────────────────
    Private Sub Save()
        Try
            If txtParNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Parcel No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If txtPktNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Packet No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If cmbSizeType.Text.Trim() = "" Then
                MessageBox.Show("Invalid Code", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If cmbPktType.Text.Trim() = "" Then
                MessageBox.Show("Invalid Packet Type", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If txtActPcs.Text.Trim() = "" OrElse Convert.ToDouble(txtActPcs.Text) <= 0 Then
                MessageBox.Show("Invalid Packet Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If txtActCts.Text.Trim() = "" OrElse Convert.ToDouble(txtActCts.Text) <= 0 Then
                MessageBox.Show("Invalid Packet Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Check if already exists
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_SizingPacket WHERE ParNo=@par AND PktNo=@pkt",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                If CInt(cmd.ExecuteScalar()) > 0 Then
                    MessageBox.Show("Already Entered", Me.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            End Using

            ' Insert
            Using cmd As New SqlCommand(
                "INSERT INTO tblGrading_SizingPacket(Department,ParNo,PktNo,SizeCode,PktPcs,PktCts," &
                "ReturnType1,ReturnType2,ReturnType3,ReturnType4,PktType) " &
                "VALUES('Colombo',@par,@pkt,@size,@pcs,@cts,@t1,@t2,@t3,@t4,@ptype)",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                cmd.Parameters.AddWithValue("@size", cmbSizeType.Text.Trim())
                cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(txtActPcs.Text))
                cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(txtActCts.Text))
                cmd.Parameters.AddWithValue("@t1", cmbType1.Text.Trim())
                cmd.Parameters.AddWithValue("@t2", cmbType2.Text.Trim())
                cmd.Parameters.AddWithValue("@t3", cmbType3.Text.Trim())
                cmd.Parameters.AddWithValue("@t4", cmbType4.Text.Trim())
                cmd.Parameters.AddWithValue("@ptype", cmbPktType.Text.Trim())
                cmd.ExecuteNonQuery()
            End Using

            ' Reset
            txtPktPcs.Text = ""
            txtPktCts.Text = ""
            cmbType1.Text = ""
            cmbType2.Text = ""
            cmbType3.Text = ""
            cmbType4.Text = ""
            cmbSizeType.Text = ""
            cmbPktType.Text = ""
            txtBalPcs.Text = ""
            txtBalCts.Text = ""
            txtActPcs.Text = "0"
            txtActCts.Text = "0"
            flxSelect.Rows.Clear()

            GetNewPacket()

        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "Save")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' PARCEL FOUND CHECK
    '──────────────────────────────────────────────────────────────
    Private Function ParcelFound(parcelNo As String) As Boolean
        Try
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblInvoice WHERE ParcelNo=@par", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", parcelNo)
                Return CInt(cmd.ExecuteScalar()) > 0
            End Using
        Catch
            Return False
        End Try
    End Function

    '──────────────────────────────────────────────────────────────
    ' GET NEXT PACKET + LOAD ALL GRIDS
    '──────────────────────────────────────────────────────────────
    Private Sub GetNewPacket()
        Try
            ' Next packet number
            Using cmd As New SqlCommand(
                "SELECT MAX(PktNo) FROM tblGrading_SizingPacket WHERE ParNo=@par",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                txtPktNo.Text = If(result IsNot DBNull.Value AndAlso result IsNot Nothing,
                                   Format(CInt(result) + 1, "000"), "001")
            End Using

            ' Load flxType — sizing summary
            flxType.Rows.Clear()
            txtTotPcs.Text = "0"
            txtTotCts.Text = "0"

            Dim sql As String =
                "SELECT TOP (100) PERCENT sc.Code, " &
                "SUM(ct.Pcs) AS TotPcs, ROUND(SUM(ct.Cts),3) AS TotCts " &
                "FROM tblGrading_CheckingTypes ct " &
                "INNER JOIN tblGrading_CheckingReturns cr " &
                    "ON ct.Department=cr.Department AND ct.ParNo=cr.ParNo " &
                    "AND ct.PktNo=cr.PktNo AND ct.Sec=cr.Sec " &
                "INNER JOIN tblGrading_SizingCodesNew sc " &
                    "ON ct.ReturnType1=sc.Color AND ct.ReturnType2=sc.Make " &
                    "AND ct.ReturnType4=sc.Clarity " &
                "WHERE ct.ParNo=@par AND cr.SecCount=4 " &
                "GROUP BY sc.Code ORDER BY sc.Code"

            Using cmd As New SqlCommand(sql, dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim code As String = dr("Code").ToString()
                        Dim totPcs As Double = Convert.ToDouble(dr("TotPcs"))
                        Dim totCts As Double = Math.Round(Convert.ToDouble(dr("TotCts")), 3)

                        ' Get already packeted pcs/cts for this code
                        Dim pktPcs As Double = 0
                        Dim pktCts As Double = 0
                        Using cmd2 As New SqlCommand(
                            "SELECT SUM(PktPcs) AS P, ROUND(SUM(PktCts),3) AS C " &
                            "FROM tblGrading_SizingPacket WHERE ParNo=@par AND SizeCode=@code",
                            dbconn_Prod)
                            cmd2.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                            cmd2.Parameters.AddWithValue("@code", code)
                            Using dr2 As SqlDataReader = cmd2.ExecuteReader()
                                If dr2.Read() AndAlso dr2("P") IsNot DBNull.Value Then
                                    pktPcs = Convert.ToDouble(dr2("P"))
                                    pktCts = Math.Round(Convert.ToDouble(dr2("C")), 3)
                                End If
                            End Using
                        End Using

                        flxType.Rows.Add(code, "", "", "", "",
                            totPcs.ToString(),
                            Format(totCts, "#0.000"),
                            (totPcs - pktPcs).ToString(),
                            Format(Math.Round(totCts - pktCts, 3), "#0.000"))

                        txtTotPcs.Text = Format(Convert.ToDouble(txtTotPcs.Text) + totPcs, "#0")
                        txtTotCts.Text = Format(Math.Round(Convert.ToDouble(txtTotCts.Text) + totCts, 3), "#0.000")
                    End While
                End Using
            End Using

            ' Load flxDetails — all saved packets
            flxDetails.Rows.Clear()
            txtTPktPcs.Text = "0"
            txtTPktCts.Text = "0"

            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_SizingPacket WHERE ParNo=@par ORDER BY PktNo",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim pcs As Double = Convert.ToDouble(dr("PktPcs"))
                        Dim cts As Double = Math.Round(Convert.ToDouble(dr("PktCts")), 3)

                        flxDetails.Rows.Add(
                            dr("PktNo").ToString(),
                            dr("SizeCode").ToString(),
                            dr("ReturnType1").ToString(),
                            dr("ReturnType2").ToString(),
                            dr("ReturnType4").ToString(),
                            dr("ReturnType3").ToString(),
                            pcs.ToString(),
                            Format(cts, "#0.000"),
                            dr("PktType").ToString()
                        )

                        txtTPktPcs.Text = Format(Convert.ToDouble(txtTPktPcs.Text) + pcs, "#0")
                        txtTPktCts.Text = Format(Math.Round(Convert.ToDouble(txtTPktCts.Text) + cts, 3), "#0.000")
                    End While
                End Using
            End Using

        Catch ex As Exception
            ErrorLog("frm_Grading_SizingPacket", "GetNewPacket")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' CLEAR ALL
    '──────────────────────────────────────────────────────────────
    Private Sub ClearFields()
        txtParNo.Text = ""
        txtPktNo.Text = ""
        txtPktPcs.Text = ""
        txtPktCts.Text = ""
        cmbType1.Text = ""
        cmbType2.Text = ""
        cmbType3.Text = ""
        cmbType4.Text = ""
        cmbSizeType.Text = ""
        cmbPktType.Text = ""
        txtBalPcs.Text = ""
        txtBalCts.Text = ""
        txtActPcs.Text = "0"
        txtActCts.Text = "0"
        txtTotPcs.Text = "0"
        txtTotCts.Text = "0"
        txtTPktPcs.Text = "0"
        txtTPktCts.Text = "0"
        flxType.Rows.Clear()
        flxSelect.Rows.Clear()
        flxDetails.Rows.Clear()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' EXPORT GRID TO EXCEL
    '──────────────────────────────────────────────────────────────
    Private Sub ExportGridToExcel(grid As DataGridView)
        Try
            Dim sb As New System.Text.StringBuilder()
            For Each col As DataGridViewColumn In grid.Columns
                sb.Append(col.HeaderText & vbTab)
            Next
            sb.AppendLine()
            For Each row As DataGridViewRow In grid.Rows
                For Each cell As DataGridViewCell In row.Cells
                    sb.Append(cell.Value?.ToString() & vbTab)
                Next
                sb.AppendLine()
            Next
            Dim tempFile As String = System.IO.Path.Combine(
                System.IO.Path.GetTempPath(), "SizingExport.xls")
            System.IO.File.WriteAllText(tempFile, sb.ToString())
            ShellEx(tempFile)
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

End Class