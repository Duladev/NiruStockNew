﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_Packet
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        '── Controls ───────────────────────────────────────────
        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlToolbar = New System.Windows.Forms.Panel()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtRecordCount = New System.Windows.Forms.TextBox()
        Me.pnlEntry = New System.Windows.Forms.Panel()
        Me.lblParNo = New System.Windows.Forms.Label()
        Me.txtParNo = New System.Windows.Forms.TextBox()
        Me.lblPktNo = New System.Windows.Forms.Label()
        Me.txtPktNo = New System.Windows.Forms.TextBox()
        Me.lblPcs = New System.Windows.Forms.Label()
        Me.txtPktPcs = New System.Windows.Forms.TextBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtPktCts = New System.Windows.Forms.TextBox()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.grpModel = New System.Windows.Forms.GroupBox()
        Me.optNiruMake = New System.Windows.Forms.RadioButton()
        Me.optCommercial = New System.Windows.Forms.RadioButton()
        Me.optBlack = New System.Windows.Forms.RadioButton()
        Me.optSingleCut = New System.Windows.Forms.RadioButton()
        Me.flxPacket = New System.Windows.Forms.DataGridView()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "Grading Packet Entry"
        Me.Size = New System.Drawing.Size(620, 560)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.White

        '── Title Panel ────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)

        Me.lblTitle.Text = "Grading Packet Entry"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Toolbar Panel ──────────────────────────────────────
        Me.pnlToolbar.Location = New System.Drawing.Point(0, 35)
        Me.pnlToolbar.Size = New System.Drawing.Size(614, 40)
        Me.pnlToolbar.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.btnNew.Text = "New"
        Me.btnNew.Location = New System.Drawing.Point(5, 6)
        Me.btnNew.Size = New System.Drawing.Size(70, 26)
        Me.btnNew.Font = fnt
        Me.btnNew.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.btnSave.Text = "Save"
        Me.btnSave.Location = New System.Drawing.Point(80, 6)
        Me.btnSave.Size = New System.Drawing.Size(70, 26)
        Me.btnSave.Font = fnt
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.btnExit.Text = "Exit"
        Me.btnExit.Location = New System.Drawing.Point(155, 6)
        Me.btnExit.Size = New System.Drawing.Size(70, 26)
        Me.btnExit.Font = fnt
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.txtRecordCount.Location = New System.Drawing.Point(400, 8)
        Me.txtRecordCount.Size = New System.Drawing.Size(150, 22)
        Me.txtRecordCount.Text = "Record Count"
        Me.txtRecordCount.Font = fnt
        Me.txtRecordCount.ReadOnly = True
        Me.txtRecordCount.TextAlign = HorizontalAlignment.Center
        Me.txtRecordCount.BackColor = System.Drawing.Color.White

        Me.pnlToolbar.Controls.AddRange({
            Me.btnNew, Me.btnSave, Me.btnExit, Me.txtRecordCount
        })

        '── Entry Panel ────────────────────────────────────────
        Me.pnlEntry.Location = New System.Drawing.Point(0, 75)
        Me.pnlEntry.Size = New System.Drawing.Size(614, 220)
        Me.pnlEntry.BackColor = System.Drawing.Color.White

        Me.lblParNo.Text = "Parcel No"
        Me.lblParNo.Font = fntBold
        Me.lblParNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblParNo.Location = New System.Drawing.Point(10, 15)
        Me.lblParNo.Size = New System.Drawing.Size(80, 20)

        Me.txtParNo.Location = New System.Drawing.Point(100, 12)
        Me.txtParNo.Size = New System.Drawing.Size(120, 22)
        Me.txtParNo.Font = fnt

        Me.lblPktNo.Text = "Packet No"
        Me.lblPktNo.Font = fntBold
        Me.lblPktNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblPktNo.Location = New System.Drawing.Point(240, 15)
        Me.lblPktNo.Size = New System.Drawing.Size(75, 20)

        Me.txtPktNo.Location = New System.Drawing.Point(320, 12)
        Me.txtPktNo.Size = New System.Drawing.Size(60, 22)
        Me.txtPktNo.Font = fnt

        Me.lblPcs.Text = "PCs"
        Me.lblPcs.Font = fntBold
        Me.lblPcs.Location = New System.Drawing.Point(10, 55)
        Me.lblPcs.Size = New System.Drawing.Size(40, 20)

        Me.txtPktPcs.Location = New System.Drawing.Point(55, 52)
        Me.txtPktPcs.Size = New System.Drawing.Size(60, 22)
        Me.txtPktPcs.Font = fnt

        Me.lblCts.Text = "Cts"
        Me.lblCts.Font = fntBold
        Me.lblCts.Location = New System.Drawing.Point(130, 55)
        Me.lblCts.Size = New System.Drawing.Size(40, 20)

        Me.txtPktCts.Location = New System.Drawing.Point(175, 52)
        Me.txtPktCts.Size = New System.Drawing.Size(80, 22)
        Me.txtPktCts.Font = fnt

        Me.lblSize.Text = "Size"
        Me.lblSize.Font = fntBold
        Me.lblSize.Location = New System.Drawing.Point(270, 55)
        Me.lblSize.Size = New System.Drawing.Size(40, 20)

        Me.cmbSize.Location = New System.Drawing.Point(315, 52)
        Me.cmbSize.Size = New System.Drawing.Size(200, 22)
        Me.cmbSize.Font = fnt
        Me.cmbSize.DropDownStyle = ComboBoxStyle.DropDownList

        '── Radio Buttons (Make) ───────────────────────────────
        Me.grpModel.Text = "Make"
        Me.grpModel.Font = fntBold
        Me.grpModel.Location = New System.Drawing.Point(10, 90)
        Me.grpModel.Size = New System.Drawing.Size(590, 50)

        Me.optNiruMake.Text = "Niru Make"
        Me.optNiruMake.Font = fntBold
        Me.optNiruMake.Location = New System.Drawing.Point(10, 18)
        Me.optNiruMake.Size = New System.Drawing.Size(100, 22)
        Me.optNiruMake.Checked = True

        Me.optCommercial.Text = "Commercial Make"
        Me.optCommercial.Font = fntBold
        Me.optCommercial.Location = New System.Drawing.Point(120, 18)
        Me.optCommercial.Size = New System.Drawing.Size(140, 22)

        Me.optBlack.Text = "Black"
        Me.optBlack.Font = fntBold
        Me.optBlack.Location = New System.Drawing.Point(270, 18)
        Me.optBlack.Size = New System.Drawing.Size(80, 22)

        Me.optSingleCut.Text = "Single Cut"
        Me.optSingleCut.Font = fntBold
        Me.optSingleCut.Location = New System.Drawing.Point(360, 18)
        Me.optSingleCut.Size = New System.Drawing.Size(100, 22)

        Me.grpModel.Controls.AddRange({
            Me.optNiruMake, Me.optCommercial, Me.optBlack, Me.optSingleCut
        })

        Me.pnlEntry.Controls.AddRange({
            Me.lblParNo, Me.txtParNo,
            Me.lblPktNo, Me.txtPktNo,
            Me.lblPcs, Me.txtPktPcs,
            Me.lblCts, Me.txtPktCts,
            Me.lblSize, Me.cmbSize,
            Me.grpModel
        })

        '── DataGridView ───────────────────────────────────────
        Me.flxPacket.Location = New System.Drawing.Point(5, 300)
        Me.flxPacket.Size = New System.Drawing.Size(604, 210)
        Me.flxPacket.Font = fnt

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlToolbar)
        Me.Controls.Add(Me.pnlEntry)
        Me.Controls.Add(Me.flxPacket)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlToolbar As System.Windows.Forms.Panel
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtRecordCount As System.Windows.Forms.TextBox
    Friend WithEvents pnlEntry As System.Windows.Forms.Panel
    Friend WithEvents lblParNo As System.Windows.Forms.Label
    Friend WithEvents txtParNo As System.Windows.Forms.TextBox
    Friend WithEvents lblPktNo As System.Windows.Forms.Label
    Friend WithEvents txtPktNo As System.Windows.Forms.TextBox
    Friend WithEvents lblPcs As System.Windows.Forms.Label
    Friend WithEvents txtPktPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtPktCts As System.Windows.Forms.TextBox
    Friend WithEvents lblSize As System.Windows.Forms.Label
    Friend WithEvents cmbSize As System.Windows.Forms.ComboBox
    Friend WithEvents grpModel As System.Windows.Forms.GroupBox
    Friend WithEvents optNiruMake As System.Windows.Forms.RadioButton
    Friend WithEvents optCommercial As System.Windows.Forms.RadioButton
    Friend WithEvents optBlack As System.Windows.Forms.RadioButton
    Friend WithEvents optSingleCut As System.Windows.Forms.RadioButton
    Friend WithEvents flxPacket As System.Windows.Forms.DataGridView

End Class