﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.IO

Public Class frm_Grading_ExportSummaryModify

    ' FORM LOAD
    Private Sub frm_Grading_ExportSummaryModify_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_Supplier()
            txtPcs.Text = "0"
            txtCts.Text = "0"
            txtTotPcs.Text = "0"
            txtTotCts.Text = "0"
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("MS Sans Serif", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        ' Checkbox col 0
        Dim chk As New DataGridViewCheckBoxColumn()
        chk.HeaderText = "Sel"
        chk.Name = "Selected"
        chk.Width = 40
        flxDetails.Columns.Add(chk)

        Dim headers() As String = {
            "Assortment", "Lot No", "Pcs", "Cts", "Price", "Value",
            "Order No", "Pkt No", "Color", "Clarity", "Code", "Size Range",
            "ID", "Pack No", "Pack Type"
        }
        Dim names() As String = {
            "Assortment", "LotNo", "Pcs", "Cts", "Price", "Value",
            "OrderNo", "PktNo", "Color", "Clarity", "Code", "SizeRange",
            "ID", "PackNo", "PackType"
        }
        Dim widths() As Integer = {
            110, 75, 55, 70, 65, 75,
            80, 60, 65, 65, 90, 90,
            50, 70, 75
        }
        Dim editable() As Boolean = {
            False, False, True, True, True, False,
            False, False, False, False, False, False,
            False, True, True
        }

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = Not editable(idx)
            If idx >= 2 AndAlso idx <= 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    ' LOAD SUPPLIERS
    Private Sub Load_Supplier()
        Try
            cmbSupplier.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT SupplierCode, CompanyName FROM tblSuppliers ORDER BY CompanyName",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSupplier.Items.Add(New SupplierItem(
                            dr("SupplierCode").ToString().Trim(),
                            dr("CompanyName").ToString().Trim()))
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "Load_Supplier")
        End Try
    End Sub

    ' SUPPLIER SELECTED
    Private Sub cmbSupplier_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSupplier.SelectedIndexChanged
        If cmbSupplier.SelectedItem IsNot Nothing Then
            txtSupCode.Text = CType(cmbSupplier.SelectedItem, SupplierItem).Code
        End If
    End Sub

    ' LOAD ASSORTMENTS
    Private Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
        Load_Assortments()
    End Sub

    Private Sub Load_Assortments()
        Try
            Cursor.Current = Cursors.WaitCursor
            cmbAssort.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT AssortNo FROM tblGrading_SizeListNew ORDER BY AssortNo",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbAssort.Items.Add(dr("AssortNo").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "Load_Assortments")
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    ' ASSORTMENT ENTER — LOAD SIZE RANGES
    Private Sub cmbAssort_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbAssort.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If cmbAssort.Text.Trim() <> "" Then
                Load_SizeRange()
                cmbSize.Focus()
            End If
        End If
    End Sub

    Private Sub Load_SizeRange()
        Try
            cmbSize.Items.Clear()
            Dim intType As Integer = If(chkNew.Checked, 1, 0)
            Using cmd As New SqlCommand(
                "SELECT Size FROM tblGrading_SizeListRange WHERE AssortNo=@a AND Type=@t ORDER BY Size",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort.Text.Trim())
                cmd.Parameters.AddWithValue("@t", intType)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSize.Items.Add(dr("Size").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "Load_SizeRange")
        End Try
    End Sub

    Private Sub cmbSize_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbSize.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If cmbSize.Text.Trim() <> "" Then txtNewPcs.Focus()
        End If
    End Sub

    ' LOT NO — ENTER KEY
    Private Sub txtLotNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLotNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Load_PackingList()
        End If
    End Sub

    ' LOAD PACKING LIST BY LOT NO
    Private Sub Load_PackingList()
        Try
            flxDetails.Rows.Clear()
            Dim is2nd As Boolean = opt2.Checked
            Dim ctsFormat As String = If(is2nd, "#0.00", "#0.000")

            ' Try tblGrading_PackingListM first
            Dim hasM As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_PackingListM WHERE LotNo=@lot ORDER BY Code, Assortment",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@lot", txtLotNo.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    Dim first As Boolean = True
                    While dr.Read()
                        hasM = True
                        If first Then
                            txtPack.Text = dr("PackNo").ToString().Trim()
                            txtType.Text = dr("PackType").ToString().Trim()
                            txtCategory.Text = dr("Category").ToString().Trim()
                            first = False
                        End If
                        Dim pcs As Double = Convert.ToDouble(dr("Pcs"))
                        Dim cts As Double = Convert.ToDouble(dr("Cts"))
                        Dim price As Double = If(IsDBNull(dr("Price")), 0, Convert.ToDouble(dr("Price")))

                        Dim rowIdx As Integer = flxDetails.Rows.Add()
                        Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                        row.Cells("Selected").Value = True
                        row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                        row.Cells("LotNo").Value = dr("LotNo").ToString().Trim()
                        row.Cells("Pcs").Value = pcs.ToString()
                        row.Cells("Cts").Value = Format(cts, ctsFormat)
                        row.Cells("Price").Value = Format(price, "#0.00")
                        row.Cells("Value").Value = Format(cts * price, "#0.00")
                        row.Cells("OrderNo").Value = dr("OrderNo").ToString().Trim()
                        row.Cells("PktNo").Value = dr("PktNo").ToString().Trim()
                        row.Cells("Color").Value = dr("Color").ToString().Trim()
                        row.Cells("Clarity").Value = dr("Clarity").ToString().Trim()
                        row.Cells("Code").Value = dr("Code").ToString().Trim()
                        row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                        row.Cells("ID").Value = dr("ID").ToString().Trim()
                        row.Cells("PackNo").Value = dr("PackNo").ToString().Trim()
                        row.Cells("PackType").Value = dr("PackType").ToString().Trim()
                    End While
                End Using
            End Using

            If Not hasM Then
                ' Fall back to tblGrading_PackingList via VW_GradingLot
                Dim lotVal As Double = Convert.ToDouble(txtLotNo.Text.Trim())

                Dim sql1 As String =
                    "SELECT TOP (100) PERCENT gl.LotID, pl.Assortment, pl.SizeRange, " &
                    $"SUM(pl.ActPcs) AS Pcs, ROUND(SUM(pl.ActCts),{If(is2nd, 2, 3)}) AS Cts, " &
                    "ROUND(SUM(pl.ActCts * pl.Price),2) AS Value, pl.Code, pl.Price " &
                    "FROM tblGrading_PackingList pl INNER JOIN VW_GradingLot gl ON pl.ParNo=gl.ParNo " &
                    "WHERE pl.Code <> 'ZFOREVERMARK' " &
                    "GROUP BY gl.LotID, pl.Assortment, pl.SizeRange, pl.Code, pl.Price " &
                    $"HAVING gl.LotID = '{lotVal}' ORDER BY pl.Assortment"

                Using cmd As New SqlCommand(sql1, dbconn_Prod)
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        While dr.Read()
                            Dim rowIdx As Integer = flxDetails.Rows.Add()
                            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                            row.Cells("Selected").Value = True
                            row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                            row.Cells("LotNo").Value = dr("LotID").ToString().Trim()
                            row.Cells("Pcs").Value = dr("Pcs").ToString()
                            row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), ctsFormat)
                            row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                            row.Cells("Value").Value = Format(Convert.ToDouble(dr("Value")), "#0.00")
                            row.Cells("Code").Value = dr("Code").ToString().Trim()
                            row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                        End While
                    End Using
                End Using

                ' Forevermark rows
                Dim sql2 As String =
                    "SELECT TOP (100) PERCENT gl.LotID, pl.Assortment, pl.SizeRange, " &
                    "pl.ActPcs AS Pcs, pl.ActCts AS Cts, pl.Price, " &
                    "pl.ActCts * pl.Price AS Value, pl.Code, " &
                    "pl.OrderNo, pl.PktNo, pl.Color, pl.Clarity " &
                    "FROM tblGrading_PackingList pl INNER JOIN VW_GradingLot gl ON pl.ParNo=gl.ParNo " &
                    $"WHERE pl.Code = 'ZFOREVERMARK' AND gl.LotID = '{lotVal}' ORDER BY pl.Assortment"

                Using cmd As New SqlCommand(sql2, dbconn_Prod)
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        While dr.Read()
                            Dim rowIdx As Integer = flxDetails.Rows.Add()
                            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                            row.Cells("Selected").Value = True
                            row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                            row.Cells("LotNo").Value = dr("LotID").ToString().Trim()
                            row.Cells("Pcs").Value = dr("Pcs").ToString()
                            row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), ctsFormat)
                            row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                            row.Cells("Value").Value = Format(Convert.ToDouble(dr("Value")), "#0.00")
                            row.Cells("OrderNo").Value = dr("OrderNo").ToString().Trim()
                            row.Cells("PktNo").Value = dr("PktNo").ToString().Trim()
                            row.Cells("Color").Value = dr("Color").ToString().Trim()
                            row.Cells("Clarity").Value = dr("Clarity").ToString().Trim()
                            row.Cells("Code").Value = dr("Code").ToString().Trim()
                            row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                        End While
                    End Using
                End Using
            End If

            RecalcTotals()

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "Load_PackingList")
        End Try
    End Sub


    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Try
            If cmbAssort.Text.Trim() = "" Then MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If cmbSize.Text.Trim() = "" Then MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewPcs.Text.Trim() = "" OrElse Convert.ToDouble(txtNewPcs.Text) <= 0 Then MessageBox.Show("Invalid Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewCts.Text.Trim() = "" OrElse Convert.ToDouble(txtNewCts.Text) <= 0 Then MessageBox.Show("Invalid Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return

            If Convert.ToDouble(txtTotPcs.Text) + Convert.ToDouble(txtNewPcs.Text) > Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Invalid Total Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text) + Convert.ToDouble(txtNewCts.Text), 3) > Convert.ToDouble(txtCts.Text) Then
                MessageBox.Show("Invalid Total Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Get price and code
            Dim price As Double = 0
            Dim strCode As String = ""
            Using cmd As New SqlCommand(
                "SELECT PRICE, MainAssort FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        price = If(IsDBNull(dr("PRICE")), 0, Convert.ToDouble(dr("PRICE")))
                        strCode = dr("MainAssort").ToString().Trim()
                    Else
                        MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                    End If
                End Using
            End Using

            ' Validate size range
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_SizeListRange WHERE AssortNo=@a AND Size=@s",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort.Text.Trim())
                cmd.Parameters.AddWithValue("@s", cmbSize.Text.Trim())
                If CInt(cmd.ExecuteScalar()) = 0 Then
                    MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                End If
            End Using

            Dim pcs As Double = Convert.ToDouble(txtNewPcs.Text)
            Dim cts As Double = Convert.ToDouble(txtNewCts.Text)

            Dim rowIdx As Integer = flxDetails.Rows.Add()
            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
            row.Cells("Selected").Value = True
            row.Cells("Assortment").Value = cmbAssort.Text.Trim().ToUpper()
            row.Cells("LotNo").Value = txtLotNo.Text.Trim()
            row.Cells("Pcs").Value = pcs.ToString()
            row.Cells("Cts").Value = cts.ToString()
            row.Cells("Price").Value = Format(price, "#0.00")
            row.Cells("Value").Value = Format(price * cts, "#0.00")
            row.Cells("Code").Value = strCode
            row.Cells("SizeRange").Value = cmbSize.Text.Trim()
            row.Cells("ID").Value = "0"
            row.Cells("PackNo").Value = txtPack.Text.Trim()
            row.Cells("PackType").Value = txtType.Text.Trim()

            RecalcTotals()

            cmbAssort.Text = ""
            cmbSize.Text = ""
            txtNewPcs.Text = ""
            txtNewCts.Text = ""
            cmbAssort.Focus()

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "cmdAdd_Click")
        End Try
    End Sub


    Private Sub cmdAddPack_Click(sender As Object, e As EventArgs) Handles cmdAddPack.Click
        If txtPack.Text.Trim() = "" Then
            MessageBox.Show("Invalid Packing List No", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        For Each row As DataGridViewRow In flxDetails.Rows
            row.Cells("PackNo").Value = txtPack.Text.Trim()
        Next
    End Sub


    Private Sub RecalcTotals()
        Dim totPcs As Double = 0
        Dim totCts As Double = 0
        Dim is2nd As Boolean = opt2.Checked

        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("Selected").Value) Then
                totPcs += Convert.ToDouble(If(row.Cells("Pcs").Value?.ToString() = "", "0", row.Cells("Pcs").Value?.ToString()))
                totCts += Convert.ToDouble(If(row.Cells("Cts").Value?.ToString() = "", "0", row.Cells("Cts").Value?.ToString()))
            End If
        Next

        txtTotPcs.Text = totPcs.ToString()
        txtTotCts.Text = Format(Math.Round(totCts, If(is2nd, 2, 3)), If(is2nd, "#0.00", "#0.000"))
    End Sub

    Private Sub flxDetails_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellValueChanged
        If flxDetails.Columns(e.ColumnIndex).Name = "Selected" OrElse
           flxDetails.Columns(e.ColumnIndex).Name = "Cts" OrElse
           flxDetails.Columns(e.ColumnIndex).Name = "Pcs" Then
            RecalcTotals()
        End If
    End Sub

    Private Sub flxDetails_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles flxDetails.CurrentCellDirtyStateChanged
        If flxDetails.IsCurrentCellDirty Then
            flxDetails.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If txtLotNo.Text.Trim() = "" Then MessageBox.Show("Invalid Lot No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If flxDetails.Rows.Count < 1 Then MessageBox.Show("No Records", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtPack.Text.Trim() = "" Then MessageBox.Show("Invalid Packing List No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtType.Text.Trim() = "" Then MessageBox.Show("Invalid Type", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtCategory.Text.Trim() = "" Then MessageBox.Show("Invalid Category", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If cmbSupplier.Text.Trim() = "" Then MessageBox.Show("Invalid Buyer", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtSupCode.Text.Trim() = "" Then MessageBox.Show("Invalid Buyer", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return

            RecalcTotals()

            If Convert.ToDouble(txtTotPcs.Text) <> Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Pcs not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text), 3) <> Math.Round(Convert.ToDouble(txtCts.Text), 3) Then
                MessageBox.Show("Cts not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Check if lot already exists in PackingListM
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_PackingListM WHERE LotNo=@lot", dbconn_Prod)
                cmd.Parameters.AddWithValue("@lot", txtLotNo.Text.Trim())
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If exists Then
                ' Validate pack nos for selected rows
                For Each row As DataGridViewRow In flxDetails.Rows
                    If Convert.ToBoolean(row.Cells("Selected").Value) Then
                        If row.Cells("PackNo").Value?.ToString().Trim() = "" Then
                            MessageBox.Show("Invalid Packing List No - " & row.Cells("Assortment").Value?.ToString(),
                                            Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
                            Return
                        End If
                    End If
                Next

                If MessageBox.Show("Are you sure to update?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return

                For Each row As DataGridViewRow In flxDetails.Rows
                    Dim id As String = row.Cells("ID").Value?.ToString().Trim()
                    If Convert.ToBoolean(row.Cells("Selected").Value) Then
                        ' Check if ID exists
                        Dim idExists As Boolean = False
                        Using cmd As New SqlCommand(
                            "SELECT COUNT(*) FROM tblGrading_PackingListM WHERE ID=@id", dbconn_Prod)
                            cmd.Parameters.AddWithValue("@id", CDbl(id))
                            idExists = CInt(cmd.ExecuteScalar()) > 0
                        End Using

                        If Not idExists Then
                            InsertPackingListM(row)
                        Else
                            Using cmd As New SqlCommand(
                                "UPDATE tblGrading_PackingListM SET Pcs=@pcs, Cts=@cts, " &
                                "PackNo=@pn, Price=@price, PackType=@ptype, Category=@cat WHERE ID=@id",
                                dbconn_Prod)
                                cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
                                cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
                                cmd.Parameters.AddWithValue("@pn", CDbl(row.Cells("PackNo").Value?.ToString()))
                                cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
                                cmd.Parameters.AddWithValue("@ptype", row.Cells("PackType").Value?.ToString().Trim())
                                cmd.Parameters.AddWithValue("@cat", txtCategory.Text.Trim())
                                cmd.Parameters.AddWithValue("@id", CDbl(id))
                                cmd.ExecuteNonQuery()
                            End Using
                        End If
                    Else
                        ' Delete unselected
                        Using cmd As New SqlCommand(
                            "DELETE FROM tblGrading_PackingListM WHERE ID=@id", dbconn_Prod)
                            cmd.Parameters.AddWithValue("@id", CDbl(id))
                            cmd.ExecuteNonQuery()
                        End Using
                    End If
                Next
                MessageBox.Show("Updated Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If MessageBox.Show("Are you sure to save?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                For Each row As DataGridViewRow In flxDetails.Rows
                    If Convert.ToBoolean(row.Cells("Selected").Value) Then
                        InsertPackingListM(row)
                    End If
                Next
                MessageBox.Show("Saved Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            ResetForm()

        Catch ex As Exception
            MessageBox.Show("Save error: " & ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    Private Sub InsertPackingListM(row As DataGridViewRow)
        Using cmd As New SqlCommand(
            "INSERT INTO tblGrading_PackingListM(Assortment,LotNo,Pcs,Cts,Price,PackNo,PackType,Category," &
            "OrderNo,PktNo,Color,Clarity,Code,SupCode,SizeRange) " &
            "VALUES(@assort,@lot,@pcs,@cts,@price,@pn,@ptype,@cat,@order,@pkt,@color,@clarity,@code,@sup,@size)",
            dbconn_Prod)
            cmd.Parameters.AddWithValue("@assort", row.Cells("Assortment").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@lot", txtLotNo.Text.Trim())
            cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
            cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
            cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
            cmd.Parameters.AddWithValue("@pn", CDbl(txtPack.Text))
            cmd.Parameters.AddWithValue("@ptype", txtType.Text.Trim())
            cmd.Parameters.AddWithValue("@cat", txtCategory.Text.Trim())
            cmd.Parameters.AddWithValue("@order", row.Cells("OrderNo").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@pkt", row.Cells("PktNo").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@color", row.Cells("Color").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@clarity", row.Cells("Clarity").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@code", row.Cells("Code").Value?.ToString().Trim())
            cmd.Parameters.AddWithValue("@sup", CInt(txtSupCode.Text))
            cmd.Parameters.AddWithValue("@size", row.Cells("SizeRange").Value?.ToString().Trim())
            cmd.ExecuteNonQuery()
        End Using
    End Sub


    Private Sub cmdSavePrice_Click(sender As Object, e As EventArgs) Handles cmdSavePrice.Click
        Try
            If txtLotNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Lot No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If flxDetails.Rows.Count < 1 Then
                MessageBox.Show("No Records", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            If MessageBox.Show("Are you sure to Save the New Price?", Me.Text,
                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return

            For Each row As DataGridViewRow In flxDetails.Rows
                If Convert.ToBoolean(row.Cells("Selected").Value) Then
                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_PackingListM SET Price=@price WHERE ID=@id",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
                        cmd.Parameters.AddWithValue("@id", CDbl(row.Cells("ID").Value?.ToString()))
                        cmd.ExecuteNonQuery()
                    End Using
                End If
            Next

            MessageBox.Show("Price Updated Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ResetForm()

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "cmdSavePrice_Click")
        End Try
    End Sub


    Private Sub cmdUpdate_Click(sender As Object, e As EventArgs) Handles cmdUpdate.Click
        If MessageBox.Show("Are you sure to Update the List Price?", Me.Text,
                           MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
        Try
            For Each row As DataGridViewRow In flxDetails.Rows
                Using cmd As New SqlCommand(
                    "SELECT PRICE FROM tblGrading_SizeListNew WHERE AssortNo=@a",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@a", row.Cells("Assortment").Value?.ToString().Trim())
                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing Then
                        Dim price As Double = Convert.ToDouble(result)
                        Dim cts As Double = Convert.ToDouble(row.Cells("Cts").Value?.ToString())
                        row.Cells("Price").Value = Format(price, "#0.00")
                        row.Cells("Value").Value = Format(Math.Round(price * cts, 2), "#0.00")
                    End If
                End Using
            Next
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryModify", "cmdUpdate_Click")
        End Try
    End Sub


    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        ResetForm()
        txtLotNo.Focus()
    End Sub

    Private Sub cmdExcel_Click(sender As Object, e As EventArgs) Handles cmdExcel.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "Excel Files (*.xls)|*.xls"
                dlg.FileName = "PackageMix_" & txtLotNo.Text & ".xls"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportGrid(dlg.FileName, vbTab)
                    ShellEx(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub btnExportCSV_Click(sender As Object, e As EventArgs) Handles btnExportCSV.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "CSV Files (*.csv)|*.csv"
                dlg.FileName = "PackageMix_" & txtLotNo.Text & ".csv"
                If dlg.ShowDialog() = DialogResult.OK Then
                    ExportGrid(dlg.FileName, ",")
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub ExportGrid(filePath As String, delim As String)
        Dim sb As New StringBuilder()
        Dim hdrs As New List(Of String)
        For Each col As DataGridViewColumn In flxDetails.Columns
            hdrs.Add(col.HeaderText)
        Next
        sb.AppendLine(String.Join(delim, hdrs))
        For Each row As DataGridViewRow In flxDetails.Rows
            Dim cols As New List(Of String)
            For Each cell As DataGridViewCell In row.Cells
                cols.Add(cell.Value?.ToString())
            Next
            sb.AppendLine(String.Join(delim, cols))
        Next
        File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    Private Sub ResetForm()
        flxDetails.Rows.Clear()
        txtLotNo.Text = "" : txtPcs.Text = "0"
        txtCts.Text = "0" : txtTotPcs.Text = "0"
        txtTotCts.Text = "0" : txtPack.Text = ""
        txtType.Text = "" : txtCategory.Text = ""
        cmbSupplier.SelectedIndex = -1
        txtSupCode.Text = ""
    End Sub

    '── Key press helpers ──────────────────────────────────────────
    Private Sub txtNewPcs_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewPcs.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : txtNewCts.Focus()
    End Sub

    Private Sub txtNewCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewCts.KeyPress
        NumericOnly(e, txtNewCts.Text)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : cmdAdd.Focus()
    End Sub

    Private Sub txtPack_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPack.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : txtType.Focus()
    End Sub

End Class