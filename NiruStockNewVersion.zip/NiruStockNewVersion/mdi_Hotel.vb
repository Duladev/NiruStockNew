﻿Public Class mdi_Hotel


    Private Sub mdi_Hotel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.WindowState = FormWindowState.Maximized
            Me.Text = "N I R U   S T O C K  -  " & PBUser_Name & " - (" & Date.Now.ToString("dd/MM/yyyy") & ")"

            ' Load background image from network path
            Dim bgPath As String = "D:\Project\Reports Backups\Production Reports\Production Reports\Home.bmp"
            If System.IO.File.Exists(bgPath) Then
                Me.BackgroundImage = Image.FromFile(bgPath)
                Me.BackgroundImageLayout = ImageLayout.Stretch
            End If

            ' Show company info in title bar area
            lblHotelName.Text = "* " & Prod_GROUP_NAME.Trim() & " ** " & Prod_NAME.Trim() & " *"
            lblHotelName.Visible = True

        Catch ex As Exception
            ' Non-critical — continue loading even if background fails
        End Try
    End Sub


    Private Sub mdi_Hotel_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim result = MessageBox.Show("Are you sure you want to exit NiruStock?",
                                     "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.No Then
            e.Cancel = True
        Else
            Application.Exit()
        End If
    End Sub


    Private Sub mnuCompany_Click(sender As Object, e As EventArgs) Handles mnuCompany.Click
        OpenForm(New frmHOT_Company())
    End Sub

    Private Sub mnuPacket_Click(sender As Object, e As EventArgs) Handles mnuPacket.Click
        OpenForm(New frm_Grading_Packet())
    End Sub

    Private Sub mnuSizPktEntry_Click(sender As Object, e As EventArgs) Handles mnuSizPktEntry.Click
        OpenForm(New frm_Grading_SizingPacket())
    End Sub

    Private Sub mnuParcel_Click(sender As Object, e As EventArgs) Handles mnuParcel.Click
        OpenForm(New frm_Grading_Parcels())
    End Sub

    Private Sub mExit_Click(sender As Object, e As EventArgs) Handles mExit.Click
        Me.Close()
    End Sub


    Private Sub mnuExcel_Click(sender As Object, e As EventArgs) Handles mnuExcel.Click
        OpenForm(New frmPAY_Excel_Upload())
    End Sub

    'Private Sub mnuExport_Click(sender As Object, e As EventArgs) Handles mnuExport.Click
    '    OpenForm(New frmNiru_Export())
    'End Sub

    'Private Sub mnuPackUpload_Click(sender As Object, e As EventArgs) Handles mnuPackUpload.Click
    '   OpenForm(New frm_Grading_Upload())
    'End Sub

    Private Sub mnuForever_Click(sender As Object, e As EventArgs) Handles mnuForever.Click
        OpenForm(New frm_Grading_Packing())
    End Sub

    'Private Sub mnuInvoicing_Click(sender As Object, e As EventArgs) Handles mnuInvoicing.Click
    '   OpenForm(New frmNiru_Invoice())
    'End Sub

    Private Sub UploadDetails_Click(sender As Object, e As EventArgs) Handles UploadDetails.Click
        OpenForm(New frm_Grading_PacketUpload())
    End Sub

    Private Sub mnuPacking_Click(sender As Object, e As EventArgs) Handles mnuPacking.Click
        OpenForm(New frm_Grading_Export())
    End Sub

    Private Sub mnuPackage_Click(sender As Object, e As EventArgs) Handles mnuPackage.Click
        OpenForm(New frm_Grading_ExportSummary())
    End Sub

    Private Sub mnuMPack_Click(sender As Object, e As EventArgs) Handles mnuMPack.Click
        OpenForm(New frm_Grading_ExportSummaryModify())
    End Sub

    Private Sub mnuBundle2_Click(sender As Object, e As EventArgs) Handles mnuBundle2.Click
        OpenForm(New frm_Grading_Bundle())
    End Sub

    Private Sub mnuBundle_Click(sender As Object, e As EventArgs) Handles mnuBundle.Click
        OpenForm(New frm_Grading_ExportSummaryBundle())
    End Sub

    'Private Sub mnuIssRet_Click(sender As Object, e As EventArgs) Handles mnuIssRet.Click
    '   OpenForm(New frm_Grading_Boiling())
    'End Sub

    'Private Sub mnuSizeIR_Click(sender As Object, e As EventArgs) Handles mnuSizeIR.Click
    '   OpenForm(New frm_Grading_Sizing())
    'End Sub

    Private Sub mnuAssortCalc_Click(sender As Object, e As EventArgs) Handles mnuAssortCalc.Click
        OpenForm(New frm_Grading_AssortComp())
    End Sub


    Private Sub mReports_Click(sender As Object, e As EventArgs) Handles mReports.Click
        OpenForm(New frm_GrdReports())
    End Sub

    Private Sub mUser_Click(sender As Object, e As EventArgs) Handles mUser.Click
        ' TODO: Add user management form when ready
        MessageBox.Show("User Management - Coming Soon", "NiruStock",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub munBackup_Click(sender As Object, e As EventArgs) Handles munBackup.Click
        OpenForm(New frmSYS_BackUp())
    End Sub


    Private Sub OpenForm(frm As Form)
        Try
            ' Check if this form type is already open
            For Each child As Form In Me.MdiChildren
                If child.GetType() Is frm.GetType() Then
                    child.Activate()
                    frm.Dispose()
                    Return
                End If
            Next

            frm.MdiParent = Me
            frm.Show()

        Catch ex As Exception
            MessageBox.Show("Error opening form: " & ex.Message, "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class