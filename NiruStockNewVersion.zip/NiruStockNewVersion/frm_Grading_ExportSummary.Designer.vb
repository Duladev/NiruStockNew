﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_ExportSummary
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)
        Dim fntBold As New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblPackNo = New System.Windows.Forms.Label()
        Me.txtPackNo = New System.Windows.Forms.TextBox()
        Me.lblParcelNo = New System.Windows.Forms.Label()
        Me.cmbParcel = New System.Windows.Forms.ComboBox()
        Me.opt2 = New System.Windows.Forms.RadioButton()
        Me.opt3 = New System.Windows.Forms.RadioButton()
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.cmdExcel = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExportCSV = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.cmdUpdate = New System.Windows.Forms.Button()
        Me.chkComplete = New System.Windows.Forms.CheckBox()
        Me.lblAddPcs = New System.Windows.Forms.Label()
        Me.txtAddPcs = New System.Windows.Forms.TextBox()
        Me.lblAddCts = New System.Windows.Forms.Label()
        Me.txtAddCts = New System.Windows.Forms.TextBox()
        Me.lblPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "GRADING PACKAGE"
        Me.Size = New System.Drawing.Size(1300, 700)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "GRADING PACKAGE"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Top Panel ──────────────────────────────────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 35)
        Me.pnlTop.Size = New System.Drawing.Size(1290, 48)
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.lblPackNo.Text = "Package No." : Me.lblPackNo.Font = fntBold : Me.lblPackNo.Location = New System.Drawing.Point(8, 5) : Me.lblPackNo.Size = New System.Drawing.Size(85, 18) : Me.lblPackNo.BackColor = System.Drawing.Color.Transparent
        Me.txtPackNo.Location = New System.Drawing.Point(8, 23) : Me.txtPackNo.Size = New System.Drawing.Size(70, 22) : Me.txtPackNo.Font = fnt : Me.txtPackNo.TextAlign = HorizontalAlignment.Right

        Me.lblParcelNo.Text = "Parcel No." : Me.lblParcelNo.Font = fntBold : Me.lblParcelNo.Location = New System.Drawing.Point(90, 5) : Me.lblParcelNo.Size = New System.Drawing.Size(75, 18) : Me.lblParcelNo.BackColor = System.Drawing.Color.Transparent
        Me.cmbParcel.Location = New System.Drawing.Point(90, 22) : Me.cmbParcel.Size = New System.Drawing.Size(200, 22) : Me.cmbParcel.Font = fnt

        Me.opt2.Text = "2nd" : Me.opt2.Font = fnt : Me.opt2.Location = New System.Drawing.Point(302, 24) : Me.opt2.Size = New System.Drawing.Size(50, 20)
        Me.opt3.Text = "3rd" : Me.opt3.Font = fnt : Me.opt3.Location = New System.Drawing.Point(355, 24) : Me.opt3.Size = New System.Drawing.Size(50, 20) : Me.opt3.Checked = True

        Me.chkNew.Text = "New" : Me.chkNew.Font = New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold) : Me.chkNew.ForeColor = System.Drawing.Color.DarkBlue : Me.chkNew.Location = New System.Drawing.Point(415, 22) : Me.chkNew.Size = New System.Drawing.Size(55, 22)

        Dim btns() As System.Windows.Forms.Button = {Me.cmdRefresh, Me.cmdExcel, Me.cmdNew, Me.cmdSave, Me.btnExportCSV, Me.btnExit}
        Dim btnTxt() As String = {"Refresh", "Excel", "New", "Save", "CSV", "Exit"}
        Dim btnClr() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxt(idx)
            btns(idx).Location = New System.Drawing.Point(680 + idx * 88, 15)
            btns(idx).Size = New System.Drawing.Size(80, 26)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnClr(idx)
            Me.pnlTop.Controls.Add(btns(idx))
        Next

        Me.pnlTop.Controls.AddRange({Me.lblPackNo, Me.txtPackNo, Me.lblParcelNo, Me.cmbParcel, Me.opt2, Me.opt3, Me.chkNew})

        '── Grid ───────────────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 88)
        Me.flxDetails.Size = New System.Drawing.Size(1280, 545)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        '── Totals Panel ───────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 638)
        Me.pnlTotals.Size = New System.Drawing.Size(1290, 32)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.cmdUpdate.Text = "Update" : Me.cmdUpdate.Font = fnt : Me.cmdUpdate.Location = New System.Drawing.Point(5, 4) : Me.cmdUpdate.Size = New System.Drawing.Size(70, 24) : Me.cmdUpdate.BackColor = System.Drawing.Color.FromArgb(210, 210, 157)
        Me.chkComplete.Text = "Complete" : Me.chkComplete.Font = fnt : Me.chkComplete.Location = New System.Drawing.Point(85, 7) : Me.chkComplete.Size = New System.Drawing.Size(80, 20)

        Me.lblAddPcs.Text = "Orig Pcs:" : Me.lblAddPcs.Font = fntBold : Me.lblAddPcs.Location = New System.Drawing.Point(180, 7) : Me.lblAddPcs.Size = New System.Drawing.Size(65, 18) : Me.lblAddPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtAddPcs.Location = New System.Drawing.Point(250, 5) : Me.txtAddPcs.Size = New System.Drawing.Size(60, 22) : Me.txtAddPcs.Font = fntBold : Me.txtAddPcs.ReadOnly = True : Me.txtAddPcs.TextAlign = HorizontalAlignment.Right

        Me.lblAddCts.Text = "Orig Cts:" : Me.lblAddCts.Font = fntBold : Me.lblAddCts.Location = New System.Drawing.Point(320, 7) : Me.lblAddCts.Size = New System.Drawing.Size(65, 18) : Me.lblAddCts.BackColor = System.Drawing.Color.Transparent
        Me.txtAddCts.Location = New System.Drawing.Point(390, 5) : Me.txtAddCts.Size = New System.Drawing.Size(75, 22) : Me.txtAddCts.Font = fntBold : Me.txtAddCts.ReadOnly = True : Me.txtAddCts.TextAlign = HorizontalAlignment.Right

        Me.lblPcs.Text = "Act Pcs:" : Me.lblPcs.Font = fntBold : Me.lblPcs.Location = New System.Drawing.Point(480, 7) : Me.lblPcs.Size = New System.Drawing.Size(60, 18) : Me.lblPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPcs.Location = New System.Drawing.Point(545, 5) : Me.txtPcs.Size = New System.Drawing.Size(60, 22) : Me.txtPcs.Font = fntBold : Me.txtPcs.ReadOnly = True : Me.txtPcs.TextAlign = HorizontalAlignment.Right

        Me.lblCts.Text = "Act Cts:" : Me.lblCts.Font = fntBold : Me.lblCts.Location = New System.Drawing.Point(615, 7) : Me.lblCts.Size = New System.Drawing.Size(60, 18) : Me.lblCts.BackColor = System.Drawing.Color.Transparent
        Me.txtCts.Location = New System.Drawing.Point(680, 5) : Me.txtCts.Size = New System.Drawing.Size(80, 22) : Me.txtCts.Font = fntBold : Me.txtCts.ReadOnly = True : Me.txtCts.TextAlign = HorizontalAlignment.Right

        Me.pnlTotals.Controls.AddRange({
            Me.cmdUpdate, Me.chkComplete,
            Me.lblAddPcs, Me.txtAddPcs, Me.lblAddCts, Me.txtAddCts,
            Me.lblPcs, Me.txtPcs, Me.lblCts, Me.txtCts
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblPackNo As System.Windows.Forms.Label
    Friend WithEvents txtPackNo As System.Windows.Forms.TextBox
    Friend WithEvents lblParcelNo As System.Windows.Forms.Label
    Friend WithEvents cmbParcel As System.Windows.Forms.ComboBox
    Friend WithEvents opt2 As System.Windows.Forms.RadioButton
    Friend WithEvents opt3 As System.Windows.Forms.RadioButton
    Friend WithEvents chkNew As System.Windows.Forms.CheckBox
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents cmdExcel As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExportCSV As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents cmdUpdate As System.Windows.Forms.Button
    Friend WithEvents chkComplete As System.Windows.Forms.CheckBox
    Friend WithEvents lblAddPcs As System.Windows.Forms.Label
    Friend WithEvents txtAddPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblAddCts As System.Windows.Forms.Label
    Friend WithEvents txtAddCts As System.Windows.Forms.TextBox
    Friend WithEvents lblPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox

End Class