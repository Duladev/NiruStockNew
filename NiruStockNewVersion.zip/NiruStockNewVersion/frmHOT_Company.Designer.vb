﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmHOT_Company
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()

        '── Controls ───────────────────────────────────────────
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.lblCompanyDrp = New System.Windows.Forms.Label()
        Me.cmbHotel = New System.Windows.Forms.ComboBox()

        Me.grpDetails = New System.Windows.Forms.GroupBox()
        Me.lblCompanyName = New System.Windows.Forms.Label()
        Me.lblCompanyCode = New System.Windows.Forms.Label()
        Me.lblStreet = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblCountry = New System.Windows.Forms.Label()
        Me.lblTelephone = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblEPF = New System.Windows.Forms.Label()
        Me.lblETF = New System.Windows.Forms.Label()
        Me.lblBankAC = New System.Windows.Forms.Label()

        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.txtCompanyCode = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtEPF = New System.Windows.Forms.TextBox()
        Me.txtETF = New System.Windows.Forms.TextBox()
        Me.txtBankAC = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "C O M P A N I E S"
        Me.Size = New System.Drawing.Size(560, 530)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Font = New System.Drawing.Font("Trebuchet MS", 8.25)

        '── Top Panel (buttons + company dropdown) ─────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 0)
        Me.pnlTop.Size = New System.Drawing.Size(544, 60)
        Me.pnlTop.BackColor = System.Drawing.SystemColors.Control

        Me.cmdExit.Text = "&Exit"
        Me.cmdExit.Location = New System.Drawing.Point(10, 18)
        Me.cmdExit.Size = New System.Drawing.Size(90, 28)
        Me.cmdExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.cmdSave.Text = "&Save"
        Me.cmdSave.Location = New System.Drawing.Point(115, 18)
        Me.cmdSave.Size = New System.Drawing.Size(90, 28)
        Me.cmdSave.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.cmdNew.Text = "&New"
        Me.cmdNew.Location = New System.Drawing.Point(220, 18)
        Me.cmdNew.Size = New System.Drawing.Size(90, 28)
        Me.cmdNew.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.lblCompanyDrp.Text = "Company"
        Me.lblCompanyDrp.Location = New System.Drawing.Point(370, 5)
        Me.lblCompanyDrp.Size = New System.Drawing.Size(70, 18)

        Me.cmbHotel.Location = New System.Drawing.Point(370, 22)
        Me.cmbHotel.Size = New System.Drawing.Size(160, 24)
        Me.cmbHotel.DropDownStyle = ComboBoxStyle.DropDownList

        Me.pnlTop.Controls.AddRange({
            Me.cmdExit, Me.cmdSave, Me.cmdNew,
            Me.lblCompanyDrp, Me.cmbHotel
        })

        '── Details GroupBox ───────────────────────────────────
        Me.grpDetails.Text = "Company Details"
        Me.grpDetails.Location = New System.Drawing.Point(5, 65)
        Me.grpDetails.Size = New System.Drawing.Size(540, 420)

        ' Helper to set label properties
        Dim lblFont As New System.Drawing.Font("Trebuchet MS", 8.25)

        Dim labels() As System.Windows.Forms.Label = {
            Me.lblCompanyName, Me.lblCompanyCode, Me.lblStreet,
            Me.lblCity, Me.lblCountry, Me.lblTelephone, Me.lblFax,
            Me.lblEmail, Me.lblEPF, Me.lblETF, Me.lblBankAC
        }
        Dim labelTexts() As String = {
            "Company Name", "Company Code", "Street", "City", "Country",
            "Telephone", "Fax", "E-Mail", "EPF Reg. No", "ETF Reg. No", "Bank A/C No"
        }
        For idx As Integer = 0 To labels.Length - 1
            labels(idx).Text = labelTexts(idx)
            labels(idx).Font = lblFont
            labels(idx).BackColor = System.Drawing.Color.Transparent
            labels(idx).Location = New System.Drawing.Point(10, 28 + idx * 34)
            labels(idx).Size = New System.Drawing.Size(100, 20)
        Next

        ' TextBoxes
        Dim txts() As System.Windows.Forms.TextBox = {
            Me.txtCompany, Me.txtCompanyCode, Me.txtStreet,
            Me.txtCity, Me.txtCountry, Me.txtTelephone, Me.txtFax,
            Me.txtEmail, Me.txtEPF, Me.txtETF, Me.txtBankAC
        }
        Dim txtWidths() As Integer = {
            420, 45, 420, 420, 420, 420, 420, 420, 175, 175, 175
        }
        For idx As Integer = 0 To txts.Length - 1
            txts(idx).Font = lblFont
            txts(idx).Location = New System.Drawing.Point(115, 25 + idx * 34)
            txts(idx).Size = New System.Drawing.Size(txtWidths(idx), 22)
            txts(idx).BackColor = System.Drawing.SystemColors.Window
        Next
        Me.txtCompanyCode.MaxLength = 2

        ' Add all to groupbox
        For Each lbl In labels : Me.grpDetails.Controls.Add(lbl) : Next
        For Each txt In txts : Me.grpDetails.Controls.Add(txt) : Next

        '── Assemble Form ──────────────────────────────────────
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.grpDetails)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents lblCompanyDrp As System.Windows.Forms.Label
    Friend WithEvents cmbHotel As System.Windows.Forms.ComboBox
    Friend WithEvents grpDetails As System.Windows.Forms.GroupBox

    Friend WithEvents lblCompanyName As System.Windows.Forms.Label
    Friend WithEvents lblCompanyCode As System.Windows.Forms.Label
    Friend WithEvents lblStreet As System.Windows.Forms.Label
    Friend WithEvents lblCity As System.Windows.Forms.Label
    Friend WithEvents lblCountry As System.Windows.Forms.Label
    Friend WithEvents lblTelephone As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblEPF As System.Windows.Forms.Label
    Friend WithEvents lblETF As System.Windows.Forms.Label
    Friend WithEvents lblBankAC As System.Windows.Forms.Label

    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents txtCompanyCode As System.Windows.Forms.TextBox
    Friend WithEvents txtStreet As System.Windows.Forms.TextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtEPF As System.Windows.Forms.TextBox
    Friend WithEvents txtETF As System.Windows.Forms.TextBox
    Friend WithEvents txtBankAC As System.Windows.Forms.TextBox

End Class