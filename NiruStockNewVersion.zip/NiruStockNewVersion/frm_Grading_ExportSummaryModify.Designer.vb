﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_ExportSummaryModify
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)
        Dim fntBold As New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlRow1 = New System.Windows.Forms.Panel()
        Me.lblLotNo = New System.Windows.Forms.Label()
        Me.txtLotNo = New System.Windows.Forms.TextBox()
        Me.lblTotPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()
        Me.lblBuyer = New System.Windows.Forms.Label()
        Me.cmbSupplier = New System.Windows.Forms.ComboBox()
        Me.opt2 = New System.Windows.Forms.RadioButton()
        Me.opt3 = New System.Windows.Forms.RadioButton()
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.cmdExcel = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExportCSV = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pnlRow2 = New System.Windows.Forms.Panel()
        Me.lblAssort = New System.Windows.Forms.Label()
        Me.cmbAssort = New System.Windows.Forms.ComboBox()
        Me.lblSize = New System.Windows.Forms.Label()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.lblNewPcs = New System.Windows.Forms.Label()
        Me.txtNewPcs = New System.Windows.Forms.TextBox()
        Me.lblNewCts = New System.Windows.Forms.Label()
        Me.txtNewCts = New System.Windows.Forms.TextBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.lblPackNo = New System.Windows.Forms.Label()
        Me.txtPack = New System.Windows.Forms.TextBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.txtType = New System.Windows.Forms.TextBox()
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.txtCategory = New System.Windows.Forms.TextBox()
        Me.lblSupCode = New System.Windows.Forms.Label()
        Me.txtSupCode = New System.Windows.Forms.TextBox()
        Me.cmdAddPack = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.cmdUpdate = New System.Windows.Forms.Button()
        Me.cmdSavePrice = New System.Windows.Forms.Button()
        Me.lblTotPcsB = New System.Windows.Forms.Label()
        Me.txtTotPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCtsB = New System.Windows.Forms.Label()
        Me.txtTotCts = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "GRADING PACKAGE MIXING"
        Me.Size = New System.Drawing.Size(1200, 740)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "GRADING PACKAGE MIXING"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Row 1 Panel ────────────────────────────────────────
        Me.pnlRow1.Location = New System.Drawing.Point(0, 35)
        Me.pnlRow1.Size = New System.Drawing.Size(1190, 40)
        Me.pnlRow1.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        ' Lot No
        Me.lblLotNo.Text = "Lot No." : Me.lblLotNo.Font = fntBold : Me.lblLotNo.Location = New System.Drawing.Point(5, 5) : Me.lblLotNo.Size = New System.Drawing.Size(55, 18) : Me.lblLotNo.BackColor = System.Drawing.Color.Transparent
        Me.txtLotNo.Location = New System.Drawing.Point(5, 22) : Me.txtLotNo.Size = New System.Drawing.Size(90, 22) : Me.txtLotNo.Font = fnt

        Me.lblTotPcs.Text = "Total Pcs" : Me.lblTotPcs.Font = fntBold : Me.lblTotPcs.Location = New System.Drawing.Point(105, 5) : Me.lblTotPcs.Size = New System.Drawing.Size(65, 18) : Me.lblTotPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPcs.Location = New System.Drawing.Point(105, 22) : Me.txtPcs.Size = New System.Drawing.Size(70, 22) : Me.txtPcs.Font = fnt : Me.txtPcs.ReadOnly = True : Me.txtPcs.TextAlign = HorizontalAlignment.Right : Me.txtPcs.Text = "0"

        Me.lblTotCts.Text = "Total Cts" : Me.lblTotCts.Font = fntBold : Me.lblTotCts.Location = New System.Drawing.Point(185, 5) : Me.lblTotCts.Size = New System.Drawing.Size(65, 18) : Me.lblTotCts.BackColor = System.Drawing.Color.Transparent
        Me.txtCts.Location = New System.Drawing.Point(185, 22) : Me.txtCts.Size = New System.Drawing.Size(80, 22) : Me.txtCts.Font = fnt : Me.txtCts.ReadOnly = True : Me.txtCts.TextAlign = HorizontalAlignment.Right : Me.txtCts.Text = "0"

        Me.lblBuyer.Text = "Buyer" : Me.lblBuyer.Font = fntBold : Me.lblBuyer.Location = New System.Drawing.Point(275, 5) : Me.lblBuyer.Size = New System.Drawing.Size(50, 18) : Me.lblBuyer.BackColor = System.Drawing.Color.Transparent
        Me.cmbSupplier.Location = New System.Drawing.Point(275, 22) : Me.cmbSupplier.Size = New System.Drawing.Size(200, 22) : Me.cmbSupplier.DropDownStyle = ComboBoxStyle.DropDownList : Me.cmbSupplier.Font = fnt

        Me.opt2.Text = "2nd" : Me.opt2.Font = fnt : Me.opt2.Location = New System.Drawing.Point(485, 22) : Me.opt2.Size = New System.Drawing.Size(50, 20)
        Me.opt3.Text = "3rd" : Me.opt3.Font = fnt : Me.opt3.Location = New System.Drawing.Point(540, 22) : Me.opt3.Size = New System.Drawing.Size(50, 20) : Me.opt3.Checked = True
        Me.chkNew.Text = "New" : Me.chkNew.Font = New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold) : Me.chkNew.ForeColor = System.Drawing.Color.DarkBlue : Me.chkNew.Location = New System.Drawing.Point(598, 22) : Me.chkNew.Size = New System.Drawing.Size(55, 20)

        Dim btns() As System.Windows.Forms.Button = {Me.cmdRefresh, Me.cmdExcel, Me.cmdNew, Me.cmdSave, Me.btnExportCSV, Me.btnExit}
        Dim btnTxt() As String = {"Refresh", "Excel", "New", "Save", "CSV", "Exit"}
        Dim btnClr() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxt(idx)
            btns(idx).Location = New System.Drawing.Point(660 + idx * 88, 15)
            btns(idx).Size = New System.Drawing.Size(80, 22)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnClr(idx)
            Me.pnlRow1.Controls.Add(btns(idx))
        Next
        Me.pnlRow1.Controls.AddRange({Me.lblLotNo, Me.txtLotNo, Me.lblTotPcs, Me.txtPcs, Me.lblTotCts, Me.txtCts, Me.lblBuyer, Me.cmbSupplier, Me.opt2, Me.opt3, Me.chkNew})

        '── Row 2 Panel ────────────────────────────────────────
        Me.pnlRow2.Location = New System.Drawing.Point(0, 75)
        Me.pnlRow2.Size = New System.Drawing.Size(1190, 45)
        Me.pnlRow2.BackColor = System.Drawing.Color.FromArgb(245, 245, 245)

        Me.lblAssort.Text = "Assortment" : Me.lblAssort.Font = fntBold : Me.lblAssort.Location = New System.Drawing.Point(5, 3) : Me.lblAssort.Size = New System.Drawing.Size(85, 18) : Me.lblAssort.BackColor = System.Drawing.Color.Transparent
        Me.cmbAssort.Location = New System.Drawing.Point(5, 21) : Me.cmbAssort.Size = New System.Drawing.Size(150, 22) : Me.cmbAssort.Font = fnt : Me.cmbAssort.DropDownStyle = ComboBoxStyle.DropDown

        Me.lblSize.Text = "Size Range" : Me.lblSize.Font = fntBold : Me.lblSize.Location = New System.Drawing.Point(165, 3) : Me.lblSize.Size = New System.Drawing.Size(80, 18) : Me.lblSize.BackColor = System.Drawing.Color.Transparent
        Me.cmbSize.Location = New System.Drawing.Point(165, 21) : Me.cmbSize.Size = New System.Drawing.Size(100, 22) : Me.cmbSize.Font = fnt : Me.cmbSize.DropDownStyle = ComboBoxStyle.DropDown

        Me.lblNewPcs.Text = "Pcs" : Me.lblNewPcs.Font = fntBold : Me.lblNewPcs.Location = New System.Drawing.Point(275, 3) : Me.lblNewPcs.Size = New System.Drawing.Size(40, 18) : Me.lblNewPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtNewPcs.Location = New System.Drawing.Point(275, 21) : Me.txtNewPcs.Size = New System.Drawing.Size(60, 22) : Me.txtNewPcs.Font = fnt

        Me.lblNewCts.Text = "Cts" : Me.lblNewCts.Font = fntBold : Me.lblNewCts.Location = New System.Drawing.Point(345, 3) : Me.lblNewCts.Size = New System.Drawing.Size(40, 18) : Me.lblNewCts.BackColor = System.Drawing.Color.Transparent
        Me.txtNewCts.Location = New System.Drawing.Point(345, 21) : Me.txtNewCts.Size = New System.Drawing.Size(75, 22) : Me.txtNewCts.Font = fnt

        Me.cmdAdd.Text = "Add" : Me.cmdAdd.Location = New System.Drawing.Point(430, 18) : Me.cmdAdd.Size = New System.Drawing.Size(60, 24) : Me.cmdAdd.Font = fnt : Me.cmdAdd.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.lblPackNo.Text = "Pack List No" : Me.lblPackNo.Font = fntBold : Me.lblPackNo.Location = New System.Drawing.Point(500, 3) : Me.lblPackNo.Size = New System.Drawing.Size(90, 18) : Me.lblPackNo.BackColor = System.Drawing.Color.Transparent
        Me.txtPack.Location = New System.Drawing.Point(500, 21) : Me.txtPack.Size = New System.Drawing.Size(70, 22) : Me.txtPack.Font = fnt

        Me.lblType.Text = "Type" : Me.lblType.Font = fntBold : Me.lblType.Location = New System.Drawing.Point(580, 3) : Me.lblType.Size = New System.Drawing.Size(40, 18) : Me.lblType.BackColor = System.Drawing.Color.Transparent
        Me.txtType.Location = New System.Drawing.Point(580, 21) : Me.txtType.Size = New System.Drawing.Size(70, 22) : Me.txtType.Font = fnt

        Me.lblCategory.Text = "Category" : Me.lblCategory.Font = fntBold : Me.lblCategory.Location = New System.Drawing.Point(660, 3) : Me.lblCategory.Size = New System.Drawing.Size(65, 18) : Me.lblCategory.BackColor = System.Drawing.Color.Transparent
        Me.txtCategory.Location = New System.Drawing.Point(660, 21) : Me.txtCategory.Size = New System.Drawing.Size(80, 22) : Me.txtCategory.Font = fnt

        Me.lblSupCode.Text = "Sup Code" : Me.lblSupCode.Font = fntBold : Me.lblSupCode.Location = New System.Drawing.Point(750, 3) : Me.lblSupCode.Size = New System.Drawing.Size(70, 18) : Me.lblSupCode.BackColor = System.Drawing.Color.Transparent
        Me.txtSupCode.Location = New System.Drawing.Point(750, 21) : Me.txtSupCode.Size = New System.Drawing.Size(70, 22) : Me.txtSupCode.Font = fnt : Me.txtSupCode.ReadOnly = True

        Me.cmdAddPack.Text = "Add Pack" : Me.cmdAddPack.Location = New System.Drawing.Point(830, 18) : Me.cmdAddPack.Size = New System.Drawing.Size(80, 24) : Me.cmdAddPack.Font = fnt : Me.cmdAddPack.BackColor = System.Drawing.Color.FromArgb(210, 210, 157)

        Me.pnlRow2.Controls.AddRange({
            Me.lblAssort, Me.cmbAssort, Me.lblSize, Me.cmbSize,
            Me.lblNewPcs, Me.txtNewPcs, Me.lblNewCts, Me.txtNewCts, Me.cmdAdd,
            Me.lblPackNo, Me.txtPack, Me.lblType, Me.txtType,
            Me.lblCategory, Me.txtCategory, Me.lblSupCode, Me.txtSupCode, Me.cmdAddPack
        })

        '── Grid ───────────────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 125)
        Me.flxDetails.Size = New System.Drawing.Size(1180, 555)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        '── Totals Panel ───────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 685)
        Me.pnlTotals.Size = New System.Drawing.Size(1190, 32)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.cmdUpdate.Text = "Update Price" : Me.cmdUpdate.Font = fnt : Me.cmdUpdate.Location = New System.Drawing.Point(5, 4) : Me.cmdUpdate.Size = New System.Drawing.Size(90, 24) : Me.cmdUpdate.BackColor = System.Drawing.Color.FromArgb(210, 210, 157)
        Me.cmdSavePrice.Text = "Save New Price" : Me.cmdSavePrice.Font = fnt : Me.cmdSavePrice.Location = New System.Drawing.Point(100, 4) : Me.cmdSavePrice.Size = New System.Drawing.Size(105, 24) : Me.cmdSavePrice.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.lblTotPcsB.Text = "Tot Pcs:" : Me.lblTotPcsB.Font = fntBold : Me.lblTotPcsB.Location = New System.Drawing.Point(215, 7) : Me.lblTotPcsB.Size = New System.Drawing.Size(60, 18) : Me.lblTotPcsB.BackColor = System.Drawing.Color.Transparent
        Me.txtTotPcs.Location = New System.Drawing.Point(280, 5) : Me.txtTotPcs.Size = New System.Drawing.Size(70, 22) : Me.txtTotPcs.Font = fntBold : Me.txtTotPcs.ReadOnly = True : Me.txtTotPcs.TextAlign = HorizontalAlignment.Right : Me.txtTotPcs.Text = "0"

        Me.lblTotCtsB.Text = "Tot Cts:" : Me.lblTotCtsB.Font = fntBold : Me.lblTotCtsB.Location = New System.Drawing.Point(360, 7) : Me.lblTotCtsB.Size = New System.Drawing.Size(60, 18) : Me.lblTotCtsB.BackColor = System.Drawing.Color.Transparent
        Me.txtTotCts.Location = New System.Drawing.Point(425, 5) : Me.txtTotCts.Size = New System.Drawing.Size(80, 22) : Me.txtTotCts.Font = fntBold : Me.txtTotCts.ReadOnly = True : Me.txtTotCts.TextAlign = HorizontalAlignment.Right : Me.txtTotCts.Text = "0"

        Me.pnlTotals.Controls.AddRange({
            Me.cmdUpdate, Me.cmdSavePrice,
            Me.lblTotPcsB, Me.txtTotPcs, Me.lblTotCtsB, Me.txtTotCts
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlRow1)
        Me.Controls.Add(Me.pnlRow2)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlRow1 As System.Windows.Forms.Panel
    Friend WithEvents lblLotNo As System.Windows.Forms.Label
    Friend WithEvents txtLotNo As System.Windows.Forms.TextBox
    Friend WithEvents lblTotPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox
    Friend WithEvents lblBuyer As System.Windows.Forms.Label
    Friend WithEvents cmbSupplier As System.Windows.Forms.ComboBox
    Friend WithEvents opt2 As System.Windows.Forms.RadioButton
    Friend WithEvents opt3 As System.Windows.Forms.RadioButton
    Friend WithEvents chkNew As System.Windows.Forms.CheckBox
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents cmdExcel As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExportCSV As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents pnlRow2 As System.Windows.Forms.Panel
    Friend WithEvents lblAssort As System.Windows.Forms.Label
    Friend WithEvents cmbAssort As System.Windows.Forms.ComboBox
    Friend WithEvents lblSize As System.Windows.Forms.Label
    Friend WithEvents cmbSize As System.Windows.Forms.ComboBox
    Friend WithEvents lblNewPcs As System.Windows.Forms.Label
    Friend WithEvents txtNewPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblNewCts As System.Windows.Forms.Label
    Friend WithEvents txtNewCts As System.Windows.Forms.TextBox
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents lblPackNo As System.Windows.Forms.Label
    Friend WithEvents txtPack As System.Windows.Forms.TextBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents txtType As System.Windows.Forms.TextBox
    Friend WithEvents lblCategory As System.Windows.Forms.Label
    Friend WithEvents txtCategory As System.Windows.Forms.TextBox
    Friend WithEvents lblSupCode As System.Windows.Forms.Label
    Friend WithEvents txtSupCode As System.Windows.Forms.TextBox
    Friend WithEvents cmdAddPack As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents cmdUpdate As System.Windows.Forms.Button
    Friend WithEvents cmdSavePrice As System.Windows.Forms.Button
    Friend WithEvents lblTotPcsB As System.Windows.Forms.Label
    Friend WithEvents txtTotPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCtsB As System.Windows.Forms.Label
    Friend WithEvents txtTotCts As System.Windows.Forms.TextBox

End Class