﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_Parcels
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        '── Controls ───────────────────────────────────────────
        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlToolbar = New System.Windows.Forms.Panel()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnSelectAll = New System.Windows.Forms.Button()
        Me.btnDeselectAll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtRecordCount = New System.Windows.Forms.TextBox()
        Me.flxDetails = New System.Windows.Forms.DataGridView()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "Grading Parcels"
        Me.Size = New System.Drawing.Size(560, 620)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title Panel ────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "Grading Parcels"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Toolbar Panel ──────────────────────────────────────
        Me.pnlToolbar.Location = New System.Drawing.Point(0, 35)
        Me.pnlToolbar.Size = New System.Drawing.Size(554, 40)
        Me.pnlToolbar.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        ' Buttons
        Dim btns() As System.Windows.Forms.Button = {
            Me.btnRefresh, Me.btnSave, Me.btnSelectAll, Me.btnDeselectAll, Me.btnExit
        }
        Dim btnTxts() As String = {"Refresh", "Save", "Select All", "Deselect All", "Exit"}
        Dim btnColors() As System.Drawing.Color = {
            System.Drawing.Color.FromArgb(157, 183, 235),
            System.Drawing.Color.FromArgb(157, 210, 157),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(210, 210, 157),
            System.Drawing.Color.FromArgb(235, 183, 157)
        }
        For idx As Integer = 0 To btns.Length - 1
            btns(idx).Text = btnTxts(idx)
            btns(idx).Location = New System.Drawing.Point(5 + idx * 90, 5)
            btns(idx).Size = New System.Drawing.Size(82, 28)
            btns(idx).Font = fnt
            btns(idx).BackColor = btnColors(idx)
            Me.pnlToolbar.Controls.Add(btns(idx))
        Next

        Me.txtRecordCount.Location = New System.Drawing.Point(460, 8)
        Me.txtRecordCount.Size = New System.Drawing.Size(85, 22)
        Me.txtRecordCount.Font = fnt
        Me.txtRecordCount.ReadOnly = True
        Me.txtRecordCount.TextAlign = HorizontalAlignment.Center
        Me.txtRecordCount.Text = "Record Count"
        Me.pnlToolbar.Controls.Add(Me.txtRecordCount)

        '── DataGridView ───────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 80)
        Me.flxDetails.Size = New System.Drawing.Size(544, 525)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or
                                  AnchorStyles.Left Or AnchorStyles.Right

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlToolbar)
        Me.Controls.Add(Me.flxDetails)

        Me.ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlToolbar As System.Windows.Forms.Panel
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnSelectAll As System.Windows.Forms.Button
    Friend WithEvents btnDeselectAll As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtRecordCount As System.Windows.Forms.TextBox
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView

End Class