﻿Public Class frmHOT_Company

    Private ValidateOk As Boolean = False

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frmHOT_Company_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            Load_Hotel_Name()
        Catch ex As Exception
            ErrorLog("frmHOT_Company", "Form_Load")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD COMPANIES INTO COMBO BOX
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Hotel_Name()
        Try
            cmbHotel.Items.Clear()

            Using cmd As New SqlCommand("SELECT WAN_CODE, WAN_NAME FROM WAN_LOCA ORDER BY WAN_NAME", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim code As String = dr("WAN_CODE").ToString().Trim()
                        Dim name As String = dr("WAN_NAME").ToString().Trim()

                        ' If XX show all, otherwise only show matching company
                        If Prod_CODE = "XX" Then
                            cmbHotel.Items.Add(New CompanyItem(code, name))
                        ElseIf Prod_CODE = code Then
                            Dim item As New CompanyItem(code, name)
                            cmbHotel.Items.Add(item)
                            cmbHotel.SelectedItem = item
                        End If
                    End While
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error No : " & ex.HResult &
                            vbCrLf & "Description : " & ex.Message &
                            vbCrLf & "Function : Load Company Name",
                            Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' COMPANY SELECTED FROM COMBO — LOAD FIELDS
    '──────────────────────────────────────────────────────────────
    Private Sub cmbHotel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbHotel.SelectedIndexChanged
        Try
            If cmbHotel.SelectedItem Is Nothing Then Return

            Dim selected As CompanyItem = CType(cmbHotel.SelectedItem, CompanyItem)

            Using cmd As New SqlCommand(
                "SELECT * FROM WAN_LOCA WHERE WAN_CODE = @code", dbconn_Prod)
                cmd.Parameters.AddWithValue("@code", selected.Code)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    If dr.Read() Then
                        Prod_SITE_CODE = dr("WAN_CODE").ToString().Trim()
                        Prod_SITE_NAME = dr("WAN_NAME").ToString().Trim()

                        txtCompany.Text = dr("WAN_NAME").ToString().Trim()
                        txtCompanyCode.Text = dr("WAN_CODE").ToString().Trim()
                        txtStreet.Text = dr("STREET").ToString().Trim()
                        txtCity.Text = dr("City").ToString().Trim()
                        txtCountry.Text = dr("Country").ToString().Trim()
                        txtTelephone.Text = dr("Telephone").ToString().Trim()
                        txtFax.Text = dr("Fax").ToString().Trim()
                        txtEmail.Text = dr("Email").ToString().Trim()
                        txtEPF.Text = dr("EPFRegNo").ToString().Trim()
                        txtETF.Text = dr("ETFRegNo").ToString().Trim()
                        txtBankAC.Text = dr("BankACNo").ToString().Trim()
                    End If
                End Using
            End Using

        Catch ex As Exception
            ErrorLog("frmHOT_Company", "cmbHotel_SelectedIndexChanged")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' NEW BUTTON — CLEAR FORM
    '──────────────────────────────────────────────────────────────
    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        ClearAll()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SAVE BUTTON — INSERT OR UPDATE
    '──────────────────────────────────────────────────────────────
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            Validate()
            If Not ValidateOk Then
                MessageBox.Show("1.  Enter the Company Name" & vbCrLf & vbCrLf &
                                "2.  Enter the Company Code",
                                Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Check if company already exists
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM WAN_LOCA WHERE WAN_CODE = @code", dbconn_Prod)
                cmd.Parameters.AddWithValue("@code", txtCompanyCode.Text.Trim())
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If Not exists Then
                ' INSERT new company
                Using cmd As New SqlCommand(
                    "INSERT INTO WAN_LOCA VALUES (@name, @code, 'S', '1', @street, @city, '', " &
                    "@country, @tel, @fax, @email, '', @date, @epf, @bank, @etf)", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@name", txtCompany.Text.Trim())
                    cmd.Parameters.AddWithValue("@code", txtCompanyCode.Text.Trim())
                    cmd.Parameters.AddWithValue("@street", txtStreet.Text.Trim())
                    cmd.Parameters.AddWithValue("@city", txtCity.Text.Trim())
                    cmd.Parameters.AddWithValue("@country", txtCountry.Text.Trim())
                    cmd.Parameters.AddWithValue("@tel", txtTelephone.Text.Trim())
                    cmd.Parameters.AddWithValue("@fax", txtFax.Text.Trim())
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                    cmd.Parameters.AddWithValue("@date", Date.Now.ToString("MM/dd/yyyy"))
                    cmd.Parameters.AddWithValue("@epf", txtEPF.Text.Trim())
                    cmd.Parameters.AddWithValue("@bank", txtBankAC.Text.Trim())
                    cmd.Parameters.AddWithValue("@etf", txtETF.Text.Trim())
                    cmd.ExecuteNonQuery()
                End Using

                ' Also insert into PAY_SYS_PAR if not exists
                Dim parExists As Boolean = False
                Using cmd2 As New SqlCommand(
                    "SELECT COUNT(*) FROM PAY_SYS_PAR WHERE COMP_CODE = @code", dbconn_Prod)
                    cmd2.Parameters.AddWithValue("@code", txtCompanyCode.Text.Trim())
                    parExists = CInt(cmd2.ExecuteScalar()) > 0
                End Using

                If Not parExists Then
                    Using cmd3 As New SqlCommand(
                        "INSERT INTO PAY_SYS_PAR VALUES(@code, @date)", dbconn_Prod)
                        cmd3.Parameters.AddWithValue("@code", txtCompanyCode.Text.Trim())
                        cmd3.Parameters.AddWithValue("@date", Date.Now.ToString("MM/dd/yyyy"))
                        cmd3.ExecuteNonQuery()
                    End Using
                End If

            Else
                ' UPDATE existing company
                Dim confirm = MessageBox.Show(
                    "Do you want to amend " & txtCompanyCode.Text & " - " & txtCompany.Text & " ?",
                    Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If confirm = DialogResult.Yes Then
                    Using cmd As New SqlCommand(
                        "UPDATE WAN_LOCA SET WAN_NAME=@name, STREET=@street, CITY=@city, " &
                        "COUNTRY=@country, TELEPHONE=@tel, FAX=@fax, EMAIL=@email, " &
                        "EPFRegNo=@epf, ETFRegNo=@etf, BankACNo=@bank " &
                        "WHERE WAN_CODE=@code", dbconn_Prod)
                        cmd.Parameters.AddWithValue("@name", txtCompany.Text.Trim())
                        cmd.Parameters.AddWithValue("@street", txtStreet.Text.Trim())
                        cmd.Parameters.AddWithValue("@city", txtCity.Text.Trim())
                        cmd.Parameters.AddWithValue("@country", txtCountry.Text.Trim())
                        cmd.Parameters.AddWithValue("@tel", txtTelephone.Text.Trim())
                        cmd.Parameters.AddWithValue("@fax", txtFax.Text.Trim())
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                        cmd.Parameters.AddWithValue("@epf", txtEPF.Text.Trim())
                        cmd.Parameters.AddWithValue("@etf", txtETF.Text.Trim())
                        cmd.Parameters.AddWithValue("@bank", txtBankAC.Text.Trim())
                        cmd.Parameters.AddWithValue("@code", txtCompanyCode.Text.Trim())
                        cmd.ExecuteNonQuery()
                    End Using
                End If
            End If

            ClearAll()
            Load_Hotel_Name()

        Catch ex As Exception
            ErrorLog("frmHOT_Company", "cmdSave_Click")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' VALIDATE
    '──────────────────────────────────────────────────────────────
    Private Sub Validate()
        ValidateOk = True
        If txtCompany.Text.Trim().Length = 0 Then
            ValidateOk = False
        ElseIf txtCompanyCode.Text.Trim().Length = 0 Then
            ValidateOk = False
        End If
    End Sub

    '──────────────────────────────────────────────────────────────
    ' CLEAR ALL FIELDS
    '──────────────────────────────────────────────────────────────
    Private Sub ClearAll()
        txtCompany.Text = ""
        txtCompanyCode.Text = ""
        txtStreet.Text = ""
        txtCity.Text = ""
        txtCountry.Text = ""
        txtTelephone.Text = ""
        txtFax.Text = ""
        txtEmail.Text = ""
        txtEPF.Text = ""
        txtETF.Text = ""
        txtBankAC.Text = ""
    End Sub

    '──────────────────────────────────────────────────────────────
    ' EXIT BUTTON
    '──────────────────────────────────────────────────────────────
    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Try
            Me.Close()
        Catch ex As Exception
            ErrorLog("frmHOT_Company", "cmdExit_Click")
        End Try
    End Sub

End Class

'──────────────────────────────────────────────────────────────────
' HELPER CLASS — ComboBox item for company code + name
'──────────────────────────────────────────────────────────────────
Public Class CompanyItem
    Public Property Code As String
    Public Property Name As String

    Public Sub New(code As String, name As String)
        Me.Code = code
        Me.Name = name
    End Sub

    Public Overrides Function ToString() As String
        Return Code & "  -  " & Name
    End Function
End Class