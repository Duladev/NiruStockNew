﻿Public Class frm_Grading_Packet

    ' FORM LOAD
    Private Sub frm_Grading_Packet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            ClearFields()
        Catch ex As Exception
            ErrorLog("frm_Grading_Packet", "Form_Load")
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SETUP DATAGRIDVIEW COLUMNS
    '──────────────────────────────────────────────────────────────
    Private Sub SetupGrid()
        flxPacket.Columns.Clear()
        flxPacket.AutoGenerateColumns = False
        flxPacket.AllowUserToAddRows = False
        flxPacket.AllowUserToDeleteRows = False
        flxPacket.ReadOnly = True
        flxPacket.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxPacket.BackgroundColor = System.Drawing.Color.White
        flxPacket.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim cols() As String = {"Parcel No", "Pkt No", "Pkt Pcs", "Pkt Cts", "Make"}
        Dim names() As String = {"ParNo", "PktNo", "PktPcs", "PktCts", "PktType"}
        Dim widths() As Integer = {120, 80, 80, 80, 160}

        For i As Integer = 0 To cols.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = cols(i)
            col.Name = names(i)
            col.Width = widths(i)
            If i >= 2 AndAlso i <= 3 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxPacket.Columns.Add(col)
        Next
    End Sub

    ' PARCEL NO — ENTER KEY
    Private Sub txtParNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If ParcelFound(txtParNo.Text.Trim()) Then
                txtParNo.Text = txtParNo.Text.Trim().ToUpper()
                GetNewPacket()
                txtPktPcs.Focus()
            Else
                MessageBox.Show("Invalid Parcel", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                ClearFields()
                txtParNo.Focus()
            End If
        End If
    End Sub

    ' PACKET NO — ENTER KEY (LOAD EXISTING PACKET)
    Private Sub txtPktNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Try
                Using cmd As New SqlCommand(
                    "SELECT * FROM tblGrading_Packet WHERE ParNo=@par AND PktNo=@pkt",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        If dr.Read() Then
                            txtPktPcs.Text = dr("PktPcs").ToString()
                            txtPktCts.Text = Format(Convert.ToDouble(dr("PktCts")), "#0.000")
                            Dim pktType As String = dr("PktType").ToString()
                            For Each rb As RadioButton In grpModel.Controls.OfType(Of RadioButton)()
                                If rb.Text = pktType Then rb.Checked = True
                            Next
                        Else
                            MessageBox.Show("Invalid Parcel and Packet", Me.Text,
                                            MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End Using
                End Using
            Catch ex As Exception
                ErrorLog("frm_Grading_Packet", "txtPktNo_KeyPress")
            End Try
        End If
    End Sub

    ' PCS — ENTER MOVES TO CTS
    Private Sub txtPktPcs_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktPcs.KeyPress
        NumericOnly(e, txtPktPcs.Text)
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            txtPktCts.Focus()
        End If
    End Sub

    Private Sub txtPktCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPktCts.KeyPress
        NumericOnly(e, txtPktCts.Text)
    End Sub

    ' TOOLBAR BUTTONS
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        ClearFields()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Save()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    ' SAVE
    Private Sub Save()
        Try
            If Not ParcelFound(txtParNo.Text.Trim()) Then Return

            If cmbSize.Text.Trim() = "" Then
                MessageBox.Show("Please select the Size", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If
            If txtPktPcs.Text.Trim() = "" Then
                MessageBox.Show("Please enter the Pcs", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If
            If txtPktCts.Text.Trim() = "" Then
                MessageBox.Show("Please enter the Cts", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Get total pcs in parcel
            Dim intTotPcs As Double = 0
            Using cmd As New SqlCommand(
                "SELECT SUM(PolPcs) AS TotPcs FROM tblInvoice WHERE ParcelNo=@par",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result IsNot DBNull.Value AndAlso result IsNot Nothing Then
                    intTotPcs = Convert.ToDouble(result)
                End If
            End Using

            ' Get already issued pcs
            Dim intIssPcs As Double = 0
            Using cmd As New SqlCommand(
                "SELECT SUM(PktPcs) AS TotPcs FROM tblGrading_Packet WHERE ParNo=@par",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result IsNot DBNull.Value AndAlso result IsNot Nothing Then
                    intIssPcs = Convert.ToDouble(result)
                End If
            End Using

            If intTotPcs < intIssPcs + Convert.ToDouble(txtPktPcs.Text) Then
                MessageBox.Show("Not enough Pcs in the Parcel", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Check if packet already exists
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_Packet WHERE ParNo=@par AND PktNo=@pkt",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If exists Then
                MessageBox.Show("Already Existing Packet", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Get selected model
            Dim strModel As String = ""
            For Each rb As RadioButton In grpModel.Controls.OfType(Of RadioButton)()
                If rb.Checked Then strModel = rb.Text : Exit For
            Next

            ' Ensure parcel record exists
            Dim parcelExists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_Parcel WHERE ParNo=@par", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                parcelExists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If Not parcelExists Then
                Using cmd As New SqlCommand(
                    "INSERT INTO tblGrading_Parcel(ParNo,Complete) VALUES(@par,0)",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                    cmd.ExecuteNonQuery()
                End Using
            End If

            ' Insert packet
            Using cmd As New SqlCommand(
                "INSERT INTO tblGrading_Packet(Department,ParNo,PktNo,PktPcs,PktCts,PktType,PktSize) " &
                "VALUES('Colombo',@par,@pkt,@pcs,@cts,@type,@size)", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim().ToUpper())
                cmd.Parameters.AddWithValue("@pkt", txtPktNo.Text.Trim())
                cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(txtPktPcs.Text))
                cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(txtPktCts.Text))
                cmd.Parameters.AddWithValue("@type", strModel)
                cmd.Parameters.AddWithValue("@size", cmbSize.Text.Trim())
                cmd.ExecuteNonQuery()
            End Using

            ' Reset entry fields
            txtPktNo.Text = ""
            txtPktPcs.Text = ""
            txtPktCts.Text = ""
            cmbSize.Text = ""

            ' Reset radio buttons
            For Each rb As RadioButton In grpModel.Controls.OfType(Of RadioButton)()
                If rb.Text = "Niru Make" Then rb.Checked = True
            Next

            GetNewPacket()

        Catch ex As Exception
            ErrorLog("frm_Grading_Packet", "Save")
        End Try
    End Sub

    ' PARCEL FOUND CHECK
    Private Function ParcelFound(parcelNo As String) As Boolean
        Try
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblInvoice WHERE ParcelNo=@par", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", parcelNo)
                Return CInt(cmd.ExecuteScalar()) > 0
            End Using
        Catch
            Return False
        End Try
    End Function

    ' GET NEXT PACKET NO + REFRESH GRID
    Private Sub GetNewPacket()
        Try
            ' Get next packet number
            Using cmd As New SqlCommand(
                "SELECT MAX(PktNo) AS MaxPktNo FROM tblGrading_Packet WHERE ParNo=@par",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result IsNot DBNull.Value AndAlso result IsNot Nothing Then
                    txtPktNo.Text = Format(CInt(result) + 1, "000")
                Else
                    txtPktNo.Text = "001"
                End If
            End Using

            ' Load grid
            flxPacket.Rows.Clear()
            Using cmd As New SqlCommand(
                "SELECT ParNo, PktNo, PktPcs, PktCts, PktType FROM tblGrading_Packet " &
                "WHERE ParNo=@par ORDER BY PktNo", dbconn_Prod)
                cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        flxPacket.Rows.Add(
                            dr("ParNo").ToString(),
                            dr("PktNo").ToString(),
                            dr("PktPcs").ToString(),
                            Format(Convert.ToDouble(dr("PktCts")), "#0.000"),
                            dr("PktType").ToString()
                        )
                    End While
                End Using
            End Using

            txtRecordCount.Text = "Records : " & flxPacket.Rows.Count

        Catch ex As Exception
            ErrorLog("frm_Grading_Packet", "GetNewPacket")
        End Try
    End Sub

    ' CLEAR ALL FIELDS
    Private Sub ClearFields()
        txtParNo.Text = ""
        txtPktNo.Text = ""
        txtPktPcs.Text = ""
        txtPktCts.Text = ""
        cmbSize.Text = ""
        flxPacket.Rows.Clear()
        txtRecordCount.Text = "Record Count"

        ' Default radio to Niru Make
        For Each rb As RadioButton In grpModel.Controls.OfType(Of RadioButton)()
            rb.Checked = (rb.Text = "Niru Make")
        Next
    End Sub

End Class