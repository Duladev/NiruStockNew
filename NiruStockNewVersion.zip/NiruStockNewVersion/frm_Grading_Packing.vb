﻿Imports System.Data.SqlClient

Public Class frm_Grading_Packing

    ' FORM LOAD
    Private Sub frm_Grading_Packing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_Orders()
        Catch ex As Exception
            ErrorLog("frm_Grading_Packing", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("Tahoma", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)
        flxDetails.RowTemplate.Height = 22

        ' Checkbox column — FM2 (selected for packing)
        Dim chkCol As New DataGridViewCheckBoxColumn()
        chkCol.HeaderText = "Select"
        chkCol.Name = "FM2"
        chkCol.Width = 55
        flxDetails.Columns.Add(chkCol)

        ' Text columns
        Dim headers() As String = {"Parcel No", "Grp", "Pkt No", "Box No", "Pcs", "Cts", "FM", "Assortment", "ID", "Order No", "Doc ID", "Pack No"}
        Dim names() As String = {"ParNo", "Grp", "PktNo", "BoxNo", "Pcs", "Cts", "FM", "Assortment", "ID", "OrderNo", "DocID", "PackNo"}
        Dim widths() As Integer = {90, 50, 60, 60, 60, 70, 40, 100, 60, 90, 70, 75}
        ReadOnly () As Boolean = {True, True, True, True, True, True, True, False, True, False, False, False}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = readOnly(idx)
            If idx = 4 OrElse idx = 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next

        ' Order No column — use ComboBox column
        Dim cboCol As New DataGridViewComboBoxColumn()
        cboCol.HeaderText = "Order No (Edit)"
        cboCol.Name = "OrderNoEdit"
        cboCol.Width = 110
        flxDetails.Columns.Add(cboCol)
    End Sub

    ' LOAD ORDERS INTO COMBO COLUMN
    Private Sub Load_Orders()
        Try
            cmbOrder.Items.Clear()
            Dim cboCol As DataGridViewComboBoxColumn =
                CType(flxDetails.Columns("OrderNoEdit"), DataGridViewComboBoxColumn)
            cboCol.Items.Clear()
            cboCol.Items.Add("")

            Using cmd As New SqlCommand(
                "SELECT OrderNo FROM tblNoneOrders WHERE Complete='N' ORDER BY OrderNo",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim orderNo As String = dr("OrderNo").ToString().Trim()
                        cmbOrder.Items.Add(orderNo)
                        cboCol.Items.Add(orderNo)
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_Packing", "Load_Orders")
        End Try
    End Sub

    ' PARCEL NO — ENTER KEY
    Private Sub txtParNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtParNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            If txtParNo.Text.Trim() = "" Then Return

            txtParNo.Text = txtParNo.Text.Trim().ToUpper()
            flxDetails.Rows.Clear()

            Try
                Using cmd As New SqlCommand(
                    "SELECT * FROM tblGrading_Box WHERE ParNo=@par ORDER BY BoxNo",
                    dbconn_Prod)
                    cmd.Parameters.AddWithValue("@par", txtParNo.Text.Trim())
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        While dr.Read()
                            Dim rowIdx As Integer = flxDetails.Rows.Add()
                            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)

                            Dim fm2 As Boolean = Convert.ToBoolean(
                                If(dr("FM2").ToString() = "1", True, False))

                            row.Cells("FM2").Value = fm2
                            row.Cells("ParNo").Value = dr("ParNo").ToString().Trim()
                            row.Cells("Grp").Value = dr("Grp").ToString().Trim()
                            row.Cells("PktNo").Value = dr("PktNo").ToString().Trim()
                            row.Cells("BoxNo").Value = dr("BoxNo").ToString().Trim()
                            row.Cells("Pcs").Value = dr("Pcs").ToString()
                            row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                            row.Cells("FM").Value = dr("FM").ToString().Trim()
                            row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                            row.Cells("ID").Value = dr("ID").ToString().Trim()
                            row.Cells("OrderNo").Value = dr("OrderNo").ToString().Trim()
                            row.Cells("DocID").Value = dr("DocID").ToString().Trim()
                            row.Cells("PackNo").Value = dr("PackNo").ToString().Trim()
                            row.Cells("OrderNoEdit").Value = dr("OrderNo").ToString().Trim()
                        End While
                    End Using
                End Using

                CalculateTotals()

            Catch ex As Exception
                ErrorLog("frm_Grading_Packing", "txtParNo_KeyPress")
            End Try
        End If
    End Sub

    ' CHECKBOX CHANGED 
    Private Sub flxDetails_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellValueChanged
        If e.ColumnIndex = flxDetails.Columns("FM2").Index Then
            CalculateTotals()
        End If
    End Sub

    Private Sub flxDetails_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles flxDetails.CurrentCellDirtyStateChanged
        If flxDetails.IsCurrentCellDirty Then
            flxDetails.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub


    Private Sub CalculateTotals()
        Dim vPcs As Double = 0
        Dim vCts As Double = 0

        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("FM2").Value) Then
                vPcs += Convert.ToDouble(If(row.Cells("Pcs").Value?.ToString() = "", "0", row.Cells("Pcs").Value?.ToString()))
                vCts += Convert.ToDouble(If(row.Cells("Cts").Value?.ToString() = "", "0", row.Cells("Cts").Value?.ToString()))
            End If
        Next

        txtPcs.Text = vPcs.ToString()
        txtCts.Text = Format(Math.Round(vCts, 3), "#0.000")
    End Sub


    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If flxDetails.Rows.Count = 0 Then Return

            ' Validate Pack No for checked rows
            For Each row As DataGridViewRow In flxDetails.Rows
                If Convert.ToBoolean(row.Cells("FM2").Value) Then
                    Dim packNo As String = row.Cells("PackNo").Value?.ToString().Trim()
                    If packNo = "" OrElse Not IsNumeric(packNo) Then
                        MessageBox.Show("Invalid Packing List No", Me.Text,
                                        MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Return
                    End If
                End If
            Next

            Dim confirm = MessageBox.Show("Are you sure?", Me.Text,
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.No Then Return

            ' Save each row
            For Each row As DataGridViewRow In flxDetails.Rows
                Dim id As String = row.Cells("ID").Value?.ToString().Trim()
                Dim isChecked As Boolean = Convert.ToBoolean(row.Cells("FM2").Value)

                ' Check record exists
                Using cmd As New SqlCommand(
                    "SELECT COUNT(*) FROM tblGrading_Box WHERE ID=@id", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@id", id)
                    If CInt(cmd.ExecuteScalar()) = 0 Then Continue For
                End Using

                If isChecked Then
                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_Box SET FM2=1, Assortment=@assort, " &
                        "OrderNo=@order, DocID=@doc, PackNo=@pack WHERE ID=@id",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@assort", row.Cells("Assortment").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@order", row.Cells("OrderNoEdit").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@doc", row.Cells("DocID").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@pack", row.Cells("PackNo").Value?.ToString().Trim())
                        cmd.Parameters.AddWithValue("@id", id)
                        cmd.ExecuteNonQuery()
                    End Using
                Else
                    Using cmd As New SqlCommand(
                        "UPDATE tblGrading_Box SET FM2=0, Assortment='', " &
                        "OrderNo='', DocID='', PackNo=0 WHERE ID=@id",
                        dbconn_Prod)
                        cmd.Parameters.AddWithValue("@id", id)
                        cmd.ExecuteNonQuery()
                    End Using
                End If
            Next

            MessageBox.Show("Packing List Saved", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Reset
            txtParNo.Text = ""
            flxDetails.Rows.Clear()
            txtPcs.Text = ""
            txtCts.Text = ""

        Catch ex As Exception
            ErrorLog("frm_Grading_Packing", "cmdSave_Click")
        End Try
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class