﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class frm_GrdReports

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frm_GrdReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.StartPosition = FormStartPosition.CenterScreen
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SHARED HELPER — open and preview a Crystal Report
    '──────────────────────────────────────────────────────────────
    Private Sub OpenReport(rptFileName As String)
        Try
            Dim rptPath As String = IO.Path.Combine(Prod_RPT_PATH, rptFileName)
            If Not IO.File.Exists(rptPath) Then
                MessageBox.Show("Report file not found:" & vbCrLf & rptPath, Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            PrintReport(rptPath)
        Catch ex As Exception
            ErrorLog("frm_GrdReports", "OpenReport - " & rptFileName)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' REPORT BUTTONS (95 reports)
    '──────────────────────────────────────────────────────────────
    Private Sub btnStockInfo_Click(s As Object, e As EventArgs) Handles btnStockInfo.Click
        OpenReport("crptNiruStockInfo.rpt")
    End Sub

    Private Sub btnSizingStockInfo_Click(s As Object, e As EventArgs) Handles btnSizingStockInfo.Click
        OpenReport("crptNiruStockInfoSizing.rpt")
    End Sub

    Private Sub btnStockSummary_Click(s As Object, e As EventArgs) Handles btnStockSummary.Click
        OpenReport("crptAssortStock.rpt")
    End Sub

    Private Sub btnPacketInfo_Click(s As Object, e As EventArgs) Handles btnPacketInfo.Click
        OpenReport("crptIssRetPkt.rpt")
    End Sub

    Private Sub btnSizingPacketInfo_Click(s As Object, e As EventArgs) Handles btnSizingPacketInfo.Click
        OpenReport("crptSizingIssRetPkt.rpt")
    End Sub

    Private Sub btnPackingList_Click(s As Object, e As EventArgs) Handles btnPackingList.Click
        OpenReport("crptGRD_PackingList.rpt")
    End Sub

    Private Sub btnSizingDetails_Click(s As Object, e As EventArgs) Handles btnSizingDetails.Click
        OpenReport("crptSizeReturnTypes.rpt")
    End Sub

    Private Sub btnColorSummaryNew_Click(s As Object, e As EventArgs) Handles btnColorSummaryNew.Click
        OpenReport("crptColorSummaryNew.rpt")
    End Sub

    Private Sub btnMakeSummaryNew_Click(s As Object, e As EventArgs) Handles btnMakeSummaryNew.Click
        OpenReport("crptMakeSummaryNew.rpt")
    End Sub

    Private Sub btnClaritySummaryNew_Click(s As Object, e As EventArgs) Handles btnClaritySummaryNew.Click
        OpenReport("crptClaritySummaryNew.rpt")
    End Sub

    Private Sub btnParcelBeforeFloNew_Click(s As Object, e As EventArgs) Handles btnParcelBeforeFloNew.Click
        OpenReport("crptParReturnDetails2New.rpt")
    End Sub

    Private Sub btnParcelDetailsNew_Click(s As Object, e As EventArgs) Handles btnParcelDetailsNew.Click
        OpenReport("crptParReturnDetailsNew.rpt")
    End Sub

    Private Sub btnParcelDetailsSummary_Click(s As Object, e As EventArgs) Handles btnParcelDetailsSummary.Click
        OpenReport("crptParReturnDetailsSum.rpt")
    End Sub

    Private Sub btnSizingSummaryNew_Click(s As Object, e As EventArgs) Handles btnSizingSummaryNew.Click
        OpenReport("crptSizeReturnSummaryNew.rpt")
    End Sub

    Private Sub btnCheckingSummary_Click(s As Object, e As EventArgs) Handles btnCheckingSummary.Click
        OpenReport("crptCheckingSummary.rpt")
    End Sub

    Private Sub btnPacketDetails_Click(s As Object, e As EventArgs) Handles btnPacketDetails.Click
        OpenReport("crptPacketDetails.rpt")
    End Sub

    Private Sub btnParcelValue_Click(s As Object, e As EventArgs) Handles btnParcelValue.Click
        OpenReport("crptGRD_ParcelValue.rpt")
    End Sub

    Private Sub btnSizingSummaryNewBtn_Click(s As Object, e As EventArgs) Handles btnSizingSummaryNewBtn.Click
        OpenReport("crptSizeReturnSummaryNew.rpt")
    End Sub

    Private Sub btnEmpProduction_Click(s As Object, e As EventArgs) Handles btnEmpProduction.Click
        OpenReport("crptEmpProd.rpt")
    End Sub

    Private Sub btnEmpProdEmpWise_Click(s As Object, e As EventArgs) Handles btnEmpProdEmpWise.Click
        OpenReport("crptEmpProdEmpWise.rpt")
    End Sub

    Private Sub btnEmpProdSummary_Click(s As Object, e As EventArgs) Handles btnEmpProdSummary.Click
        OpenReport("crptEmpProdEmpSummary.rpt")
    End Sub

    Private Sub btnForevermarkList_Click(s As Object, e As EventArgs) Handles btnForevermarkList.Click
        OpenReport("crptGradingBoxNew.rpt")
    End Sub

    Private Sub btnFMSticker_Click(s As Object, e As EventArgs) Handles btnFMSticker.Click
        OpenReport("crptFMSticker.rpt")
    End Sub

    Private Sub btnFMStickerNew_Click(s As Object, e As EventArgs) Handles btnFMStickerNew.Click
        OpenReport("crptGradingFMSticker.rpt")
    End Sub

    Private Sub btnPacketPrintNew_Click(s As Object, e As EventArgs) Handles btnPacketPrintNew.Click
        OpenReport("GrdPKTSLEEVE_Full2.rpt")
    End Sub

    Private Sub btnAssortingPNL_Click(s As Object, e As EventArgs) Handles btnAssortingPNL.Click
        OpenReport("crptProfitLoss.rpt")
    End Sub

    Private Sub btnAssortingPNLSummary_Click(s As Object, e As EventArgs) Handles btnAssortingPNLSummary.Click
        OpenReport("crptProfitLossSum.rpt")
    End Sub

    Private Sub btnPackingListNiru_Click(s As Object, e As EventArgs) Handles btnPackingListNiru.Click
        OpenReport("crptPackingList.rpt")
    End Sub

    Private Sub btnBoxLabelsNew_Click(s As Object, e As EventArgs) Handles btnBoxLabelsNew.Click
        OpenReport("crptBoxLabelsNew.rpt")
    End Sub

    Private Sub btnBoxLabelsNiru_Click(s As Object, e As EventArgs) Handles btnBoxLabelsNiru.Click
        OpenReport("crptBoxLabelsNiru.rpt")
    End Sub

    Private Sub btnMainStickerNiru_Click(s As Object, e As EventArgs) Handles btnMainStickerNiru.Click
        OpenReport("crptMainSticker.rpt")
    End Sub

    Private Sub btnSubLabelsNiru_Click(s As Object, e As EventArgs) Handles btnSubLabelsNiru.Click
        OpenReport("crptMainStickerSub.rpt")
    End Sub

    Private Sub btnSubMainStickerNiru_Click(s As Object, e As EventArgs) Handles btnSubMainStickerNiru.Click
        OpenReport("crptMainStickerSubGrp.rpt")
    End Sub

    Private Sub btnPackingListBundle_Click(s As Object, e As EventArgs) Handles btnPackingListBundle.Click
        OpenReport("crptPackingList2019.rpt")
    End Sub

    Private Sub btnBoxLabelsBundle_Click(s As Object, e As EventArgs) Handles btnBoxLabelsBundle.Click
        OpenReport("crptBoxLabelsNiru2019.rpt")
    End Sub

    Private Sub btnSubLabelsBundle_Click(s As Object, e As EventArgs) Handles btnSubLabelsBundle.Click
        OpenReport("crptMainStickerSub2019.rpt")
    End Sub

    Private Sub btnPackingListHK_Click(s As Object, e As EventArgs) Handles btnPackingListHK.Click
        OpenReport("crptGRD_PackingListHK.rpt")
    End Sub

    Private Sub btnPackingListHKMix_Click(s As Object, e As EventArgs) Handles btnPackingListHKMix.Click
        OpenReport("crptGRD_PackingListHK_Mix.rpt")
    End Sub

    Private Sub btnPackingListFM_Click(s As Object, e As EventArgs) Handles btnPackingListFM.Click
        OpenReport("crptGRD_PackingListFM.rpt")
    End Sub

    Private Sub btnPackingListFMID_Click(s As Object, e As EventArgs) Handles btnPackingListFMID.Click
        OpenReport("crptGRD_PackingListFMNew.rpt")
    End Sub

    Private Sub btnBoxLabelsID_Click(s As Object, e As EventArgs) Handles btnBoxLabelsID.Click
        OpenReport("crptBoxLabelsNewTest.rpt")
    End Sub

    Private Sub btnBoxLabelsIDClient_Click(s As Object, e As EventArgs) Handles btnBoxLabelsIDClient.Click
        OpenReport("crptBoxLabelsNewClient.rpt")
    End Sub

    Private Sub btnPackingListClient_Click(s As Object, e As EventArgs) Handles btnPackingListClient.Click
        OpenReport("crptGRD_PackingListClient.rpt")
    End Sub

    Private Sub btnSubLabelsClient_Click(s As Object, e As EventArgs) Handles btnSubLabelsClient.Click
        OpenReport("crptMainStickerSubClient.rpt")
    End Sub

    Private Sub btnPackingListClientNY_Click(s As Object, e As EventArgs) Handles btnPackingListClientNY.Click
        OpenReport("crptGRD_PackingListClientNY.rpt")
    End Sub

    Private Sub btnBoxLabelsClientNY_Click(s As Object, e As EventArgs) Handles btnBoxLabelsClientNY.Click
        OpenReport("crptBoxLabelsNewClientNY.rpt")
    End Sub

    Private Sub btnSubLabelsClientNY_Click(s As Object, e As EventArgs) Handles btnSubLabelsClientNY.Click
        OpenReport("crptMainStickerSubNY.rpt")
    End Sub

    Private Sub btnPackingListNY_Click(s As Object, e As EventArgs) Handles btnPackingListNY.Click
        OpenReport("crptGRD_PackingListNY.rpt")
    End Sub

    Private Sub btnBoxLabelsNY_Click(s As Object, e As EventArgs) Handles btnBoxLabelsNY.Click
        OpenReport("crptBoxLabelsNY.rpt")
    End Sub

    Private Sub btnAssortingPNLRep_Click(s As Object, e As EventArgs) Handles btnAssortingPNLRep.Click
        OpenReport("crptProfitLossSum2021.rpt")
    End Sub

    Private Sub btnAssortingPNLRA_Click(s As Object, e As EventArgs) Handles btnAssortingPNLRA.Click
        OpenReport("crptProfitLossSum2021_4.rpt")
    End Sub

    Private Sub btnPackingListRA_Click(s As Object, e As EventArgs) Handles btnPackingListRA.Click
        OpenReport("crptGRD_PackingListClientTFT.rpt")
    End Sub

    Private Sub btnBoxLabelsIDRA_Click(s As Object, e As EventArgs) Handles btnBoxLabelsIDRA.Click
        OpenReport("crptBoxLabelsTFT.rpt")
    End Sub

    Private Sub btnSubLabelsRA_Click(s As Object, e As EventArgs) Handles btnSubLabelsRA.Click
        OpenReport("crptMainStickerSubTFT.rpt")
    End Sub

    Private Sub btnPackingListCountry_Click(s As Object, e As EventArgs) Handles btnPackingListCountry.Click
        OpenReport("crptGRD_PackingListCountry.rpt")
    End Sub

    Private Sub btnMainStickerCountry_Click(s As Object, e As EventArgs) Handles btnMainStickerCountry.Click
        OpenReport("crptMainStickerCountry.rpt")
    End Sub

    Private Sub btnSubLabelsCountry_Click(s As Object, e As EventArgs) Handles btnSubLabelsCountry.Click
        OpenReport("crptMainStickerSubCountry.rpt")
    End Sub

    Private Sub btnBoxLabelsCountry_Click(s As Object, e As EventArgs) Handles btnBoxLabelsCountry.Click
        OpenReport("crptBoxLabelsCountry.rpt")
    End Sub

    Private Sub btnStockInSection_Click(s As Object, e As EventArgs) Handles btnStockInSection.Click
        OpenReport("crptGradingStockInSectionPar.rpt")
    End Sub

    Private Sub btnPacketSticker_Click(s As Object, e As EventArgs) Handles btnPacketSticker.Click
        OpenReport("crptGradingPktSticker.rpt")
    End Sub

    Private Sub btnMainStickerClient_Click(s As Object, e As EventArgs) Handles btnMainStickerClient.Click
        OpenReport("crptMainStickerClient.rpt")
    End Sub

    Private Sub btnSizingProdEmpWise_Click(s As Object, e As EventArgs) Handles btnSizingProdEmpWise.Click
        OpenReport("crptEmpProdEmpWiseSize.rpt")
    End Sub

    Private Sub btnMainStickerFM_Click(s As Object, e As EventArgs) Handles btnMainStickerFM.Click
        OpenReport("crptMainStickerFM.rpt")
    End Sub

    Private Sub btnPackingListClient2_Click(s As Object, e As EventArgs) Handles btnPackingListClient2.Click
        OpenReport("crptGRD_PackingListSimple.rpt")
    End Sub

    Private Sub btnParcelAnalysis_Click(s As Object, e As EventArgs) Handles btnParcelAnalysis.Click
        OpenReport("crptAALotSum.rpt")
    End Sub

    Private Sub btnLotSummary_Click(s As Object, e As EventArgs) Handles btnLotSummary.Click
        OpenReport("crptGradingPackingListSum.rpt")
    End Sub

    Private Sub btnPackingListClientHK_Click(s As Object, e As EventArgs) Handles btnPackingListClientHK.Click
        OpenReport("crptGRD_PackingListClientHK.rpt")
    End Sub

    Private Sub btnFMStickerID_Click(s As Object, e As EventArgs) Handles btnFMStickerID.Click
        OpenReport("crptGradingFMStickerUpload.rpt")
    End Sub

    Private Sub btnSizingDetailsSum_Click(s As Object, e As EventArgs) Handles btnSizingDetailsSum.Click
        OpenReport("crptSizeReturnDetailsSum.rpt")
    End Sub

    Private Sub btnPackingListPkt_Click(s As Object, e As EventArgs) Handles btnPackingListPkt.Click
        OpenReport("crptGRD_PackingListPkt.rpt")
    End Sub

    Private Sub btnBoxLabelsPkt_Click(s As Object, e As EventArgs) Handles btnBoxLabelsPkt.Click
        OpenReport("crptBoxLabelsNewPkt.rpt")
    End Sub

    Private Sub btnAssortingPNLParcel_Click(s As Object, e As EventArgs) Handles btnAssortingPNLParcel.Click
        OpenReport("crptProfitLossSumPar.rpt")
    End Sub

    '──────────────────────────────────────────────────────────────
    ' EXIT
    '──────────────────────────────────────────────────────────────
    Private Sub btnExit_Click(s As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class