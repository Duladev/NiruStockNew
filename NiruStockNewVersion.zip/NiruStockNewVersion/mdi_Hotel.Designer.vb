﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class mdi_Hotel
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        '── Controls ───────────────────────────────────────────
        Me.lblHotelName = New System.Windows.Forms.Label()
        Me.MainMenuStrip = New System.Windows.Forms.MenuStrip()

        '── Menu Items — Data Entry ────────────────────────────
        Me.mRes1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCompany = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPacket = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSizPktEntry = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuParcel = New System.Windows.Forms.ToolStripMenuItem()
        Me.mLine11 = New System.Windows.Forms.ToolStripSeparator()
        Me.mExit = New System.Windows.Forms.ToolStripMenuItem()

        '── Menu Items — Processing ────────────────────────────
        Me.mFD = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExcel = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPackUpload = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuForever = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInvoicing = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadDetails = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPacking = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSep = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMPack = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBundle2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBundle = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSep2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuIssRet = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSizeIR = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssortCalc = New System.Windows.Forms.ToolStripMenuItem()

        '── Menu Items — System ────────────────────────────────
        Me.mSystem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.mUser = New System.Windows.Forms.ToolStripMenuItem()
        Me.munBackup = New System.Windows.Forms.ToolStripMenuItem()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "N I R U   S T O C K"
        Me.IsMdiContainer = True
        Me.WindowState = FormWindowState.Maximized
        Me.BackColor = System.Drawing.Color.White
        Me.Font = New System.Drawing.Font("Trebuchet MS", 9.75)
        Me.MainMenuStrip = Me.MainMenuStrip

        '── lblHotelName ───────────────────────────────────────
        Me.lblHotelName.Dock = DockStyle.Top
        Me.lblHotelName.TextAlign = ContentAlignment.MiddleCenter
        Me.lblHotelName.Font = New System.Drawing.Font("Arial", 18)
        Me.lblHotelName.BackColor = System.Drawing.Color.White
        Me.lblHotelName.ForeColor = System.Drawing.Color.Black
        Me.lblHotelName.Height = 40
        Me.lblHotelName.Visible = False

        '── MenuStrip ──────────────────────────────────────────
        Me.MainMenuStrip.Dock = DockStyle.Top
        Me.MainMenuStrip.Font = New System.Drawing.Font("Trebuchet MS", 9.75)

        '── Data Entry Menu ────────────────────────────────────
        Me.mRes1.Text = "Data Entry"
        Me.mnuCompany.Text = "Companies"
        Me.mnuPacket.Text = "Packet Entry"
        Me.mnuSizPktEntry.Text = "Sizing Packet Entry"
        Me.mnuParcel.Text = "Parcel"
        Me.mExit.Text = "&Exit"
        Me.mRes1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {
            Me.mnuCompany,
            Me.mnuPacket,
            Me.mnuSizPktEntry,
            Me.mnuParcel,
            Me.mLine11,
            Me.mExit
        })

        '── Processing Menu ────────────────────────────────────
        Me.mFD.Text = "Processing"
        Me.mnuExcel.Text = "Import Upload"
        Me.mnuExport.Text = "Export"
        Me.mnuPackUpload.Text = "Packing Upload"
        Me.mnuForever.Text = "Forevermark"
        Me.mnuInvoicing.Text = "Invoices"
        Me.UploadDetails.Text = "Upload Details"
        Me.mnuPacking.Text = "Packing List"
        Me.mnuPackage.Text = "Package"
        Me.mnuMPack.Text = "Mix Packages"
        Me.mnuBundle2.Text = "Bundle Module"
        Me.mnuBundle.Text = "Bundle Packages"
        Me.mnuIssRet.Text = "Issue/Return"
        Me.mnuSizeIR.Text = "Sizing Issue/Return"
        Me.mnuAssortCalc.Text = "Assortment Calculator"
        Me.mFD.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {
            Me.mnuExcel,
            Me.mnuExport,
            Me.mnuPackUpload,
            Me.mnuForever,
            Me.mnuInvoicing,
            Me.UploadDetails,
            Me.mnuPacking,
            Me.mnuSep,
            Me.mnuPackage,
            Me.mnuMPack,
            Me.mnuBundle2,
            Me.mnuBundle,
            Me.mnuSep2,
            Me.mnuIssRet,
            Me.mnuSizeIR,
            Me.mnuAssortCalc
        })

        '── System Menu ────────────────────────────────────────
        Me.mSystem.Text = "System"
        Me.mReports.Text = "Reports"
        Me.mUser.Text = "New Users"
        Me.munBackup.Text = "System Back Up"
        Me.mSystem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {
            Me.mReports,
            Me.mUser,
            Me.munBackup
        })

        '── Add menus to MenuStrip ─────────────────────────────
        Me.MainMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {
            Me.mRes1,
            Me.mFD,
            Me.mSystem
        })

        '── Assemble form ──────────────────────────────────────
        Me.Controls.Add(Me.lblHotelName)
        Me.Controls.Add(Me.MainMenuStrip)

        Me.ResumeLayout(False)
        Me.PerformLayout()
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents lblHotelName As System.Windows.Forms.Label
    Friend WithEvents MainMenuStrip As System.Windows.Forms.MenuStrip

    ' Data Entry
    Friend WithEvents mRes1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCompany As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPacket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSizPktEntry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuParcel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mLine11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mExit As System.Windows.Forms.ToolStripMenuItem

    ' Processing
    Friend WithEvents mFD As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExcel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPackUpload As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuForever As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuInvoicing As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadDetails As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPacking As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSep As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMPack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBundle2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBundle As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSep2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuIssRet As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSizeIR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssortCalc As System.Windows.Forms.ToolStripMenuItem

    ' System
    Friend WithEvents mSystem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mUser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents munBackup As System.Windows.Forms.ToolStripMenuItem

End Class