﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_Export
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblParNo = New System.Windows.Forms.Label()
        Me.txtParNo = New System.Windows.Forms.TextBox()
        Me.optParcel = New System.Windows.Forms.RadioButton()
        Me.optLot = New System.Windows.Forms.RadioButton()
        Me.cmdExport = New System.Windows.Forms.Button()
        Me.btnExportCSV = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.lblPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()
        Me.lblValue = New System.Windows.Forms.Label()
        Me.txtValue = New System.Windows.Forms.TextBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "PACKING LIST EXPORT"
        Me.Size = New System.Drawing.Size(980, 620)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "PACKING LIST EXPORT"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Top Panel ──────────────────────────────────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 35)
        Me.pnlTop.Size = New System.Drawing.Size(974, 45)
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.lblParNo.Text = "Parcel No / Lot No"
        Me.lblParNo.Font = fntBold
        Me.lblParNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblParNo.Location = New System.Drawing.Point(8, 5)
        Me.lblParNo.Size = New System.Drawing.Size(140, 18)
        Me.lblParNo.BackColor = System.Drawing.Color.Transparent

        Me.txtParNo.Location = New System.Drawing.Point(8, 22)
        Me.txtParNo.Size = New System.Drawing.Size(190, 22)
        Me.txtParNo.Font = fnt

        Me.optParcel.Text = "Parcel"
        Me.optParcel.Font = fnt
        Me.optParcel.Location = New System.Drawing.Point(210, 22)
        Me.optParcel.Size = New System.Drawing.Size(65, 20)
        Me.optParcel.Checked = True

        Me.optLot.Text = "Lot"
        Me.optLot.Font = fnt
        Me.optLot.Location = New System.Drawing.Point(280, 22)
        Me.optLot.Size = New System.Drawing.Size(50, 20)

        Me.cmdExport.Text = "Export Excel"
        Me.cmdExport.Location = New System.Drawing.Point(600, 15)
        Me.cmdExport.Size = New System.Drawing.Size(100, 26)
        Me.cmdExport.Font = fnt
        Me.cmdExport.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.btnExportCSV.Text = "Export CSV"
        Me.btnExportCSV.Location = New System.Drawing.Point(705, 15)
        Me.btnExportCSV.Size = New System.Drawing.Size(90, 26)
        Me.btnExportCSV.Font = fnt
        Me.btnExportCSV.BackColor = System.Drawing.Color.FromArgb(157, 183, 235)

        Me.btnExit.Text = "Exit"
        Me.btnExit.Location = New System.Drawing.Point(800, 15)
        Me.btnExit.Size = New System.Drawing.Size(70, 26)
        Me.btnExit.Font = fnt
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.pnlTop.Controls.AddRange({
            Me.lblParNo, Me.txtParNo, Me.optParcel, Me.optLot,
            Me.cmdExport, Me.btnExportCSV, Me.btnExit
        })

        '── DataGridView ───────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 85)
        Me.flxDetails.Size = New System.Drawing.Size(964, 480)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or
                                  AnchorStyles.Left Or AnchorStyles.Right

        '── Totals Panel ───────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 570)
        Me.pnlTotals.Size = New System.Drawing.Size(974, 32)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.lblPcs.Text = "Total Pcs:" : Me.lblPcs.Font = fntBold : Me.lblPcs.Location = New System.Drawing.Point(200, 7) : Me.lblPcs.Size = New System.Drawing.Size(70, 18) : Me.lblPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPcs.Location = New System.Drawing.Point(275, 5) : Me.txtPcs.Size = New System.Drawing.Size(60, 22) : Me.txtPcs.Font = fntBold : Me.txtPcs.ReadOnly = True : Me.txtPcs.TextAlign = HorizontalAlignment.Right

        Me.lblCts.Text = "Total Cts:" : Me.lblCts.Font = fntBold : Me.lblCts.Location = New System.Drawing.Point(345, 7) : Me.lblCts.Size = New System.Drawing.Size(70, 18) : Me.lblCts.BackColor = System.Drawing.Color.Transparent
        Me.txtCts.Location = New System.Drawing.Point(420, 5) : Me.txtCts.Size = New System.Drawing.Size(75, 22) : Me.txtCts.Font = fntBold : Me.txtCts.ReadOnly = True : Me.txtCts.TextAlign = HorizontalAlignment.Right

        Me.lblValue.Text = "Total Value:" : Me.lblValue.Font = fntBold : Me.lblValue.Location = New System.Drawing.Point(505, 7) : Me.lblValue.Size = New System.Drawing.Size(80, 18) : Me.lblValue.BackColor = System.Drawing.Color.Transparent
        Me.txtValue.Location = New System.Drawing.Point(590, 5) : Me.txtValue.Size = New System.Drawing.Size(90, 22) : Me.txtValue.Font = fntBold : Me.txtValue.ReadOnly = True : Me.txtValue.TextAlign = HorizontalAlignment.Right

        Me.pnlTotals.Controls.AddRange({
            Me.lblPcs, Me.txtPcs, Me.lblCts, Me.txtCts, Me.lblValue, Me.txtValue
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblParNo As System.Windows.Forms.Label
    Friend WithEvents txtParNo As System.Windows.Forms.TextBox
    Friend WithEvents optParcel As System.Windows.Forms.RadioButton
    Friend WithEvents optLot As System.Windows.Forms.RadioButton
    Friend WithEvents cmdExport As System.Windows.Forms.Button
    Friend WithEvents btnExportCSV As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents lblPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox
    Friend WithEvents lblValue As System.Windows.Forms.Label
    Friend WithEvents txtValue As System.Windows.Forms.TextBox

End Class