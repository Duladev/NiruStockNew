﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm000_UserPASSWD
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        pnlMain = New Panel()
        pnlInfo = New GroupBox()
        lblCompany = New Label()
        lblLocation = New Label()
        pnlLogin = New GroupBox()
        lblUserID = New Label()
        lblUserName = New Label()
        lblPassword = New Label()
        cmbUsers = New ComboBox()
        lblName = New Label()
        txtPassWord = New TextBox()
        passfr = New GroupBox()
        lblNewPW = New Label()
        lblConfirmPW = New Label()
        txtpw = New TextBox()
        txtcpw = New TextBox()
        Timer1 = New Timer(components)
        pnlMain.SuspendLayout()
        pnlInfo.SuspendLayout()
        pnlLogin.SuspendLayout()
        passfr.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlMain
        ' 
        pnlMain.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        pnlMain.Controls.Add(pnlInfo)
        pnlMain.Controls.Add(pnlLogin)
        pnlMain.Dock = DockStyle.Fill
        pnlMain.Location = New Point(0, 0)
        pnlMain.Name = "pnlMain"
        pnlMain.Padding = New Padding(10)
        pnlMain.Size = New Size(434, 441)
        pnlMain.TabIndex = 0
        ' 
        ' pnlInfo
        ' 
        pnlInfo.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        pnlInfo.Controls.Add(lblCompany)
        pnlInfo.Controls.Add(lblLocation)
        pnlInfo.Location = New Point(10, 10)
        pnlInfo.Name = "pnlInfo"
        pnlInfo.Size = New Size(410, 90)
        pnlInfo.TabIndex = 0
        pnlInfo.TabStop = False
        ' 
        ' lblCompany
        ' 
        lblCompany.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        lblCompany.BorderStyle = BorderStyle.FixedSingle
        lblCompany.Font = New Font("Trebuchet MS", 9.75F, FontStyle.Bold)
        lblCompany.Location = New Point(10, 15)
        lblCompany.Name = "lblCompany"
        lblCompany.Size = New Size(385, 28)
        lblCompany.TabIndex = 0
        lblCompany.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblLocation
        ' 
        lblLocation.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        lblLocation.BorderStyle = BorderStyle.FixedSingle
        lblLocation.Location = New Point(10, 50)
        lblLocation.Name = "lblLocation"
        lblLocation.Size = New Size(385, 28)
        lblLocation.TabIndex = 1
        lblLocation.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' pnlLogin
        ' 
        pnlLogin.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        pnlLogin.Controls.Add(lblUserID)
        pnlLogin.Controls.Add(lblUserName)
        pnlLogin.Controls.Add(lblPassword)
        pnlLogin.Controls.Add(cmbUsers)
        pnlLogin.Controls.Add(lblName)
        pnlLogin.Controls.Add(txtPassWord)
        pnlLogin.Controls.Add(passfr)
        pnlLogin.Location = New Point(10, 110)
        pnlLogin.Name = "pnlLogin"
        pnlLogin.Size = New Size(410, 260)
        pnlLogin.TabIndex = 1
        pnlLogin.TabStop = False
        ' 
        ' lblUserID
        ' 
        lblUserID.Font = New Font("Trebuchet MS", 9.75F, FontStyle.Bold)
        lblUserID.ForeColor = Color.Gray
        lblUserID.Location = New Point(20, 25)
        lblUserID.Name = "lblUserID"
        lblUserID.Size = New Size(80, 22)
        lblUserID.TabIndex = 0
        lblUserID.Text = "User ID"
        ' 
        ' lblUserName
        ' 
        lblUserName.Font = New Font("Trebuchet MS", 9.75F, FontStyle.Bold)
        lblUserName.ForeColor = Color.Gray
        lblUserName.Location = New Point(20, 65)
        lblUserName.Name = "lblUserName"
        lblUserName.Size = New Size(90, 22)
        lblUserName.TabIndex = 1
        lblUserName.Text = "User Name"
        ' 
        ' lblPassword
        ' 
        lblPassword.Font = New Font("Trebuchet MS", 9.75F, FontStyle.Bold)
        lblPassword.ForeColor = Color.Gray
        lblPassword.Location = New Point(20, 105)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(80, 22)
        lblPassword.TabIndex = 2
        lblPassword.Text = "Password"
        ' 
        ' cmbUsers
        ' 
        cmbUsers.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        cmbUsers.DropDownStyle = ComboBoxStyle.DropDownList
        cmbUsers.Font = New Font("Trebuchet MS", 8.25F)
        cmbUsers.Location = New Point(130, 22)
        cmbUsers.Name = "cmbUsers"
        cmbUsers.Size = New Size(260, 24)
        cmbUsers.TabIndex = 3
        ' 
        ' lblName
        ' 
        lblName.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        lblName.BorderStyle = BorderStyle.FixedSingle
        lblName.Location = New Point(130, 62)
        lblName.Name = "lblName"
        lblName.Size = New Size(260, 28)
        lblName.TabIndex = 4
        ' 
        ' txtPassWord
        ' 
        txtPassWord.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txtPassWord.Font = New Font("Trebuchet MS", 8.25F)
        txtPassWord.Location = New Point(130, 102)
        txtPassWord.MaxLength = 8
        txtPassWord.Name = "txtPassWord"
        txtPassWord.PasswordChar = "*"c
        txtPassWord.Size = New Size(120, 20)
        txtPassWord.TabIndex = 5
        ' 
        ' passfr
        ' 
        passfr.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        passfr.Controls.Add(lblNewPW)
        passfr.Controls.Add(lblConfirmPW)
        passfr.Controls.Add(txtpw)
        passfr.Controls.Add(txtcpw)
        passfr.Font = New Font("Trebuchet MS", 8.25F)
        passfr.Location = New Point(15, 145)
        passfr.Name = "passfr"
        passfr.Size = New Size(375, 100)
        passfr.TabIndex = 6
        passfr.TabStop = False
        passfr.Text = "Change Password"
        passfr.Visible = False
        ' 
        ' lblNewPW
        ' 
        lblNewPW.Font = New Font("Trebuchet MS", 8.25F, FontStyle.Bold)
        lblNewPW.ForeColor = Color.Gray
        lblNewPW.Location = New Point(10, 25)
        lblNewPW.Name = "lblNewPW"
        lblNewPW.Size = New Size(110, 22)
        lblNewPW.TabIndex = 0
        lblNewPW.Text = "New Password"
        ' 
        ' lblConfirmPW
        ' 
        lblConfirmPW.Font = New Font("Trebuchet MS", 8.25F, FontStyle.Bold)
        lblConfirmPW.ForeColor = Color.Gray
        lblConfirmPW.Location = New Point(10, 60)
        lblConfirmPW.Name = "lblConfirmPW"
        lblConfirmPW.Size = New Size(120, 22)
        lblConfirmPW.TabIndex = 1
        lblConfirmPW.Text = "Confirm Password"
        ' 
        ' txtpw
        ' 
        txtpw.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txtpw.Font = New Font("Trebuchet MS", 8.25F)
        txtpw.Location = New Point(135, 22)
        txtpw.MaxLength = 8
        txtpw.Name = "txtpw"
        txtpw.PasswordChar = "*"c
        txtpw.Size = New Size(120, 20)
        txtpw.TabIndex = 2
        ' 
        ' txtcpw
        ' 
        txtcpw.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txtcpw.Font = New Font("Trebuchet MS", 8.25F)
        txtcpw.Location = New Point(135, 57)
        txtcpw.MaxLength = 8
        txtcpw.Name = "txtcpw"
        txtcpw.PasswordChar = "*"c
        txtcpw.Size = New Size(120, 20)
        txtcpw.TabIndex = 3
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 200
        ' 
        ' frm000_UserPASSWD
        ' 
        BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        ClientSize = New Size(434, 441)
        Controls.Add(pnlMain)
        Font = New Font("Trebuchet MS", 9.75F)
        FormBorderStyle = FormBorderStyle.FixedToolWindow
        KeyPreview = True
        MaximizeBox = False
        MinimizeBox = False
        Name = "frm000_UserPASSWD"
        ShowInTaskbar = False
        StartPosition = FormStartPosition.CenterScreen
        Text = " Login into System"
        pnlMain.ResumeLayout(False)
        pnlInfo.ResumeLayout(False)
        pnlLogin.ResumeLayout(False)
        pnlLogin.PerformLayout()
        passfr.ResumeLayout(False)
        passfr.PerformLayout()
        ResumeLayout(False)
    End Sub

    '── Control Declarations ───────────────────────────────────
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents pnlInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblCompany As System.Windows.Forms.Label
    Friend WithEvents lblLocation As System.Windows.Forms.Label
    Friend WithEvents pnlLogin As System.Windows.Forms.GroupBox
    Friend WithEvents lblUserID As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents cmbUsers As System.Windows.Forms.ComboBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents txtPassWord As System.Windows.Forms.TextBox
    Friend WithEvents passfr As System.Windows.Forms.GroupBox
    Friend WithEvents lblNewPW As System.Windows.Forms.Label
    Friend WithEvents lblConfirmPW As System.Windows.Forms.Label
    Friend WithEvents txtpw As System.Windows.Forms.TextBox
    Friend WithEvents txtcpw As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class