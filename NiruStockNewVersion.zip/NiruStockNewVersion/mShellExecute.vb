﻿Imports System.IO

Module mShellExecute

    Public Enum EShellShowConstants
        essSW_HIDE = 0
        essSW_SHOWNORMAL = 1
        essSW_SHOWMINIMIZED = 2
        essSW_SHOWMAXIMIZED = 3
        essSW_SHOWNOACTIVATE = 4
        essSW_SHOW = 5
        essSW_MINIMIZE = 6
        essSW_SHOWMINNOACTIVE = 7
        essSW_SHOWNA = 8
        essSW_RESTORE = 9
        essSW_SHOWDEFAULT = 10
    End Enum

    ' ── Open a file, URL, or executable via the OS shell ───────
    Public Function ShellEx(ByVal sFile As String,
                            Optional ByVal eShowCmd As EShellShowConstants = EShellShowConstants.essSW_SHOWDEFAULT,
                            Optional ByVal sParameters As String = "",
                            Optional ByVal sDefaultDir As String = "",
                            Optional ByVal sOperation As String = "open") As Boolean
        Try
            Dim psi As New ProcessStartInfo()
            psi.FileName = sFile
            psi.Verb = sOperation
            psi.UseShellExecute = True

            If sParameters <> "" Then psi.Arguments = sParameters
            If sDefaultDir <> "" Then psi.WorkingDirectory = sDefaultDir

            Select Case eShowCmd
                Case EShellShowConstants.essSW_HIDE
                    psi.WindowStyle = ProcessWindowStyle.Hidden
                Case EShellShowConstants.essSW_SHOWMAXIMIZED
                    psi.WindowStyle = ProcessWindowStyle.Maximized
                Case EShellShowConstants.essSW_SHOWMINIMIZED, EShellShowConstants.essSW_MINIMIZE
                    psi.WindowStyle = ProcessWindowStyle.Minimized
                Case Else
                    psi.WindowStyle = ProcessWindowStyle.Normal
            End Select

            Process.Start(psi)
            Return True

        Catch ex As FileNotFoundException
            MessageBox.Show($"File not found:{vbCrLf}{sFile}", "Open Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        Catch ex As Exception
            MessageBox.Show($"Error No : {ex.HResult}{vbCrLf}Description : {ex.Message}{vbCrLf}Function : Open Attachment",
                            "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return False
        End Try
    End Function

End Module