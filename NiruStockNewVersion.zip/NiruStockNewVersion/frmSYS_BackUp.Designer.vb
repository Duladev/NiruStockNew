﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmSYS_BackUp
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        Me.grpMain = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdBackup = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.lblBackupLoc = New System.Windows.Forms.Label()
        Me.txtBackupLocation = New System.Windows.Forms.TextBox()
        Me.lblFileNameHdr = New System.Windows.Forms.Label()
        Me.lblBackupFileName = New System.Windows.Forms.Label()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "S Y S T E M   B A C K U P"
        Me.Size = New System.Drawing.Size(500, 300)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Font = New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        '── GroupBox ───────────────────────────────────────────
        Me.grpMain.Location = New System.Drawing.Point(5, 5)
        Me.grpMain.Size = New System.Drawing.Size(480, 255)
        Me.grpMain.Text = ""
        Me.grpMain.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Buttons ────────────────────────────────────────────
        Me.cmdNew.Text = "New"
        Me.cmdNew.Location = New System.Drawing.Point(10, 15)
        Me.cmdNew.Size = New System.Drawing.Size(100, 28)
        Me.cmdNew.Font = fnt
        Me.cmdNew.BackColor = System.Drawing.Color.FromArgb(210, 210, 157)

        Me.cmdBackup.Text = "Back Up"
        Me.cmdBackup.Location = New System.Drawing.Point(120, 15)
        Me.cmdBackup.Size = New System.Drawing.Size(100, 28)
        Me.cmdBackup.Font = fnt
        Me.cmdBackup.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.cmdExit.Text = "Exit"
        Me.cmdExit.Location = New System.Drawing.Point(240, 15)
        Me.cmdExit.Size = New System.Drawing.Size(100, 28)
        Me.cmdExit.Font = fnt
        Me.cmdExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        '── Backup Location ────────────────────────────────────
        Me.lblBackupLoc.Text = "Backup Location"
        Me.lblBackupLoc.Font = fntBold
        Me.lblBackupLoc.Location = New System.Drawing.Point(10, 58)
        Me.lblBackupLoc.Size = New System.Drawing.Size(130, 18)
        Me.lblBackupLoc.BackColor = System.Drawing.Color.Transparent

        Me.txtBackupLocation.Location = New System.Drawing.Point(10, 78)
        Me.txtBackupLocation.Size = New System.Drawing.Size(455, 55)
        Me.txtBackupLocation.Font = fnt
        Me.txtBackupLocation.Multiline = True
        Me.txtBackupLocation.ReadOnly = True
        Me.txtBackupLocation.ScrollBars = ScrollBars.Vertical
        Me.txtBackupLocation.BackColor = System.Drawing.Color.White

        '── Backup File Name ───────────────────────────────────
        Me.lblFileNameHdr.Text = "Backup File Name :"
        Me.lblFileNameHdr.Font = fntBold
        Me.lblFileNameHdr.Location = New System.Drawing.Point(10, 148)
        Me.lblFileNameHdr.Size = New System.Drawing.Size(130, 22)
        Me.lblFileNameHdr.BackColor = System.Drawing.Color.Transparent
        Me.lblFileNameHdr.TextAlign = ContentAlignment.MiddleRight

        Me.lblBackupFileName.Location = New System.Drawing.Point(148, 148)
        Me.lblBackupFileName.Size = New System.Drawing.Size(317, 22)
        Me.lblBackupFileName.Font = fnt
        Me.lblBackupFileName.BorderStyle = BorderStyle.FixedSingle
        Me.lblBackupFileName.BackColor = SystemColors.Control
        Me.lblBackupFileName.TextAlign = ContentAlignment.MiddleLeft

        '── Add to GroupBox ────────────────────────────────────
        Me.grpMain.Controls.AddRange({
            Me.cmdNew, Me.cmdBackup, Me.cmdExit,
            Me.lblBackupLoc, Me.txtBackupLocation,
            Me.lblFileNameHdr, Me.lblBackupFileName
        })

        Me.Controls.Add(Me.grpMain)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents grpMain As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdBackup As System.Windows.Forms.Button
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents lblBackupLoc As System.Windows.Forms.Label
    Friend WithEvents txtBackupLocation As System.Windows.Forms.TextBox
    Friend WithEvents lblFileNameHdr As System.Windows.Forms.Label
    Friend WithEvents lblBackupFileName As System.Windows.Forms.Label

End Class
