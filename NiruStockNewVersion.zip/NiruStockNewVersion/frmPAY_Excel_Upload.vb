﻿Imports System.IO

Public Class frmPAY_Excel_Upload

    Private strSuppCode As String = ""

    '──────────────────────────────────────────────────────────────
    ' FORM LOAD
    '──────────────────────────────────────────────────────────────
    Private Sub frmPAY_Excel_Upload_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_Hotel_Name()
            Load_Suppliers()
            dtpInvDate.Value = Date.Now
            ProgressBar1.Value = 0
        Catch ex As Exception
            MessageBox.Show("Error loading form: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SETUP GRID
    '──────────────────────────────────────────────────────────────
    Private Sub SetupGrid()
        flxOT.Columns.Clear()
        flxOT.AutoGenerateColumns = False
        flxOT.AllowUserToAddRows = False
        flxOT.AllowUserToDeleteRows = False
        flxOT.ReadOnly = True
        flxOT.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxOT.BackgroundColor = System.Drawing.Color.White
        flxOT.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        Dim headers() As String = {
            "#", "Rgh Price", "Rgh Pcs", "Rgh Cts", "Labour",
            "Pol Price", "Pol Pcs", "Pol Cts", "Parcel No", "Assort No",
            "Size1", "Description", "Parcel ID", "OSPONo", "Sup Par No",
            "Lot ID", "Remarks"
        }
        Dim widths() As Integer = {
            35, 85, 70, 75, 70,
            85, 70, 75, 100, 90,
            60, 100, 90, 80, 90,
            70, 90
        }

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = "Col" & idx
            col.Width = widths(idx)
            flxOT.Columns.Add(col)
        Next
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD COMPANIES
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Hotel_Name()
        Try
            cmbHotel.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT WAN_CODE, WAN_NAME FROM WAN_LOCA ORDER BY WAN_NAME",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim code As String = dr("WAN_CODE").ToString().Trim()
                        Dim name As String = dr("WAN_NAME").ToString().Trim()
                        If Prod_CODE = "XX" Then
                            cmbHotel.Items.Add(New CompanyItem(code, name))
                        ElseIf Prod_CODE = code Then
                            Dim item As New CompanyItem(code, name)
                            cmbHotel.Items.Add(item)
                            cmbHotel.SelectedItem = item
                        End If
                    End While
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading companies: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD SUPPLIERS
    '──────────────────────────────────────────────────────────────
    Private Sub Load_Suppliers()
        Try
            cmbSupplier.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT SupplierCode, SupplierName FROM tblSupplier ORDER BY SupplierName",
                dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSupplier.Items.Add(New SupplierItem(
                            dr("SupplierCode").ToString().Trim(),
                            dr("SupplierName").ToString().Trim()))
                    End While
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading suppliers: " & ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' COMPANY SELECTION
    '──────────────────────────────────────────────────────────────
    Private Sub cmbHotel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbHotel.SelectedIndexChanged
        If cmbHotel.SelectedItem IsNot Nothing Then
            Dim selected As CompanyItem = CType(cmbHotel.SelectedItem, CompanyItem)
            Prod_SITE_CODE = selected.Code
        End If
        flxOT.Rows.Clear()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SUPPLIER SELECTION
    '──────────────────────────────────────────────────────────────
    Private Sub cmbSupplier_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSupplier.SelectedIndexChanged
        If cmbSupplier.SelectedItem IsNot Nothing Then
            strSuppCode = CType(cmbSupplier.SelectedItem, SupplierItem).Code
        End If
    End Sub

    '──────────────────────────────────────────────────────────────
    ' SELECT FILE BUTTON (...)
    '──────────────────────────────────────────────────────────────
    Private Sub cmdSelect_Click(sender As Object, e As EventArgs) Handles cmdSelect.Click
        If cmbHotel.SelectedItem Is Nothing Then
            MessageBox.Show("Please select a Company", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        flxOT.Rows.Clear()

        Using dlg As New OpenFileDialog()
            dlg.InitialDirectory = "C:\"
            dlg.Filter = "Excel Files (*.xls;*.xlsx)|*.xls;*.xlsx|All Files (*.*)|*.*"
            dlg.Title = "Select Excel File"
            If dlg.ShowDialog() = DialogResult.OK Then
                txtBackupLocation.Text = dlg.FileName
            End If
        End Using
    End Sub

    '──────────────────────────────────────────────────────────────
    ' LOAD FILE BUTTON
    '──────────────────────────────────────────────────────────────
    Private Sub cmdLoad_Click(sender As Object, e As EventArgs) Handles cmdLoad.Click
        Try
            If cmbHotel.SelectedItem Is Nothing Then
                MessageBox.Show("Please select a Company", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If
            If txtBackupLocation.Text.Trim() = "" Then
                MessageBox.Show("Please select the Excel file", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If
            If Not File.Exists(txtBackupLocation.Text.Trim()) Then
                MessageBox.Show("Invalid File Path", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Upload_Excel()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' READ EXCEL FILE AND POPULATE GRID
    '──────────────────────────────────────────────────────────────
    Private Sub Upload_Excel()
        Cursor.Current = Cursors.WaitCursor
        Try
            flxOT.Rows.Clear()
            txtError.Text = ""
            txtCount.Text = "0"
            txtInvoice.Text = ""

            Dim xlApp As New Microsoft.Office.Interop.Excel.Application()
            xlApp.Visible = False

            Dim wb As Microsoft.Office.Interop.Excel.Workbook = xlApp.Workbooks.Open(txtBackupLocation.Text.Trim())
            Dim ws As Microsoft.Office.Interop.Excel.Worksheet = CType(wb.Worksheets(1), Microsoft.Office.Interop.Excel.Worksheet)

            ProgressBar1.Value = 0
            ProgressBar1.Maximum = 100

            ' Invoice number is in row 2, column 1
            txtInvoice.Text = ws.Cells(2, 1).Value?.ToString().Trim()

            Dim dblCount As Double = 0

            For intRow As Integer = 4 To 104
                Dim cellVal As Object = ws.Cells(intRow, 5).Value
                If cellVal Is Nothing OrElse cellVal.ToString().Trim() = "" Then Exit For

                dblCount += 1

                Dim labour As String = "0"
                Dim raw = ws.Cells(intRow, 18).Value?.ToString().Trim()
                If IsNumeric(raw) Then labour = raw

                flxOT.Rows.Add(
                    dblCount.ToString(),
                    Format(Convert.ToDouble(ws.Cells(intRow, 10).Value), "###,##0.00"),
                    ws.Cells(intRow, 8).Value?.ToString().Trim(),
                    Format(Convert.ToDouble(ws.Cells(intRow, 9).Value), "#0.000"),
                    labour,
                    Format(Convert.ToDouble(ws.Cells(intRow, 21).Value), "###,##0.00"),
                    ws.Cells(intRow, 15).Value?.ToString().Trim(),
                    Format(Convert.ToDouble(ws.Cells(intRow, 19).Value), "#0.000"),
                    ws.Cells(intRow, 6).Value?.ToString().Trim(),
                    ws.Cells(intRow, 5).Value?.ToString().Trim(),
                    Format(Convert.ToDouble(ws.Cells(intRow, 16).Value), "#0.00"),
                    ws.Cells(intRow, 35).Value?.ToString().Trim(),
                    ws.Cells(intRow, 36).Value?.ToString().Trim(),
                    ws.Cells(intRow, 37).Value?.ToString().Trim(),
                    ws.Cells(intRow, 1).Value?.ToString().Trim(),
                    ws.Cells(intRow, 7).Value?.ToString().Trim(),
                    ws.Cells(intRow, 2).Value?.ToString().Trim()
                )

                ProgressBar1.Value = CInt(Math.Min(dblCount, 100))
                Application.DoEvents()
            Next

            txtCount.Text = dblCount.ToString()
            ProgressBar1.Value = 0

            wb.Close(False)
            xlApp.Quit()

            System.Runtime.InteropServices.Marshal.ReleaseComObject(ws)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(wb)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)

        Catch ex As Exception
            txtError.Text = "Error reading Excel: " & ex.Message
            MessageBox.Show(ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' UPLOAD BUTTON — SAVE TO DATABASE
    '──────────────────────────────────────────────────────────────
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If cmbHotel.SelectedItem Is Nothing OrElse cmbSupplier.SelectedItem Is Nothing Then
                MessageBox.Show("Please select the Supplier", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            If flxOT.Rows.Count = 0 Then
                MessageBox.Show("No data to upload. Please load the Excel file first.", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Check first row has a parcel number
            If flxOT.Rows(0).Cells("Col8").Value?.ToString().Trim() = "" Then
                MessageBox.Show("Invalid Parcel No.", Me.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim confirm = MessageBox.Show(
                "You are going to upload invoice details of " &
                txtInvoice.Text.Trim() & ". Are you sure?",
                Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If confirm = DialogResult.No Then Return

            ' Check invoice doesn't already exist
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblInvoice WHERE InvoiceNo=@inv", dbconn_Prod)
                cmd.Parameters.AddWithValue("@inv", txtInvoice.Text.Trim())
                If CInt(cmd.ExecuteScalar()) > 0 Then
                    MessageBox.Show(
                        "Invoice already exists. Please contact the System Administrator to update.",
                        Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If
            End Using

            ' Insert all rows
            For Each row As DataGridViewRow In flxOT.Rows
                Using cmd As New SqlCommand(
                    "INSERT INTO tblInvoice(InvoiceNo,InvoiceDate,RghPrice,RghPcs,RhgCts,Labour," &
                    "PolPrice,PolPcs,PolCts,Supplier,ParcelNo,AssortNo,Size1,GrpName," &
                    "ImportDate,TransferDate,Checked,Repair,Export,ActPcs,ActCts," &
                    "Description,ParcelID,OSPONo,SupParNo,LotID,Remarks) " &
                    "VALUES(@inv,@invdate,@rghprice,@rghpcs,@rghcts,@labour," &
                    "@polprice,@polpcs,@polcts,@supp,@parno,@assort,@size1,''," &
                    "@impdate,@transdate,0,0,0,@actpcs,@actcts," &
                    "@desc,@parid,@ospo,@suppar,@lot,@remarks)",
                    dbconn_Prod)

                    cmd.Parameters.AddWithValue("@inv", txtInvoice.Text.Trim())
                    cmd.Parameters.AddWithValue("@invdate", dtpInvDate.Value.ToString("MM/dd/yyyy"))
                    cmd.Parameters.AddWithValue("@rghprice", ToDouble(row.Cells("Col1").Value))
                    cmd.Parameters.AddWithValue("@rghpcs", ToDouble(row.Cells("Col2").Value))
                    cmd.Parameters.AddWithValue("@rghcts", ToDouble(row.Cells("Col3").Value))
                    cmd.Parameters.AddWithValue("@labour", ToDouble(row.Cells("Col4").Value))
                    cmd.Parameters.AddWithValue("@polprice", ToDouble(row.Cells("Col5").Value))
                    cmd.Parameters.AddWithValue("@polpcs", ToDouble(row.Cells("Col6").Value))
                    cmd.Parameters.AddWithValue("@polcts", ToDouble(row.Cells("Col7").Value))
                    cmd.Parameters.AddWithValue("@supp", strSuppCode)
                    cmd.Parameters.AddWithValue("@parno", row.Cells("Col8").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@assort", row.Cells("Col9").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@size1", ToDouble(row.Cells("Col10").Value))
                    cmd.Parameters.AddWithValue("@impdate", Date.Now.ToString("MM/dd/yyyy"))
                    cmd.Parameters.AddWithValue("@transdate", dtpInvDate.Value.ToString("MM/dd/yyyy"))
                    cmd.Parameters.AddWithValue("@actpcs", ToDouble(row.Cells("Col6").Value))
                    cmd.Parameters.AddWithValue("@actcts", ToDouble(row.Cells("Col7").Value))
                    cmd.Parameters.AddWithValue("@desc", row.Cells("Col11").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@parid", row.Cells("Col12").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@ospo", row.Cells("Col13").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@suppar", row.Cells("Col14").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@lot", row.Cells("Col15").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@remarks", row.Cells("Col16").Value?.ToString().Trim())
                    cmd.ExecuteNonQuery()
                End Using

                Log_book("Invoice", "New", txtInvoice.Text,
                         "New Entry Parcel No. - " & row.Cells("Col8").Value?.ToString() &
                         ", Assort No. - " & row.Cells("Col9").Value?.ToString())
            Next

            MessageBox.Show("Excel Upload Successfully Completed", Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Me.Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    '──────────────────────────────────────────────────────────────
    ' NEW BUTTON — CLEAR FORM
    '──────────────────────────────────────────────────────────────
    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        txtCount.Text = ""
        txtInvoice.Text = ""
        cmbSupplier.SelectedIndex = -1
        flxOT.Rows.Clear()
        txtBackupLocation.Text = ""
        dtpInvDate.Value = Date.Now
        ProgressBar1.Value = 0
        txtError.Text = ""
    End Sub

    '──────────────────────────────────────────────────────────────
    ' EXIT BUTTON
    '──────────────────────────────────────────────────────────────
    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    '──────────────────────────────────────────────────────────────
    ' HELPER — safe numeric conversion
    '──────────────────────────────────────────────────────────────
    Private Function ToDouble(val As Object) As Double
        If val Is Nothing OrElse val.ToString().Trim() = "" Then Return 0
        Dim raw As String = val.ToString().Replace(",", "").Trim()
        If IsNumeric(raw) Then Return Convert.ToDouble(raw)
        Return 0
    End Function

End Class

'──────────────────────────────────────────────────────────────────
' HELPER CLASS — Supplier item for ComboBox
'──────────────────────────────────────────────────────────────────
Public Class SupplierItem
    Public Property Code As String
    Public Property Name As String

    Public Sub New(code As String, name As String)
        Me.Code = code
        Me.Name = name
    End Sub

    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class