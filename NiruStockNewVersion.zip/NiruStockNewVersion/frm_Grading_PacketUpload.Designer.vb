﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_PacketUpload
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("Trebuchet MS", 8.25)
        Dim fntBold As New System.Drawing.Font("Trebuchet MS", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblParNo = New System.Windows.Forms.Label()
        Me.txtParNo = New System.Windows.Forms.TextBox()
        Me.lblPktNo = New System.Windows.Forms.Label()
        Me.txtPktNo = New System.Windows.Forms.TextBox()
        Me.lblFilePath = New System.Windows.Forms.Label()
        Me.txtBackupLocation = New System.Windows.Forms.TextBox()
        Me.cmdSelect = New System.Windows.Forms.Button()
        Me.cmdLoad = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlTotals = New System.Windows.Forms.Panel()
        Me.lblPktPcs = New System.Windows.Forms.Label()
        Me.txtPktPcs = New System.Windows.Forms.TextBox()
        Me.lblPktCts = New System.Windows.Forms.Label()
        Me.txtPktCts = New System.Windows.Forms.TextBox()
        Me.lblTotPcs = New System.Windows.Forms.Label()
        Me.txtPcs = New System.Windows.Forms.TextBox()
        Me.lblTotCts = New System.Windows.Forms.Label()
        Me.txtCts = New System.Windows.Forms.TextBox()
        Me.chkSize = New System.Windows.Forms.CheckBox()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "PACKET UPLOAD"
        Me.Size = New System.Drawing.Size(780, 640)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "PACKET UPLOAD"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Top Panel ──────────────────────────────────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 35)
        Me.pnlTop.Size = New System.Drawing.Size(774, 80)
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        ' Row 1: Parcel No, Pkt No
        Me.lblParNo.Text = "Parcel No" : Me.lblParNo.Font = fntBold : Me.lblParNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblParNo.Location = New System.Drawing.Point(8, 5) : Me.lblParNo.Size = New System.Drawing.Size(70, 18) : Me.lblParNo.BackColor = System.Drawing.Color.Transparent

        Me.txtParNo.Location = New System.Drawing.Point(8, 23) : Me.txtParNo.Size = New System.Drawing.Size(120, 22) : Me.txtParNo.Font = fnt

        Me.lblPktNo.Text = "Packet No" : Me.lblPktNo.Font = fntBold : Me.lblPktNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblPktNo.Location = New System.Drawing.Point(140, 5) : Me.lblPktNo.Size = New System.Drawing.Size(70, 18) : Me.lblPktNo.BackColor = System.Drawing.Color.Transparent

        Me.txtPktNo.Location = New System.Drawing.Point(140, 23) : Me.txtPktNo.Size = New System.Drawing.Size(60, 22) : Me.txtPktNo.Font = fnt

        ' Row 2: File path + buttons
        Me.lblFilePath.Text = "Source File" : Me.lblFilePath.Font = fntBold : Me.lblFilePath.ForeColor = System.Drawing.Color.DarkRed
        Me.lblFilePath.Location = New System.Drawing.Point(8, 50) : Me.lblFilePath.Size = New System.Drawing.Size(70, 18) : Me.lblFilePath.BackColor = System.Drawing.Color.Transparent

        Me.txtBackupLocation.Location = New System.Drawing.Point(8, 50) : Me.txtBackupLocation.Size = New System.Drawing.Size(0, 0) ' hidden, shown below
        Me.txtBackupLocation.Location = New System.Drawing.Point(85, 48) : Me.txtBackupLocation.Size = New System.Drawing.Size(300, 22) : Me.txtBackupLocation.Font = fnt : Me.txtBackupLocation.ReadOnly = True

        Me.cmdSelect.Text = "..." : Me.cmdSelect.Location = New System.Drawing.Point(390, 47) : Me.cmdSelect.Size = New System.Drawing.Size(30, 24) : Me.cmdSelect.Font = fnt : Me.cmdSelect.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)
        Me.cmdLoad.Text = "Load File" : Me.cmdLoad.Location = New System.Drawing.Point(430, 47) : Me.cmdLoad.Size = New System.Drawing.Size(80, 24) : Me.cmdLoad.Font = fnt : Me.cmdLoad.BackColor = System.Drawing.Color.FromArgb(157, 183, 235)
        Me.cmdSave.Text = "Save" : Me.cmdSave.Location = New System.Drawing.Point(515, 47) : Me.cmdSave.Size = New System.Drawing.Size(70, 24) : Me.cmdSave.Font = fnt : Me.cmdSave.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)
        Me.btnExit.Text = "Exit" : Me.btnExit.Location = New System.Drawing.Point(590, 47) : Me.btnExit.Size = New System.Drawing.Size(70, 24) : Me.btnExit.Font = fnt : Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.pnlTop.Controls.AddRange({
            Me.lblParNo, Me.txtParNo, Me.lblPktNo, Me.txtPktNo,
            Me.lblFilePath, Me.txtBackupLocation,
            Me.cmdSelect, Me.cmdLoad, Me.cmdSave, Me.btnExit
        })

        '── Grid ───────────────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 120)
        Me.flxDetails.Size = New System.Drawing.Size(764, 460)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        '── Totals ─────────────────────────────────────────────
        Me.pnlTotals.Location = New System.Drawing.Point(0, 585)
        Me.pnlTotals.Size = New System.Drawing.Size(774, 32)
        Me.pnlTotals.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlTotals.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.lblPktPcs.Text = "Pkt Pcs:" : Me.lblPktPcs.Font = fntBold : Me.lblPktPcs.Location = New System.Drawing.Point(5, 7) : Me.lblPktPcs.Size = New System.Drawing.Size(60, 18) : Me.lblPktPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPktPcs.Location = New System.Drawing.Point(70, 5) : Me.txtPktPcs.Size = New System.Drawing.Size(70, 22) : Me.txtPktPcs.Font = fntBold : Me.txtPktPcs.ReadOnly = True : Me.txtPktPcs.TextAlign = HorizontalAlignment.Right

        Me.lblPktCts.Text = "Pkt Cts:" : Me.lblPktCts.Font = fntBold : Me.lblPktCts.Location = New System.Drawing.Point(150, 7) : Me.lblPktCts.Size = New System.Drawing.Size(60, 18) : Me.lblPktCts.BackColor = System.Drawing.Color.Transparent
        Me.txtPktCts.Location = New System.Drawing.Point(215, 5) : Me.txtPktCts.Size = New System.Drawing.Size(80, 22) : Me.txtPktCts.Font = fntBold : Me.txtPktCts.ReadOnly = True : Me.txtPktCts.TextAlign = HorizontalAlignment.Right

        Me.lblTotPcs.Text = "Tot Pcs:" : Me.lblTotPcs.Font = fntBold : Me.lblTotPcs.Location = New System.Drawing.Point(380, 7) : Me.lblTotPcs.Size = New System.Drawing.Size(60, 18) : Me.lblTotPcs.BackColor = System.Drawing.Color.Transparent
        Me.txtPcs.Location = New System.Drawing.Point(445, 5) : Me.txtPcs.Size = New System.Drawing.Size(70, 22) : Me.txtPcs.Font = fntBold : Me.txtPcs.ReadOnly = True : Me.txtPcs.TextAlign = HorizontalAlignment.Right

        Me.lblTotCts.Text = "Tot Cts:" : Me.lblTotCts.Font = fntBold : Me.lblTotCts.Location = New System.Drawing.Point(525, 7) : Me.lblTotCts.Size = New System.Drawing.Size(60, 18) : Me.lblTotCts.BackColor = System.Drawing.Color.Transparent
        Me.txtCts.Location = New System.Drawing.Point(590, 5) : Me.txtCts.Size = New System.Drawing.Size(80, 22) : Me.txtCts.Font = fntBold : Me.txtCts.ReadOnly = True : Me.txtCts.TextAlign = HorizontalAlignment.Right

        Me.chkSize.Text = "Size Only" : Me.chkSize.Font = fnt : Me.chkSize.Location = New System.Drawing.Point(685, 7) : Me.chkSize.Size = New System.Drawing.Size(80, 20)

        Me.pnlTotals.Controls.AddRange({
            Me.lblPktPcs, Me.txtPktPcs, Me.lblPktCts, Me.txtPktCts,
            Me.lblTotPcs, Me.txtPcs, Me.lblTotCts, Me.txtCts, Me.chkSize
        })

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlTotals)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblParNo As System.Windows.Forms.Label
    Friend WithEvents txtParNo As System.Windows.Forms.TextBox
    Friend WithEvents lblPktNo As System.Windows.Forms.Label
    Friend WithEvents txtPktNo As System.Windows.Forms.TextBox
    Friend WithEvents lblFilePath As System.Windows.Forms.Label
    Friend WithEvents txtBackupLocation As System.Windows.Forms.TextBox
    Friend WithEvents cmdSelect As System.Windows.Forms.Button
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlTotals As System.Windows.Forms.Panel
    Friend WithEvents lblPktPcs As System.Windows.Forms.Label
    Friend WithEvents txtPktPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblPktCts As System.Windows.Forms.Label
    Friend WithEvents txtPktCts As System.Windows.Forms.TextBox
    Friend WithEvents lblTotPcs As System.Windows.Forms.Label
    Friend WithEvents txtPcs As System.Windows.Forms.TextBox
    Friend WithEvents lblTotCts As System.Windows.Forms.Label
    Friend WithEvents txtCts As System.Windows.Forms.TextBox
    Friend WithEvents chkSize As System.Windows.Forms.CheckBox

End Class