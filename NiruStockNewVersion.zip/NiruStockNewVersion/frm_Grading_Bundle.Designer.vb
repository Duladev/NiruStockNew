﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_Grading_Bundle
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim fnt As New System.Drawing.Font("MS Sans Serif", 8.25)
        Dim fntBold As New System.Drawing.Font("MS Sans Serif", 8.25, FontStyle.Bold)

        Me.pnlTitle = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblBundleNo = New System.Windows.Forms.Label()
        Me.txtBundleNo = New System.Windows.Forms.TextBox()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pnlEntry = New System.Windows.Forms.Panel()
        Me.lblPackNo = New System.Windows.Forms.Label()
        Me.txtPackNo = New System.Windows.Forms.TextBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.flxDetails = New System.Windows.Forms.DataGridView()
        Me.pnlBottom = New System.Windows.Forms.Panel()
        Me.lblBNo = New System.Windows.Forms.Label()
        Me.txtBNo = New System.Windows.Forms.TextBox()
        Me.cmdClear = New System.Windows.Forms.Button()

        Me.SuspendLayout()

        '── Form ───────────────────────────────────────────────
        Me.Text = "BUNDLE MODULE"
        Me.Size = New System.Drawing.Size(500, 520)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = System.Drawing.Color.FromArgb(216, 233, 236)

        '── Title ──────────────────────────────────────────────
        Me.pnlTitle.Dock = DockStyle.Top
        Me.pnlTitle.Height = 35
        Me.pnlTitle.BackColor = System.Drawing.Color.FromArgb(70, 130, 180)
        Me.lblTitle.Text = "BUNDLE MODULE"
        Me.lblTitle.Font = New System.Drawing.Font("Trebuchet MS", 11, FontStyle.Bold)
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Dock = DockStyle.Fill
        Me.lblTitle.TextAlign = ContentAlignment.MiddleCenter
        Me.pnlTitle.Controls.Add(Me.lblTitle)

        '── Top Panel ──────────────────────────────────────────
        Me.pnlTop.Location = New System.Drawing.Point(0, 35)
        Me.pnlTop.Size = New System.Drawing.Size(494, 40)
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)

        Me.lblBundleNo.Text = "Bundle No." : Me.lblBundleNo.Font = fntBold
        Me.lblBundleNo.Location = New System.Drawing.Point(8, 5) : Me.lblBundleNo.Size = New System.Drawing.Size(80, 18)
        Me.lblBundleNo.BackColor = System.Drawing.Color.Transparent

        Me.txtBundleNo.Location = New System.Drawing.Point(8, 22) : Me.txtBundleNo.Size = New System.Drawing.Size(70, 22)
        Me.txtBundleNo.Font = fnt : Me.txtBundleNo.ReadOnly = True : Me.txtBundleNo.TextAlign = HorizontalAlignment.Right

        Me.cmdRefresh.Text = "Refresh" : Me.cmdRefresh.Location = New System.Drawing.Point(240, 12) : Me.cmdRefresh.Size = New System.Drawing.Size(80, 24)
        Me.cmdRefresh.Font = fnt : Me.cmdRefresh.BackColor = System.Drawing.Color.FromArgb(157, 183, 235)

        Me.cmdSave.Text = "Save" : Me.cmdSave.Location = New System.Drawing.Point(325, 12) : Me.cmdSave.Size = New System.Drawing.Size(80, 24)
        Me.cmdSave.Font = fnt : Me.cmdSave.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.btnExit.Text = "Exit" : Me.btnExit.Location = New System.Drawing.Point(410, 12) : Me.btnExit.Size = New System.Drawing.Size(75, 24)
        Me.btnExit.Font = fnt : Me.btnExit.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.pnlTop.Controls.AddRange({Me.lblBundleNo, Me.txtBundleNo, Me.cmdRefresh, Me.cmdSave, Me.btnExit})

        '── Entry Panel ────────────────────────────────────────
        Me.pnlEntry.Location = New System.Drawing.Point(0, 75)
        Me.pnlEntry.Size = New System.Drawing.Size(494, 35)
        Me.pnlEntry.BackColor = System.Drawing.Color.FromArgb(245, 245, 245)

        Me.lblPackNo.Text = "Packing List No." : Me.lblPackNo.Font = fntBold
        Me.lblPackNo.Location = New System.Drawing.Point(8, 7) : Me.lblPackNo.Size = New System.Drawing.Size(120, 18)
        Me.lblPackNo.BackColor = System.Drawing.Color.Transparent

        Me.txtPackNo.Location = New System.Drawing.Point(135, 5) : Me.txtPackNo.Size = New System.Drawing.Size(70, 22)
        Me.txtPackNo.Font = fnt : Me.txtPackNo.TextAlign = HorizontalAlignment.Right

        Me.cmdAdd.Text = "Add" : Me.cmdAdd.Location = New System.Drawing.Point(215, 4) : Me.cmdAdd.Size = New System.Drawing.Size(70, 24)
        Me.cmdAdd.Font = fnt : Me.cmdAdd.BackColor = System.Drawing.Color.FromArgb(157, 210, 157)

        Me.pnlEntry.Controls.AddRange({Me.lblPackNo, Me.txtPackNo, Me.cmdAdd})

        '── DataGridView ───────────────────────────────────────
        Me.flxDetails.Location = New System.Drawing.Point(5, 115)
        Me.flxDetails.Size = New System.Drawing.Size(484, 340)
        Me.flxDetails.Font = fnt
        Me.flxDetails.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        '── Bottom Panel ───────────────────────────────────────
        Me.pnlBottom.Location = New System.Drawing.Point(0, 460)
        Me.pnlBottom.Size = New System.Drawing.Size(494, 35)
        Me.pnlBottom.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.pnlBottom.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right

        Me.lblBNo.Text = "Bundle No. to Clear:" : Me.lblBNo.Font = fntBold
        Me.lblBNo.Location = New System.Drawing.Point(8, 8) : Me.lblBNo.Size = New System.Drawing.Size(140, 18)
        Me.lblBNo.BackColor = System.Drawing.Color.Transparent

        Me.txtBNo.Location = New System.Drawing.Point(155, 6) : Me.txtBNo.Size = New System.Drawing.Size(60, 22)
        Me.txtBNo.Font = fnt : Me.txtBNo.TextAlign = HorizontalAlignment.Right

        Me.cmdClear.Text = "Clear Bundle" : Me.cmdClear.Location = New System.Drawing.Point(225, 4) : Me.cmdClear.Size = New System.Drawing.Size(100, 24)
        Me.cmdClear.Font = fnt : Me.cmdClear.BackColor = System.Drawing.Color.FromArgb(235, 183, 157)

        Me.pnlBottom.Controls.AddRange({Me.lblBNo, Me.txtBNo, Me.cmdClear})

        '── Assemble ───────────────────────────────────────────
        Me.Controls.Add(Me.pnlTitle)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.pnlEntry)
        Me.Controls.Add(Me.flxDetails)
        Me.Controls.Add(Me.pnlBottom)

        Me.ResumeLayout(False)
    End Sub

    Friend WithEvents pnlTitle As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblBundleNo As System.Windows.Forms.Label
    Friend WithEvents txtBundleNo As System.Windows.Forms.TextBox
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents pnlEntry As System.Windows.Forms.Panel
    Friend WithEvents lblPackNo As System.Windows.Forms.Label
    Friend WithEvents txtPackNo As System.Windows.Forms.TextBox
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents flxDetails As System.Windows.Forms.DataGridView
    Friend WithEvents pnlBottom As System.Windows.Forms.Panel
    Friend WithEvents lblBNo As System.Windows.Forms.Label
    Friend WithEvents txtBNo As System.Windows.Forms.TextBox
    Friend WithEvents cmdClear As System.Windows.Forms.Button

End Class