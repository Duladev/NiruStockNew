﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.IO

Public Class frm_Grading_ExportSummaryBundle

    ' FORM LOAD
    Private Sub frm_Grading_ExportSummaryBundle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_SizeRange()
            txtPcs.Text = "0"
            txtCts.Text = "0"
            txtTotPcs.Text = "0"
            txtTotCts.Text = "0"
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("MS Sans Serif", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        ' Checkbox
        Dim chk As New DataGridViewCheckBoxColumn()
        chk.HeaderText = "Sel" : chk.Name = "Selected" : chk.Width = 40
        flxDetails.Columns.Add(chk)

        Dim headers() As String = {"Assortment", "Bundle No", "Pcs", "Cts", "Price", "Value", "Size Range"}
        Dim names() As String = {"Assortment", "BundleNo", "Pcs", "Cts", "Price", "Value", "SizeRange"}
        Dim widths() As Integer = {120, 75, 60, 75, 65, 75, 100}
        Dim editable() As Boolean = {False, False, True, True, False, False, False}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = Not editable(idx)
            If idx >= 2 AndAlso idx <= 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    ' LOAD SIZE RANGES
    Private Sub Load_SizeRange()
        Try
            cmbSize.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT Code FROM tblGrading_SizingRange ORDER BY Code", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSize.Items.Add(dr("Code").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Load_SizeRange")
        End Try
    End Sub

    ' LOAD ASSORTMENTS
    Private Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
        Try
            Cursor.Current = Cursors.WaitCursor
            cmbAssort.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT AssortNo FROM tblGrading_SizeListNew ORDER BY AssortNo", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbAssort.Items.Add(dr("AssortNo").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "cmdRefresh_Click")
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    ' BUNDLE NO — ENTER KEY
    Private Sub txtBundleNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBundleNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Load_PackingList()
        End If
    End Sub

    ' LOAD PACKING LIST FOR BUNDLE
    Private Sub Load_PackingList()
        Try
            flxDetails.Rows.Clear()
            Dim bundleNo As String = txtBundleNo.Text.Trim()

            ' Try PackingListB first
            Dim hasB As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_PackingListB WHERE BundleNo=@bno ORDER BY Assortment, Pcs, Cts",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@bno", bundleNo)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        hasB = True
                        Dim rowIdx As Integer = flxDetails.Rows.Add()
                        Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                        row.Cells("Selected").Value = True
                        row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                        row.Cells("BundleNo").Value = dr("BundleNo").ToString().Trim()
                        row.Cells("Pcs").Value = dr("Pcs").ToString()
                        row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                        row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                        row.Cells("Value").Value = Format(Convert.ToDouble(dr("Cts")) * Convert.ToDouble(dr("Price")), "#0.00")
                        row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                    End While
                End Using
            End Using

            If Not hasB Then
                ' Fall back to PackingListM + Bundle join
                Dim sql As String =
                    "SELECT TOP (100) PERCENT m.Assortment, m.SizeRange, " &
                    "SUM(m.Pcs) AS Pcs, ROUND(SUM(m.Cts),3) AS Cts, " &
                    "sln.Price, ROUND(SUM(sln.Price * m.Cts),2) AS Value " &
                    "FROM tblGrading_Bundle b " &
                    "INNER JOIN tblGrading_PackingListM m ON b.PackNo = m.PackNo " &
                    "INNER JOIN tblGrading_SizeListNew sln ON m.Assortment = sln.AssortNo " &
                    "WHERE b.BundleNo = @bno " &
                    "GROUP BY m.Assortment, m.SizeRange, sln.Price " &
                    "ORDER BY m.Assortment"

                Using cmd As New SqlCommand(sql, dbconn_Prod)
                    cmd.Parameters.AddWithValue("@bno", bundleNo)
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        While dr.Read()
                            Dim rowIdx As Integer = flxDetails.Rows.Add()
                            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                            row.Cells("Selected").Value = True
                            row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                            row.Cells("BundleNo").Value = bundleNo
                            row.Cells("Pcs").Value = dr("Pcs").ToString()
                            row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                            row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                            row.Cells("Value").Value = Format(Convert.ToDouble(dr("Value")), "#0.00")
                            row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                        End While
                    End Using
                End Using
            End If

            RecalcTotals(setOriginal:=True)

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Load_PackingList")
        End Try
    End Sub

    ' ADD ROW
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Try
            If cmbAssort.Text.Trim() = "" Then MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If cmbSize.Text.Trim() = "" Then MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewPcs.Text.Trim() = "" OrElse Convert.ToDouble(txtNewPcs.Text) <= 0 Then MessageBox.Show("Invalid Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewCts.Text.Trim() = "" OrElse Convert.ToDouble(txtNewCts.Text) <= 0 Then MessageBox.Show("Invalid Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return

            If Convert.ToDouble(txtTotPcs.Text) + Convert.ToDouble(txtNewPcs.Text) > Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Invalid Total Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text) + Convert.ToDouble(txtNewCts.Text), 3) > Convert.ToDouble(txtCts.Text) Then
                MessageBox.Show("Invalid Total Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Get price
            Dim price As Double = 0
            Using cmd As New SqlCommand(
                "SELECT PRICE FROM tblGrading_SizeListNew WHERE AssortNo=@a", dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result Is Nothing Then
                    MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                End If
                price = If(result Is DBNull.Value, 0, Convert.ToDouble(result))
            End Using

            ' Validate size range
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_SizingRange WHERE Code=@c", dbconn_Prod)
                cmd.Parameters.AddWithValue("@c", cmbSize.Text.Trim())
                If CInt(cmd.ExecuteScalar()) = 0 Then
                    MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                End If
            End Using

            Dim pcs As Double = Convert.ToDouble(txtNewPcs.Text)
            Dim cts As Double = Convert.ToDouble(txtNewCts.Text)

            Dim rowIdx As Integer = flxDetails.Rows.Add()
            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
            row.Cells("Selected").Value = True
            row.Cells("Assortment").Value = cmbAssort.Text.Trim().ToUpper()
            row.Cells("BundleNo").Value = txtBundleNo.Text.Trim()
            row.Cells("Pcs").Value = pcs.ToString()
            row.Cells("Cts").Value = cts.ToString()
            row.Cells("Price").Value = Format(price, "#0.00")
            row.Cells("Value").Value = Format(price * cts, "#0.00")
            row.Cells("SizeRange").Value = cmbSize.Text.Trim()

            RecalcTotals()

            cmbAssort.Text = ""
            cmbSize.Text = ""
            txtNewPcs.Text = ""
            txtNewCts.Text = ""
            cmbAssort.Focus()

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "cmdAdd_Click")
        End Try
    End Sub

    ' RECALCULATE TOTALS
    Private Sub RecalcTotals(Optional setOriginal As Boolean = False)
        Dim totPcs As Double = 0
        Dim totCts As Double = 0

        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("Selected").Value) Then
                totPcs += Convert.ToDouble(If(row.Cells("Pcs").Value?.ToString() = "", "0", row.Cells("Pcs").Value?.ToString()))
                totCts += Convert.ToDouble(If(row.Cells("Cts").Value?.ToString() = "", "0", row.Cells("Cts").Value?.ToString()))
            End If
        Next

        txtTotPcs.Text = totPcs.ToString()
        txtTotCts.Text = Format(Math.Round(totCts, 3), "#0.000")

        If setOriginal Then
            txtPcs.Text = totPcs.ToString()
            txtCts.Text = Format(Math.Round(totCts, 3), "#0.000")
        End If
    End Sub

    Private Sub flxDetails_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellValueChanged
        RecalcTotals()
    End Sub

    Private Sub flxDetails_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles flxDetails.CurrentCellDirtyStateChanged
        If flxDetails.IsCurrentCellDirty Then
            flxDetails.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    ' SAVE
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If txtBundleNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Bundle No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If flxDetails.Rows.Count < 1 Then
                MessageBox.Show("No Records", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            RecalcTotals()

            If Convert.ToDouble(txtTotPcs.Text) <> Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Pcs not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text), 3) <> Math.Round(Convert.ToDouble(txtCts.Text), 3) Then
                MessageBox.Show("Cts not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Check if exists
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_PackingListB WHERE BundleNo=@bno", dbconn_Prod)
                cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If exists Then
                If MessageBox.Show("Are you sure to update?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                ' Delete and re-insert
                Using cmd As New SqlCommand(
                    "DELETE FROM tblGrading_PackingListB WHERE BundleNo=@bno", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                    cmd.ExecuteNonQuery()
                End Using
                InsertRows()
                MessageBox.Show("Updated Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If MessageBox.Show("Are you sure to save?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                InsertRows()
                MessageBox.Show("Saved Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            ResetForm()

        Catch ex As Exception
            MessageBox.Show("Save error: " & ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    Private Sub InsertRows()
        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("Selected").Value) Then
                Using cmd As New SqlCommand(
                    "INSERT INTO tblGrading_PackingListB(Assortment,BundleNo,Pcs,Cts,Price,SizeRange) " &
                    "VALUES(@assort,@bno,@pcs,@cts,@price,@size)", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@assort", row.Cells("Assortment").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                    cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@size", row.Cells("SizeRange").Value?.ToString().Trim())
                    cmd.ExecuteNonQuery()
                End Using
            End If
        Next
    End Sub

    ' TOOLBAR BUTTONS
    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        ResetForm()
        txtBundleNo.Focus()
    End Sub

    Private Sub cmdExcel_Click(sender As Object, e As EventArgs) Handles cmdExcel.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "Excel Files (*.xls)|*.xls"
                dlg.FileName = "BundlePackage_" & txtBundleNo.Text & ".xls"
                If dlg.ShowDialog() = DialogResult.OK Then
                    Dim sb As New StringBuilder()
                    For Each col As DataGridViewColumn In flxDetails.Columns
                        sb.Append(col.HeaderText & vbTab)
                    Next
                    sb.AppendLine()
                    For Each row As DataGridViewRow In flxDetails.Rows
                        For Each cell As DataGridViewCell In row.Cells
                            sb.Append(cell.Value?.ToString() & vbTab)
                        Next
                        sb.AppendLine()
                    Next
                    File.WriteAllText(dlg.FileName, sb.ToString(), Text.Encoding.UTF8)
                    ShellEx(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    '── Key press helpers ──────────────────────────────────────────
    Private Sub txtNewPcs_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewPcs.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : txtNewCts.Focus()
    End Sub

    Private Sub txtNewCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewCts.KeyPress
        NumericOnly(e, txtNewCts.Text)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : cmdAdd.Focus()
    End Sub

    ' RESET FORM
    Private Sub ResetForm()
        flxDetails.Rows.Clear()
        txtBundleNo.Text = "" : txtPcs.Text = "0"
        txtCts.Text = "0" : txtTotPcs.Text = "0"
        txtTotCts.Text = "0" : cmbSize.Text = ""
    End Sub

End Class
Imports System.Data.SqlClient
Imports System.Text
Imports System.IO

Public Class frm_Grading_ExportSummaryBundle

    ' FORM LOAD
    Private Sub frm_Grading_ExportSummaryBundle_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.StartPosition = FormStartPosition.CenterScreen
            SetupGrid()
            Load_SizeRange()
            txtPcs.Text = "0"
            txtCts.Text = "0"
            txtTotPcs.Text = "0"
            txtTotCts.Text = "0"
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Form_Load")
        End Try
    End Sub

    ' SETUP GRID
    Private Sub SetupGrid()
        flxDetails.Columns.Clear()
        flxDetails.AutoGenerateColumns = False
        flxDetails.AllowUserToAddRows = False
        flxDetails.AllowUserToDeleteRows = False
        flxDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        flxDetails.BackgroundColor = System.Drawing.Color.White
        flxDetails.Font = New System.Drawing.Font("MS Sans Serif", 8.25)
        flxDetails.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(224, 224, 224)

        ' Checkbox
        Dim chk As New DataGridViewCheckBoxColumn()
        chk.HeaderText = "Sel" : chk.Name = "Selected" : chk.Width = 40
        flxDetails.Columns.Add(chk)

        Dim headers() As String = {"Assortment", "Bundle No", "Pcs", "Cts", "Price", "Value", "Size Range"}
        Dim names() As String = {"Assortment", "BundleNo", "Pcs", "Cts", "Price", "Value", "SizeRange"}
        Dim widths() As Integer = {120, 75, 60, 75, 65, 75, 100}
        Dim editable() As Boolean = {False, False, True, True, False, False, False}

        For idx As Integer = 0 To headers.Length - 1
            Dim col As New DataGridViewTextBoxColumn()
            col.HeaderText = headers(idx)
            col.Name = names(idx)
            col.Width = widths(idx)
            col.ReadOnly = Not editable(idx)
            If idx >= 2 AndAlso idx <= 5 Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
            flxDetails.Columns.Add(col)
        Next
    End Sub

    ' LOAD SIZE RANGES
    Private Sub Load_SizeRange()
        Try
            cmbSize.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT Code FROM tblGrading_SizingRange ORDER BY Code", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbSize.Items.Add(dr("Code").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Load_SizeRange")
        End Try
    End Sub

    ' LOAD ASSORTMENTS
    Private Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
        Try
            Cursor.Current = Cursors.WaitCursor
            cmbAssort.Items.Clear()
            Using cmd As New SqlCommand(
                "SELECT AssortNo FROM tblGrading_SizeListNew ORDER BY AssortNo", dbconn_Prod)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        cmbAssort.Items.Add(dr("AssortNo").ToString().Trim())
                    End While
                End Using
            End Using
        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "cmdRefresh_Click")
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    ' BUNDLE NO — ENTER KEY
    Private Sub txtBundleNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBundleNo.KeyPress
        If e.KeyChar = ControlChars.Cr Then
            e.Handled = True
            Load_PackingList()
        End If
    End Sub

    ' LOAD PACKING LIST FOR BUNDLE
    Private Sub Load_PackingList()
        Try
            flxDetails.Rows.Clear()
            Dim bundleNo As String = txtBundleNo.Text.Trim()

            ' Try PackingListB first
            Dim hasB As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT * FROM tblGrading_PackingListB WHERE BundleNo=@bno ORDER BY Assortment, Pcs, Cts",
                dbconn_Prod)
                cmd.Parameters.AddWithValue("@bno", bundleNo)
                Using dr As SqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        hasB = True
                        Dim rowIdx As Integer = flxDetails.Rows.Add()
                        Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                        row.Cells("Selected").Value = True
                        row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                        row.Cells("BundleNo").Value = dr("BundleNo").ToString().Trim()
                        row.Cells("Pcs").Value = dr("Pcs").ToString()
                        row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                        row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                        row.Cells("Value").Value = Format(Convert.ToDouble(dr("Cts")) * Convert.ToDouble(dr("Price")), "#0.00")
                        row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                    End While
                End Using
            End Using

            If Not hasB Then
                ' Fall back to PackingListM + Bundle join
                Dim sql As String =
                    "SELECT TOP (100) PERCENT m.Assortment, m.SizeRange, " &
                    "SUM(m.Pcs) AS Pcs, ROUND(SUM(m.Cts),3) AS Cts, " &
                    "sln.Price, ROUND(SUM(sln.Price * m.Cts),2) AS Value " &
                    "FROM tblGrading_Bundle b " &
                    "INNER JOIN tblGrading_PackingListM m ON b.PackNo = m.PackNo " &
                    "INNER JOIN tblGrading_SizeListNew sln ON m.Assortment = sln.AssortNo " &
                    "WHERE b.BundleNo = @bno " &
                    "GROUP BY m.Assortment, m.SizeRange, sln.Price " &
                    "ORDER BY m.Assortment"

                Using cmd As New SqlCommand(sql, dbconn_Prod)
                    cmd.Parameters.AddWithValue("@bno", bundleNo)
                    Using dr As SqlDataReader = cmd.ExecuteReader()
                        While dr.Read()
                            Dim rowIdx As Integer = flxDetails.Rows.Add()
                            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
                            row.Cells("Selected").Value = True
                            row.Cells("Assortment").Value = dr("Assortment").ToString().Trim()
                            row.Cells("BundleNo").Value = bundleNo
                            row.Cells("Pcs").Value = dr("Pcs").ToString()
                            row.Cells("Cts").Value = Format(Convert.ToDouble(dr("Cts")), "#0.000")
                            row.Cells("Price").Value = Format(Convert.ToDouble(dr("Price")), "#0.00")
                            row.Cells("Value").Value = Format(Convert.ToDouble(dr("Value")), "#0.00")
                            row.Cells("SizeRange").Value = dr("SizeRange").ToString().Trim()
                        End While
                    End Using
                End Using
            End If

            RecalcTotals(setOriginal:=True)

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "Load_PackingList")
        End Try
    End Sub

    ' ADD ROW
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Try
            If cmbAssort.Text.Trim() = "" Then MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If cmbSize.Text.Trim() = "" Then MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewPcs.Text.Trim() = "" OrElse Convert.ToDouble(txtNewPcs.Text) <= 0 Then MessageBox.Show("Invalid Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            If txtNewCts.Text.Trim() = "" OrElse Convert.ToDouble(txtNewCts.Text) <= 0 Then MessageBox.Show("Invalid Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return

            If Convert.ToDouble(txtTotPcs.Text) + Convert.ToDouble(txtNewPcs.Text) > Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Invalid Total Pcs", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text) + Convert.ToDouble(txtNewCts.Text), 3) > Convert.ToDouble(txtCts.Text) Then
                MessageBox.Show("Invalid Total Cts", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Get price
            Dim price As Double = 0
            Using cmd As New SqlCommand(
                "SELECT PRICE FROM tblGrading_SizeListNew WHERE AssortNo=@a", dbconn_Prod)
                cmd.Parameters.AddWithValue("@a", cmbAssort.Text.Trim())
                Dim result = cmd.ExecuteScalar()
                If result Is Nothing Then
                    MessageBox.Show("Invalid Assortment", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                End If
                price = If(result Is DBNull.Value, 0, Convert.ToDouble(result))
            End Using

            ' Validate size range
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_SizingRange WHERE Code=@c", dbconn_Prod)
                cmd.Parameters.AddWithValue("@c", cmbSize.Text.Trim())
                If CInt(cmd.ExecuteScalar()) = 0 Then
                    MessageBox.Show("Invalid Size Range", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
                End If
            End Using

            Dim pcs As Double = Convert.ToDouble(txtNewPcs.Text)
            Dim cts As Double = Convert.ToDouble(txtNewCts.Text)

            Dim rowIdx As Integer = flxDetails.Rows.Add()
            Dim row As DataGridViewRow = flxDetails.Rows(rowIdx)
            row.Cells("Selected").Value = True
            row.Cells("Assortment").Value = cmbAssort.Text.Trim().ToUpper()
            row.Cells("BundleNo").Value = txtBundleNo.Text.Trim()
            row.Cells("Pcs").Value = pcs.ToString()
            row.Cells("Cts").Value = cts.ToString()
            row.Cells("Price").Value = Format(price, "#0.00")
            row.Cells("Value").Value = Format(price * cts, "#0.00")
            row.Cells("SizeRange").Value = cmbSize.Text.Trim()

            RecalcTotals()

            cmbAssort.Text = ""
            cmbSize.Text = ""
            txtNewPcs.Text = ""
            txtNewCts.Text = ""
            cmbAssort.Focus()

        Catch ex As Exception
            ErrorLog("frm_Grading_ExportSummaryBundle", "cmdAdd_Click")
        End Try
    End Sub

    ' RECALCULATE TOTALS
    Private Sub RecalcTotals(Optional setOriginal As Boolean = False)
        Dim totPcs As Double = 0
        Dim totCts As Double = 0

        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("Selected").Value) Then
                totPcs += Convert.ToDouble(If(row.Cells("Pcs").Value?.ToString() = "", "0", row.Cells("Pcs").Value?.ToString()))
                totCts += Convert.ToDouble(If(row.Cells("Cts").Value?.ToString() = "", "0", row.Cells("Cts").Value?.ToString()))
            End If
        Next

        txtTotPcs.Text = totPcs.ToString()
        txtTotCts.Text = Format(Math.Round(totCts, 3), "#0.000")

        If setOriginal Then
            txtPcs.Text = totPcs.ToString()
            txtCts.Text = Format(Math.Round(totCts, 3), "#0.000")
        End If
    End Sub

    Private Sub flxDetails_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles flxDetails.CellValueChanged
        RecalcTotals()
    End Sub

    Private Sub flxDetails_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles flxDetails.CurrentCellDirtyStateChanged
        If flxDetails.IsCurrentCellDirty Then
            flxDetails.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    ' SAVE
    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Try
            If txtBundleNo.Text.Trim() = "" Then
                MessageBox.Show("Invalid Bundle No", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If flxDetails.Rows.Count < 1 Then
                MessageBox.Show("No Records", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            RecalcTotals()

            If Convert.ToDouble(txtTotPcs.Text) <> Convert.ToDouble(txtPcs.Text) Then
                MessageBox.Show("Pcs not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If
            If Math.Round(Convert.ToDouble(txtTotCts.Text), 3) <> Math.Round(Convert.ToDouble(txtCts.Text), 3) Then
                MessageBox.Show("Cts not matching", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return
            End If

            ' Check if exists
            Dim exists As Boolean = False
            Using cmd As New SqlCommand(
                "SELECT COUNT(*) FROM tblGrading_PackingListB WHERE BundleNo=@bno", dbconn_Prod)
                cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                exists = CInt(cmd.ExecuteScalar()) > 0
            End Using

            If exists Then
                If MessageBox.Show("Are you sure to update?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                ' Delete and re-insert
                Using cmd As New SqlCommand(
                    "DELETE FROM tblGrading_PackingListB WHERE BundleNo=@bno", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                    cmd.ExecuteNonQuery()
                End Using
                InsertRows()
                MessageBox.Show("Updated Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If MessageBox.Show("Are you sure to save?", Me.Text,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then Return
                InsertRows()
                MessageBox.Show("Saved Successfully", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            ResetForm()

        Catch ex As Exception
            MessageBox.Show("Save error: " & ex.Message, Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Critical)
        End Try
    End Sub

    Private Sub InsertRows()
        For Each row As DataGridViewRow In flxDetails.Rows
            If Convert.ToBoolean(row.Cells("Selected").Value) Then
                Using cmd As New SqlCommand(
                    "INSERT INTO tblGrading_PackingListB(Assortment,BundleNo,Pcs,Cts,Price,SizeRange) " &
                    "VALUES(@assort,@bno,@pcs,@cts,@price,@size)", dbconn_Prod)
                    cmd.Parameters.AddWithValue("@assort", row.Cells("Assortment").Value?.ToString().Trim())
                    cmd.Parameters.AddWithValue("@bno", CDbl(txtBundleNo.Text))
                    cmd.Parameters.AddWithValue("@pcs", Convert.ToDouble(row.Cells("Pcs").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@cts", Convert.ToDouble(row.Cells("Cts").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@price", Convert.ToDouble(row.Cells("Price").Value?.ToString()))
                    cmd.Parameters.AddWithValue("@size", row.Cells("SizeRange").Value?.ToString().Trim())
                    cmd.ExecuteNonQuery()
                End Using
            End If
        Next
    End Sub

    ' TOOLBAR BUTTONS
    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        ResetForm()
        txtBundleNo.Focus()
    End Sub

    Private Sub cmdExcel_Click(sender As Object, e As EventArgs) Handles cmdExcel.Click
        Try
            Using dlg As New SaveFileDialog()
                dlg.Filter = "Excel Files (*.xls)|*.xls"
                dlg.FileName = "BundlePackage_" & txtBundleNo.Text & ".xls"
                If dlg.ShowDialog() = DialogResult.OK Then
                    Dim sb As New StringBuilder()
                    For Each col As DataGridViewColumn In flxDetails.Columns
                        sb.Append(col.HeaderText & vbTab)
                    Next
                    sb.AppendLine()
                    For Each row As DataGridViewRow In flxDetails.Rows
                        For Each cell As DataGridViewCell In row.Cells
                            sb.Append(cell.Value?.ToString() & vbTab)
                        Next
                        sb.AppendLine()
                    Next
                    File.WriteAllText(dlg.FileName, sb.ToString(), Text.Encoding.UTF8)
                    ShellEx(dlg.FileName)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Export error: " & ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    '── Key press helpers ──────────────────────────────────────────
    Private Sub txtNewPcs_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewPcs.KeyPress
        IntegerOnly(e)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : txtNewCts.Focus()
    End Sub

    Private Sub txtNewCts_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNewCts.KeyPress
        NumericOnly(e, txtNewCts.Text)
        If e.KeyChar = ControlChars.Cr Then e.Handled = True : cmdAdd.Focus()
    End Sub

    ' RESET FORM
    Private Sub ResetForm()
        flxDetails.Rows.Clear()
        txtBundleNo.Text = "" : txtPcs.Text = "0"
        txtCts.Text = "0" : txtTotPcs.Text = "0"
        txtTotCts.Text = "0" : cmbSize.Text = ""
    End Sub

End Class